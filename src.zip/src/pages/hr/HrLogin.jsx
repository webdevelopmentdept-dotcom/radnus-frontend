import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function HrLogin() {
  const navigate = useNavigate();
  const API_BASE = import.meta.env.VITE_API_BASE_URL;

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/api/hr/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data.msg || "Invalid credentials");
        setLoading(false);
        return;
      }

      const hrInfo = data.hr || data.user || data.data || {};

      localStorage.setItem("hrToken", data.token || "");
      localStorage.setItem("hrId", hrInfo._id || hrInfo.id || "hr_admin_001");
      localStorage.setItem("hrUser", JSON.stringify(hrInfo));
      localStorage.setItem("hrRole", data.role || hrInfo.role || "hr");

      // ✅ Role பொறுத்து redirect
      if (data.role === "employee") {
        navigate("/hr/dashboard/attendance/monthly");
      } else {
        navigate("/hr/dashboard/applicants");
      }

    } catch (err) {
      setError("Server error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{ minHeight: "80vh" }}
    >
      <div
        className="card shadow p-4"
        style={{ width: "400px", borderRadius: "15px" }}
      >
        <h3 className="text-center fw-bold text-primary mb-4">HR Login</h3>

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label">Email</label>
            <input
              type="email"
              className="form-control"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-control"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && <p className="text-danger text-center">{error}</p>}

          <button className="btn btn-primary w-100" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <button
          className="btn btn-secondary mt-3"
          style={{ width: "200px", margin: "0 auto", display: "block" }}
          onClick={() => navigate("/login")}
        >
          ← Back to Role Selection
        </button>
      </div>
    </div>
  );
}