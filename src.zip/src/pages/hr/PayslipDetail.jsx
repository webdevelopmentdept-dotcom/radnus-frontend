// pages/hr/PayslipDetail.jsx
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { usePayslipDetail } from "../../hooks/usePayroll";
import EditPayslipModal from "./EditPayslipModal";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const MONTH_NAMES = ["", "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];

// ── EDIT THESE TO YOUR ACTUAL COMPANY DETAILS ──────────────────────
const COMPANY = {
  name: "Radnus Communication",
  addressLine1: "Sinnaya Plaza, 242/244, Mahatma Gandhi Rd,", // TODO: put real address
  addressLine2: " Puducherry, 605001",
  logo: "/image.png", // same logo already used in RadnusNavbar.jsx
};

const fmt = (v) => `₹${Number(v || 0).toLocaleString("en-IN")}`;

// ── Number → words (Indian numbering system) ───────────────────────
const ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
  "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
  "Eighteen", "Nineteen"];
const TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

function twoDigits(n) {
  if (n < 20) return ONES[n];
  return TENS[Math.floor(n / 10)] + (n % 10 ? " " + ONES[n % 10] : "");
}
function threeDigits(n) {
  if (n < 100) return twoDigits(n);
  return ONES[Math.floor(n / 100)] + " Hundred" + (n % 100 ? " " + twoDigits(n % 100) : "");
}
function numberToWords(num) {
  num = Math.round(Number(num) || 0);
  if (num === 0) return "Zero";
  const crore = Math.floor(num / 10000000); num %= 10000000;
  const lakh = Math.floor(num / 100000); num %= 100000;
  const thousand = Math.floor(num / 1000); num %= 1000;
  const rest = num;
  let parts = [];
  if (crore) parts.push(threeDigits(crore) + " Crore");
  if (lakh) parts.push(threeDigits(lakh) + " Lakh");
  if (thousand) parts.push(threeDigits(thousand) + " Thousand");
  if (rest) parts.push(threeDigits(rest));
  return parts.join(" ");
}
const amountInWords = (v) => `${numberToWords(v)} Rupees Only`;

// "Worked Days" here = payable_days (present + half-day + paid leave + holidays + weekends).
// Sundays/weekly-offs count towards Worked Days too — only LOP (absent/unpaid leave) is excluded.
const WORKED_DAYS = (p) =>
  p.payable_days ??
  ((p.present_days || 0) + (p.half_days || 0) * 0.5 + (p.paid_leave_days || 0) +
   (p.holiday_days || 0) + (p.weekend_days || 0));

export default function PayslipDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: p, isLoading } = usePayslipDetail(id);
  const [showEdit, setShowEdit] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownloadPDF = async () => {
    const el = document.getElementById("payslip-print");
    if (!el) return;
    setDownloading(true);
    try {
      // captures ONLY the payslip card — the floating "Pending Review" widget,
      // sidebar, browser date/URL/page-number headers are all outside this
      // element, so none of them end up in the PDF.
      const canvas = await html2canvas(el, {
        scale: 2,
        backgroundColor: "#ffffff",
        useCORS: true,
        windowWidth: 900,
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "pt", "a4");
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      if (imgHeight <= pageHeight) {
        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      } else {
        // taller than one A4 page — slice across multiple pages
        let heightLeft = imgHeight;
        let position = 0;
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
        while (heightLeft > 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }
      }

      const fileName = `Payslip_${(p.employee_name || "employee").replace(/\s+/g, "_")}_${MONTH_NAMES[p.month]}_${p.year}.pdf`;
      pdf.save(fileName);
    } catch (err) {
      alert("PDF generate பண்றதுல problem வந்துச்சு: " + err.message);
    } finally {
      setDownloading(false);
    }
  };

  if (isLoading) return <div style={{ padding: 60, textAlign: "center", color: "#6b7280" }}>Loading...</div>;
  if (!p) return <div style={{ padding: 60, textAlign: "center", color: "#9ca3af" }}>Payslip not found.</div>;

 
const lopDays = p.lop_days ?? ((p.absent_days || 0) + (p.unpaid_leave_days || 0));
const lopAmount = lopDays * (p.per_day_rate || 0);
const halfDayAmount = (p.half_days || 0) * (p.per_day_rate || 0) * 0.5;
// deductions.total_deductions already includes any advance recovery amount
const totalDeductions = (p.deductions?.total_deductions || 0) + lopAmount + halfDayAmount;
  const totalEarnings = p.earnings?.gross_earnings || 0;
  const isEditable = p.status === "draft";

  return (
    <div className="payslip-page" style={{ padding: 24, maxWidth: 820, margin: "0 auto" }}>
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16,
      }}>
        <button onClick={() => navigate(-1)} className="no-print" style={{
          background: "none", border: "none", color: "#2563eb", fontSize: 13, fontWeight: 600,
          cursor: "pointer",
        }}>← Back</button>

        {isEditable && (
          <button onClick={() => setShowEdit(true)} className="no-print" style={{
            background: "#fff", border: "1px solid #d1d5db", color: "#374151", fontSize: 13,
            fontWeight: 600, borderRadius: 8, padding: "7px 14px", cursor: "pointer",
          }}>✏️ Edit</button>
        )}
      </div>

      <div id="payslip-print" className="payslip-card" style={{
        background: "#fff", border: "1px solid #e5e7eb", borderRadius: 14, overflow: "hidden",
        padding: "32px 40px", fontFamily: "inherit",
      }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <img src={COMPANY.logo} alt="Radnus Logo" style={{ height: 56, marginBottom: 8, objectFit: "contain" }} />
          <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: "#111827" }}>Payslip</h1>
          <p style={{ margin: "6px 0 0", fontSize: 15, fontWeight: 600, color: "#374151" }}>{COMPANY.name}</p>
          <p style={{ margin: "2px 0 0", fontSize: 13, color: "#6b7280" }}>
            {COMPANY.addressLine1}<br />{COMPANY.addressLine2}
          </p>
        </div>

        {/* Employee / period info — two columns, like a classic payslip */}
        <div className="payslip-info" style={{
          display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 24px",
          margin: "24px 0", fontSize: 14,
        }}>
          <InfoRow label="Date of Joining" value={p.date_of_joining || "—"} />
          <InfoRow label="Employee name" value={p.employee_name} />
          <InfoRow label="Pay Period" value={`${MONTH_NAMES[p.month]} ${p.year}`} />
          <InfoRow label="Designation" value={p.designation} />
          <InfoRow label="Worked Days" value={WORKED_DAYS(p)} />
          <InfoRow label="Total Days in Month" value={p.total_days_in_month || "—"} />
          <InfoRow label="Department" value={p.department} />
          {p.employee_code && <InfoRow label="Employee Code" value={p.employee_code} />}
          <InfoRow label="Absent (LOP) Days" value={lopDays} />
        </div>

        {/* Earnings | Deductions table */}
        <div className="payslip-table-wrap">
        <table className="payslip-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 14, marginTop: 8 }}>
          <thead>
            <tr>
              <th style={thStyle}>Earnings</th>
              <th style={{ ...thStyle, textAlign: "right" }}>Amount</th>
              <th style={thStyle}>Deductions</th>
              <th style={{ ...thStyle, textAlign: "right" }}>Amount</th>
            </tr>
          </thead>
          <tbody>
{buildRows(p, lopDays, lopAmount, halfDayAmount).map((row, i) => (
              <tr key={i}>
                <td style={tdStyle}>{row.eLabel}</td>
                <td style={{ ...tdStyle, textAlign: "right" }}>{row.eAmount}</td>
                <td style={tdStyle}>{row.dLabel}</td>
                <td style={{ ...tdStyle, textAlign: "right" }}>{row.dAmount}</td>
              </tr>
            ))}
            <tr>
              <td style={{ ...tdStyle, ...totalStyle, textAlign: "right" }}>Total Earnings</td>
              <td style={{ ...tdStyle, ...totalStyle, textAlign: "right" }}>{fmt(totalEarnings)}</td>
              <td style={{ ...tdStyle, ...totalStyle, textAlign: "right" }}>Total Deductions</td>
              <td style={{ ...tdStyle, ...totalStyle, textAlign: "right" }}>{fmt(totalDeductions)}</td>
            </tr>
          </tbody>
        </table>
        </div>

        {/* Net Pay */}
        <div style={{
          display: "flex", justifyContent: "flex-end", padding: "14px 0",
          borderTop: "2px solid #111827", marginTop: 4,
        }}>
          <span style={{ fontSize: 15, fontWeight: 700, marginRight: 24 }}>Net Pay</span>
          <span style={{ fontSize: 15, fontWeight: 800 }}>{fmt(p.net_pay)}</span>
        </div>

        {/* Amount in words */}
        <div style={{ textAlign: "center", margin: "20px 0" }}>
          <p style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>{fmt(p.net_pay)}</p>
          <p style={{ margin: "2px 0 0", fontSize: 13, color: "#374151" }}>{amountInWords(p.net_pay)}</p>
        </div>

        {/* Signatures */}
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24,
          marginTop: 56, fontSize: 13, textAlign: "center",
        }}>
          <div>
            <p style={{ margin: 0 }}>MD Signature</p>
            <div style={{ borderTop: "1px solid #111827", marginTop: 48 }} />
          </div>
          <div>
            <p style={{ margin: 0 }}>Employee Signature</p>
            <div style={{ borderTop: "1px solid #111827", marginTop: 48 }} />
          </div>
        </div>

        <p style={{ textAlign: "center", fontSize: 11, color: "#9ca3af", marginTop: 40 }}>
          This is system generated payslip
        </p>
      </div>

      <div className="no-print" style={{ display: "flex", gap: 10, marginTop: 16 }}>
        <button onClick={handleDownloadPDF} disabled={downloading} style={{
          background: "#1a1a2e", color: "#fff", border: "none", borderRadius: 8,
          padding: "10px 22px", fontWeight: 700, fontSize: 13,
          cursor: downloading ? "not-allowed" : "pointer", opacity: downloading ? 0.7 : 1,
        }}>{downloading ? "Generating PDF..." : "⬇️ Download PDF"}</button>

        <button onClick={() => window.print()} style={{
          background: "#fff", color: "#374151", border: "1px solid #d1d5db", borderRadius: 8,
          padding: "10px 22px", fontWeight: 700, fontSize: 13, cursor: "pointer",
        }}>🖨️ Print</button>
      </div>

      {showEdit && (
        <EditPayslipModal payslip={p} onClose={() => setShowEdit(false)} />
      )}

      <style>{`
        @media print {
          .no-print { display: none !important; }
          #payslip-print { border: none !important; }
        }
        @media (max-width: 640px) {
          .payslip-page { padding: 12px !important; }
          .payslip-card { padding: 20px 14px !important; }
          .payslip-info {
            grid-template-columns: 1fr !important;
            margin: 16px 0 !important;
            font-size: 13px !important;
          }
          .payslip-table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
          .payslip-table { min-width: 520px; font-size: 13px !important; }
        }
      `}</style>
    </div>
  );
}

// ── Build side-by-side earnings/deductions rows (pads shorter column with blanks) ──
function buildRows(p, lopDays, lopAmount, halfDayAmount) {
  const earningsList = [
    { label: "Basic", amount: p.earnings?.basic },
    { label: "HRA", amount: p.earnings?.hra },
    { label: "Special Allowance", amount: p.earnings?.special_allowance },
    { label: "Conveyance Allowance", amount: p.earnings?.conveyance_allowance },
  ];
  if (p.earnings?.overtime_amount > 0) earningsList.push({ label: "Overtime", amount: p.earnings.overtime_amount });

  const deductionsList = [];
  
  if (lopDays > 0) deductionsList.push({ label: `LOP (${lopDays} day${lopDays > 1 ? "s" : ""})`, amount: lopAmount });
  if (p.half_days > 0) deductionsList.push({ label: `Half Day (${p.half_days} day${p.half_days > 1 ? "s" : ""})`, amount: halfDayAmount });
  (p.advance_recoveries || []).forEach((a) => {
    deductionsList.push({ label: `Advance Recovery (${a.reason})`, amount: a.amount });
  });
  if (p.deductions?.pf > 0) deductionsList.push({ label: "Provident Fund", amount: p.deductions.pf });
  if (p.deductions?.esi > 0) deductionsList.push({ label: "ESI", amount: p.deductions.esi });
  if (p.deductions?.tds > 0) deductionsList.push({ label: "TDS", amount: p.deductions.tds });
if (p.deductions?.professional_tax > 0) deductionsList.push({ label: "Professional Tax", amount: p.deductions.professional_tax });
  if (p.other_deduction?.amount > 0) {
    deductionsList.push({
      label: `Other Deduction${p.other_deduction.reason ? ` (${p.other_deduction.reason})` : ""}`,
      amount: p.other_deduction.amount,
    });
  }
  if (deductionsList.length === 0) deductionsList.push({ label: "No deductions applied", amount: 0 });

  const rowCount = Math.max(earningsList.length, deductionsList.length);
  const rows = [];
  for (let i = 0; i < rowCount; i++) {
    rows.push({
      eLabel: earningsList[i]?.label || "",
      eAmount: earningsList[i] ? fmt(earningsList[i].amount) : "",
      dLabel: deductionsList[i]?.label || "",
      dAmount: deductionsList[i] ? fmt(deductionsList[i].amount) : "",
    });
  }
  return rows;
}

function InfoRow({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px dotted #e5e7eb", padding: "3px 0" }}>
      <span style={{ color: "#6b7280" }}>{label}</span>
      <span style={{ fontWeight: 600, color: "#111827" }}>{value ?? "—"}</span>
    </div>
  );
}

const thStyle = { textAlign: "left", padding: "8px 6px", background: "#f3f4f6", borderBottom: "2px solid #111827", fontSize: 13 };
const tdStyle = { padding: "6px 6px", borderBottom: "1px solid #f3f4f6" };
const totalStyle = { fontWeight: 700, borderTop: "2px solid #111827", borderBottom: "none" };