import { useState, useEffect, useRef } from "react";
import axios from "axios";
import { HugeiconsIcon } from "@hugeicons/react";
import {
  PlusSignIcon, Delete02Icon, PencilEdit01Icon,
  CheckmarkCircle01Icon, Building04Icon, Target01Icon,
  Calendar01Icon, Award01Icon,
} from "@hugeicons/core-free-icons";

const API_BASE = import.meta.env.VITE_API_BASE_URL;

const inp = {
  width: "100%", padding: "9px 12px", border: "1.5px solid #e2e8f0",
  borderRadius: 8, fontSize: 13, color: "#1e293b", background: "#fff",
  boxSizing: "border-box", outline: "none", fontFamily: "inherit",
  transition: "border-color 0.15s",
};
const lbl = {
  display: "block", fontSize: 11, fontWeight: 700,
  color: "#64748b", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em",
};

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const CURRENT_YEAR = new Date().getFullYear();
const YEARS = [CURRENT_YEAR - 1, CURRENT_YEAR, CURRENT_YEAR + 1];

const VALUE_TYPES = [
  { value: "count", label: "Count" },
  { value: "percentage", label: "Percentage %" },
  { value: "amount", label: "Amount ₹" },
  { value: "rating", label: "Rating" },
];
const OPERATORS = [
  { value: ">=", label: "≥ (At least)" },
  { value: ">", label: "> (More than)" },
  { value: "=", label: "= (Exactly)" },
  { value: "<=", label: "≤ (At most)" },
  { value: "<", label: "< (Less than)" },
];

// ── Standalone target measurement types ──────────────────────────────────────
const STANDALONE_TARGET_TYPES = [
  { value: "revenue", label: "Revenue (₹)", icon: "💰", placeholder: "e.g. 100000" },
  { value: "units", label: "Units / Count", icon: "📦", placeholder: "e.g. 50" },
  { value: "percent", label: "Percentage (%)", icon: "📊", placeholder: "e.g. 75" },
];

// ── Standalone payout types ───────────────────────────────────────────────────
const STANDALONE_PAYOUT_TYPES = [
  { value: "fixed", label: "Fixed Amount (₹)" },
  { value: "percent_of_achieved", label: "% of Achieved Value" },
  { value: "percent_of_salary", label: "% of Salary" },
  { value: "per_unit", label: "Per Unit (₹ × count)" },
];

const EMPTY_STANDALONE_SLAB = () => ({
  min_target: 0,
  max_target: 0,
  payout_type: "fixed",
  payout_value: 0,
});

const EMPTY_KPI_CONFIG = (kpiItem) => ({
  kpi_name: kpiItem.kpi_name,
  weight: kpiItem.weight,
  target: kpiItem.target || "",
  value_type: "count",
  operator: ">=",
  rule_label: "",
  is_admission_kpi: kpiItem.is_admission_kpi || false,
  program_targets: kpiItem.program_targets || [],
  program_slabs: (kpiItem.program_targets || []).map(pt => ({
    program_id: pt.program_id,
    program_name: pt.program_name,
    slabs: [],
  })),
  slabs: [],
});

const EMPTY_FORM = {
  name: "", description: "", department: "", plan_type: "kpi_linked",
  period_type: "Monthly", period_month: new Date().getMonth() + 1,
  period_quarter: "Q1", period_half: "H1", period_year: CURRENT_YEAR,
  kpi_template_id: "", selected_kpis: [], kpi_configs: [],
  completion_reward_type: "none", completion_reward_value: 0, completion_reward_label: "",
  // Standalone
  standalone_payout_type: "fixed", standalone_payout_value: 0,
  standalone_metric: "manual", standalone_metric_label: "",
  standalone_target_type: "revenue",
  standalone_slabs: [],
  slabs: [],
};

const DEPT_COLORS = {
  Sales: { color: "#2563eb", bg: "#eff6ff" },
  Engineering: { color: "#7c3aed", bg: "#f5f3ff" },
  Marketing: { color: "#d97706", bg: "#fffbeb" },
  HR: { color: "#16a34a", bg: "#f0fdf4" },
  Finance: { color: "#ea580c", bg: "#fff7ed" },
  Operations: { color: "#0891b2", bg: "#ecfeff" },
};
const getColor = (d) => DEPT_COLORS[d] || { color: "#6b7280", bg: "#f3f4f6" };

function buildRuleLabel(cfg) {
  if (!cfg.target) return "";
  const opLabel = OPERATORS.find(o => o.value === cfg.operator)?.label?.split(" ")[0] || cfg.operator;
  const unit = cfg.value_type === "percentage" ? "%" : cfg.value_type === "amount" ? "₹" : cfg.value_type === "rating" ? "/10" : " units";
  return `${opLabel} ${cfg.target}${unit}`;
}

function periodLabel(f) {
  const y = f.period_year;
  switch (f.period_type) {
    case "Monthly": return `${MONTHS[(f.period_month || 1) - 1].slice(0, 3)} ${y}`;
    case "Quarterly": return `${f.period_quarter} ${y}`;
    case "Half-Yearly": return `${f.period_half} ${y}`;
    case "Yearly": return `FY ${y}`;
    default: return `${y}`;
  }
}

function validateSlabs(slabs) {
  const errors = [];
  slabs.forEach((s, i) => {
    if (s.min_score > s.max_score) errors.push(`Slab ${i + 1}: Min > Max`);
    if (s.type !== "none" && s.value <= 0) errors.push(`Slab ${i + 1}: Value must be > 0`);
  });
  for (let i = 0; i < slabs.length; i++)
    for (let j = i + 1; j < slabs.length; j++)
      if (slabs[i].max_score >= slabs[j].min_score && slabs[i].min_score <= slabs[j].max_score)
        errors.push(`Slabs ${i + 1} & ${j + 1} overlap`);
  return errors;
}

function validateStandaloneSlabs(slabs) {
  const errors = [];
  slabs.forEach((s, i) => {
    if (Number(s.min_target) > Number(s.max_target) && Number(s.max_target) !== 0)
      errors.push(`Slab ${i + 1}: Min > Max`);
    if (s.payout_value <= 0) errors.push(`Slab ${i + 1}: Payout value must be > 0`);
  });
  return errors;
}

// ── Format target display ─────────────────────────────────────────────────────
function formatTarget(val, type) {
  if (!val && val !== 0) return "—";
  const n = Number(val);
  if (type === "revenue") return n >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : `₹${n.toLocaleString("en-IN")}`;
  if (type === "percent") return `${n}%`;
  return n.toLocaleString("en-IN");
}

// ── Standalone Slab Editor ────────────────────────────────────────────────────
function StandaloneSlabEditor({ slabs, targetType, onAdd, onUpdate, onRemove }) {
  const errors = validateStandaloneSlabs(slabs);
  const tInfo = STANDALONE_TARGET_TYPES.find(t => t.value === targetType) || STANDALONE_TARGET_TYPES[0];

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <label style={{ ...lbl, margin: 0 }}>
          {tInfo.icon} Target → Payout Slabs
        </label>
        <button onClick={onAdd}
          style={{ background: "#eef2ff", border: "none", borderRadius: 7, padding: "5px 14px", fontSize: 11, fontWeight: 700, color: "#4f46e5", cursor: "pointer" }}>
          + Add Slab
        </button>
      </div>

      {errors.length > 0 && (
        <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 7, padding: "7px 12px", marginBottom: 8 }}>
          {errors.map((e, i) => <p key={i} style={{ margin: "2px 0", fontSize: 11, color: "#dc2626", fontWeight: 600 }}>⚠ {e}</p>)}
        </div>
      )}

      {slabs.length === 0 ? (
        <div style={{ textAlign: "center", padding: "24px 16px", background: "#f8fafc", borderRadius: 10, border: "2px dashed #e2e8f0" }}>
          <p style={{ margin: 0, fontSize: 13, color: "#94a3b8", fontWeight: 500 }}>
            No slabs yet — click "+ Add Slab" to define target ranges
          </p>
          <p style={{ margin: "4px 0 0", fontSize: 11, color: "#cbd5e1" }}>
            Example: 0–1,00,000 → ₹1,000 | 1,00,001–2,00,000 → ₹2,000
          </p>
        </div>
      ) : (
        <>
          {/* Header */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 160px 1fr 32px", gap: 8, marginBottom: 6, padding: "0 4px" }}>
            {[`Min ${tInfo.label}`, `Max ${tInfo.label}`, "Payout Type", "Payout Value", ""].map(h => (
              <span key={h} style={{ fontSize: 10, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase" }}>{h}</span>
            ))}
          </div>

          {slabs.map((slab, si) => (
            <div key={si} style={{ display: "grid", gridTemplateColumns: "1fr 1fr 160px 1fr 32px", gap: 8, marginBottom: 8, alignItems: "start" }}>
              {/* Min target */}
              <div>
                <input
                  type="number" min="0"
                  value={slab.min_target}
                  onChange={e => onUpdate(si, "min_target", e.target.value)}
                  placeholder={tInfo.placeholder}
                  style={{ ...inp, padding: "7px 8px", fontSize: 12 }}
                />
                <span style={{ fontSize: 10, color: "#94a3b8", marginTop: 2, display: "block" }}>
                  {formatTarget(slab.min_target, targetType)}
                </span>
              </div>

            {/* Max target */}
              <div>
                <input
                  type="number" min="0"
                  value={Number(slab.max_target) === 0 ? "" : slab.max_target}
                  onChange={e => onUpdate(si, "max_target", e.target.value)}
                  disabled={Number(slab.max_target) === 0}
                  placeholder="e.g. 200000"
                  style={{ ...inp, padding: "7px 8px", fontSize: 12, background: Number(slab.max_target) === 0 ? "#f8fafc" : "#fff", color: Number(slab.max_target) === 0 ? "#9ca3af" : "#1e293b" }}
                />
                <label style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 4, cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={Number(slab.max_target) === 0}
                    onChange={e => onUpdate(si, "max_target", e.target.checked ? 0 : "")}
                    style={{ width: 12, height: 12, cursor: "pointer" }}
                  />
                  <span style={{ fontSize: 10, fontWeight: 700, color: Number(slab.max_target) === 0 ? "#4f46e5" : "#94a3b8" }}>
                    {Number(slab.max_target) === 0 ? "∞ No Limit (& Above)" : "No limit?"}
                  </span>
                </label>
              </div>

              {/* Payout type */}
              <select
                value={slab.payout_type}
                onChange={e => onUpdate(si, "payout_type", e.target.value)}
                style={{ ...inp, padding: "7px 8px", fontSize: 12 }}
              >
                {STANDALONE_PAYOUT_TYPES.map(pt => (
                  <option key={pt.value} value={pt.value}>{pt.label}</option>
                ))}
              </select>

              {/* Payout value */}
              <div>
                <input
                  type="number" min="0" step="0.01"
                  value={slab.payout_value}
                  onChange={e => onUpdate(si, "payout_value", e.target.value)}
                  placeholder={slab.payout_type === "fixed" || slab.payout_type === "per_unit" ? "e.g. 150" : "e.g. 5"}
                  style={{ ...inp, padding: "7px 8px", fontSize: 12 }}
                />
                {slab.payout_value > 0 && (
                  <span style={{ fontSize: 10, fontWeight: 700, color: "#4f46e5", marginTop: 2, display: "block" }}>
                    {slab.payout_type === "fixed"
                      ? `₹${Number(slab.payout_value).toLocaleString("en-IN")}`
                      : slab.payout_type === "per_unit"
                        ? `₹${Number(slab.payout_value).toLocaleString("en-IN")} / unit`
                        : `${slab.payout_value}%`}
                  </span>
                )}
              </div>

              {/* Remove */}
              <button
                onClick={() => onRemove(si)}
                style={{ background: "#fef2f2", border: "none", borderRadius: 7, padding: "7px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", marginTop: 1 }}
              >
                <HugeiconsIcon icon={Delete02Icon} size={13} color="#dc2626" strokeWidth={2} />
              </button>
            </div>
          ))}

          {/* Slab preview */}
          {slabs.length > 0 && (
            <div style={{ marginTop: 12, background: "#f8fafc", borderRadius: 10, padding: "12px 14px", border: "1px solid #e2e8f0" }}>
              <p style={{ margin: "0 0 8px", fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase" }}>Preview</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {slabs.map((slab, si) => (
                  <div key={si} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 8, padding: "6px 12px", fontSize: 12, fontWeight: 600, color: "#374151" }}>
                    <span style={{ color: "#64748b" }}>
                      {formatTarget(slab.min_target, targetType)}
                      {" → "}
                      {Number(slab.max_target) === 0 ? "∞" : formatTarget(slab.max_target, targetType)}
                    </span>
                    <span style={{ margin: "0 6px", color: "#cbd5e1" }}>|</span>
                    <span style={{ color: "#16a34a", fontWeight: 700 }}>
                      {slab.payout_type === "fixed"
                        ? `₹${Number(slab.payout_value).toLocaleString("en-IN")}`
                        : slab.payout_type === "per_unit"
                          ? `₹${Number(slab.payout_value).toLocaleString("en-IN")} / unit`
                          : `${slab.payout_value}% ${slab.payout_type === "percent_of_salary" ? "of salary" : "of achieved"}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── KPI SlabEditor (existing, unchanged) ─────────────────────────────────────
function SlabEditor({ slabs, onAdd, onUpdate, onRemove, cfg }) {
  const errors = validateSlabs(slabs);
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <label style={{ ...lbl, margin: 0 }}>Score → Payout Slabs</label>
        <button onClick={onAdd}
          style={{ background: "#eef2ff", border: "none", borderRadius: 7, padding: "5px 12px", fontSize: 11, fontWeight: 700, color: "#4f46e5", cursor: "pointer" }}>
          + Add Slab
        </button>
      </div>
      {errors.length > 0 && (
        <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 7, padding: "7px 12px", marginBottom: 8 }}>
          {errors.map((e, i) => <p key={i} style={{ margin: "2px 0", fontSize: 11, color: "#dc2626", fontWeight: 600 }}>⚠ {e}</p>)}
        </div>
      )}
      {slabs.length === 0 ? (
        <p style={{ fontSize: 12, color: "#94a3b8", fontStyle: "italic", margin: 0 }}>No slabs yet — click "+ Add Slab"</p>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "65px 65px 130px 1fr 32px", gap: 8, marginBottom: 6 }}>
            {["Min %", "Max %", "Type", "Amount / %", ""].map(h => (
              <span key={h} style={{ fontSize: 10, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase" }}>{h}</span>
            ))}
          </div>
          {slabs.map((slab, si) => (
            <div key={si} style={{ display: "grid", gridTemplateColumns: "65px 65px 130px 1fr 32px", gap: 8, marginBottom: 7, alignItems: "center" }}>
              <input type="number" min="0" max="100" value={slab.min_score}
                onChange={e => onUpdate(si, "min_score", e.target.value)}
                style={{ ...inp, padding: "7px 8px", fontSize: 12 }} />
              <input type="number" min="0" max="100" value={slab.max_score}
                onChange={e => onUpdate(si, "max_score", e.target.value)}
                style={{ ...inp, padding: "7px 8px", fontSize: 12 }} />
              <select value={slab.type} onChange={e => onUpdate(si, "type", e.target.value)}
                style={{ ...inp, padding: "7px 8px", fontSize: 12 }}>
                <option value="none">No Bonus</option>
                <option value="fixed">Fixed ₹</option>
                <option value="target_percentage">% of Target</option>
              </select>
              <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                <input type="number" min="0" step="0.1" value={slab.value}
                  disabled={slab.type === "none"}
                  onChange={e => onUpdate(si, "value", e.target.value)}
                  placeholder={slab.type === "target_percentage" ? "e.g. 3.2" : "e.g. 3000"}
                  style={{ ...inp, padding: "7px 8px", fontSize: 12, background: slab.type === "none" ? "#f8fafc" : "#fff", color: slab.type === "none" ? "#94a3b8" : "#1e293b" }} />
                {slab.type === "target_percentage" && slab.value > 0 && cfg?.target && (
                  <span style={{ fontSize: 10, fontWeight: 700, color: "#4f46e5", background: "#eef2ff", borderRadius: 4, padding: "2px 6px", textAlign: "center" }}>
                    = ₹{((Number(slab.value) / 100) * Number(cfg.target)).toLocaleString("en-IN")}
                  </span>
                )}
              </div>
              <button onClick={() => onRemove(si)}
                style={{ background: "#fef2f2", border: "none", borderRadius: 7, padding: "7px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <HugeiconsIcon icon={Delete02Icon} size={13} color="#dc2626" strokeWidth={2} />
              </button>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

// ── AdmissionKpiConfig (unchanged from original) ─────────────────────────────
function AdmissionKpiConfig({ cfg, onAddProgSlab, onUpdateProgSlab, onRemoveProgSlab }) {
  const [activeProgram, setActiveProgram] = useState(
    () => cfg.program_targets?.[0]?.program_id || null
  );
  const prevProgramTargetsRef = useRef(null);

  useEffect(() => {
    if (!cfg.program_targets?.length) return;
    const currentKey = cfg.program_targets.map(pt => pt.program_id).join(",");
    const prevKey = prevProgramTargetsRef.current;
    if (currentKey !== prevKey) {
      prevProgramTargetsRef.current = currentKey;
      setActiveProgram(prev => {
        const stillExists = cfg.program_targets.some(pt => pt.program_id === prev);
        return stillExists ? prev : cfg.program_targets[0].program_id;
      });
    }
  }, [cfg.program_targets]);

  if (!cfg.program_targets?.length) {
    return <p style={{ fontSize: 12, color: "#f59e0b", fontStyle: "italic" }}>⚠ No programs found for this KPI.</p>;
  }

  const activePt = cfg.program_targets.find(pt => pt.program_id === activeProgram);
  const progSlabEntry = (cfg.program_slabs || []).find(ps => ps.program_id === activeProgram);
  const progSlabs = progSlabEntry?.slabs || [];
  const totalTarget = cfg.program_targets.reduce((s, pt) => s + (Number(pt.target) || 0), 0);

  return (
    <div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
        {cfg.program_targets.map((pt) => {
          const pSlabs = (cfg.program_slabs || []).find(ps => ps.program_id === pt.program_id)?.slabs || [];
          const isActive = activeProgram === pt.program_id;
          return (
            <div key={pt.program_id} style={{
              background: isActive ? "#0369a1" : "#f0f9ff",
              border: `1px solid ${isActive ? "#0369a1" : "#bae6fd"}`,
              borderRadius: 8, padding: "8px 12px", textAlign: "center", minWidth: 80,
              cursor: "pointer", transition: "all 0.15s",
            }} onClick={() => setActiveProgram(pt.program_id)}>
              <p style={{ margin: 0, fontSize: 10, fontWeight: 600, color: isActive ? "rgba(255,255,255,0.8)" : "#6b7280" }}>{pt.program_name}</p>
              <p style={{ margin: "2px 0 0", fontSize: 18, fontWeight: 800, fontFamily: "monospace", color: isActive ? "#fff" : "#0369a1" }}>{pt.target}</p>
              <p style={{ margin: 0, fontSize: 9, color: isActive ? "rgba(255,255,255,0.6)" : "#9ca3af" }}>{pSlabs.length} slab{pSlabs.length !== 1 ? "s" : ""}</p>
            </div>
          );
        })}
        <div style={{ background: "#1e293b", border: "1px solid #1e293b", borderRadius: 8, padding: "8px 12px", textAlign: "center", minWidth: 80 }}>
          <p style={{ margin: 0, fontSize: 10, color: "rgba(255,255,255,0.6)", fontWeight: 600 }}>Total</p>
          <p style={{ margin: "2px 0 0", fontSize: 18, fontWeight: 800, color: "#fff", fontFamily: "monospace" }}>{totalTarget}</p>
          <p style={{ margin: 0, fontSize: 9, color: "rgba(255,255,255,0.5)" }}>admissions</p>
        </div>
      </div>
      {activePt && (
        <div style={{ border: "1.5px solid #bae6fd", borderRadius: 10, overflow: "hidden" }}>
          <div style={{ background: "#f0f9ff", padding: "10px 14px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #bae6fd" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: "#0369a1" }}>📚 {activePt.program_name}</span>
              <span style={{ fontSize: 11, color: "#6b7280", background: "#e0f2fe", padding: "2px 8px", borderRadius: 99, fontWeight: 600 }}>Target: {activePt.target} admissions</span>
            </div>
            <span style={{ fontSize: 11, color: "#0369a1", fontWeight: 700 }}>{progSlabs.length} slab{progSlabs.length !== 1 ? "s" : ""}</span>
          </div>
          <div style={{ padding: "14px" }}>
            <SlabEditor
              slabs={progSlabs}
              cfg={{ ...cfg, target: activePt.target }}
              onAdd={() => onAddProgSlab(cfg.kpi_name, activeProgram)}
              onUpdate={(si, field, val) => onUpdateProgSlab(cfg.kpi_name, activeProgram, si, field, val)}
              onRemove={(si) => onRemoveProgSlab(cfg.kpi_name, activeProgram, si)}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// ── SearchableSelect — dropdown with search filter ────────────────────────────
function SearchableSelect({ options = [], value, onChange, placeholder = "Search...", disabled = false }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const wrapRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false);
        setQuery("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selected = options.find(o => o.value === value);

  const filtered = options.filter(o =>
    !query.trim() ||
    o.label?.toLowerCase().includes(query.toLowerCase()) ||
    o.sublabel?.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <div
        onClick={() => !disabled && setOpen(o => !o)}
        style={{
          ...inp,
          display: "flex", alignItems: "center", justifyContent: "space-between",
          cursor: disabled ? "not-allowed" : "pointer",
          background: disabled ? "#f8fafc" : "#fff",
          color: selected ? "#1e293b" : "#94a3b8",
        }}
      >
        <span>{selected ? selected.label : placeholder}</span>
        <span style={{ fontSize: 10, color: "#94a3b8" }}>▼</span>
      </div>

      {open && !disabled && (
        <div style={{
          position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, zIndex: 50,
          background: "#fff", border: "1.5px solid #e2e8f0", borderRadius: 10,
          boxShadow: "0 8px 24px rgba(0,0,0,0.12)", overflow: "hidden",
        }}>
          <input
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder={placeholder}
            style={{ width: "100%", padding: "9px 12px", border: "none", borderBottom: "1px solid #f1f5f9", fontSize: 13, outline: "none", boxSizing: "border-box" }}
          />
          <div style={{ maxHeight: 220, overflowY: "auto" }}>
            {filtered.length === 0 ? (
              <p style={{ margin: 0, padding: "10px 12px", fontSize: 12, color: "#94a3b8" }}>No matches</p>
            ) : (
              filtered.map(o => (
                <div
                  key={o.value}
                  onClick={() => { onChange(o.value); setOpen(false); setQuery(""); }}
                  style={{
                    padding: "9px 12px", cursor: "pointer", fontSize: 13,
                    background: o.value === value ? "#eef2ff" : "#fff",
                    color: o.value === value ? "#4f46e5" : "#1e293b",
                    fontWeight: o.value === value ? 700 : 500,
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = o.value === value ? "#eef2ff" : "#f8fafc"}
                  onMouseLeave={e => e.currentTarget.style.background = o.value === value ? "#eef2ff" : "#fff"}
                >
                  {o.label}
                  {o.sublabel && <span style={{ marginLeft: 6, fontSize: 11, color: "#94a3b8" }}>— {o.sublabel}</span>}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}


// ════════════════════════════════════════════════════════════════════════════
export default function IncentivePlans() {
  const [plans, setPlans] = useState([]);
  const [depts, setDepts] = useState([]);
  const [kpiTemplates, setKpiTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
    const [pageSearch, setPageSearch] = useState("");

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [p, d, k] = await Promise.all([
        axios.get(`${API_BASE}/api/incentive-plans`),
        axios.get(`${API_BASE}/api/departments`),
        axios.get(`${API_BASE}/api/kpi-templates`),
      ]);
      setPlans(p.data?.data || p.data || []);
      const list = d.data?.data || d.data || [];
      setDepts(list.map(x => typeof x === "string" ? x : x.name));
      if (k.data?.success) setKpiTemplates(k.data.data || []);
    } catch { showToast("Failed to load data", "error"); }
    finally { setLoading(false); }
  };

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const filteredTemplates = kpiTemplates.filter(t => !form.department || t.department === form.department);
  const selectedTemplate = kpiTemplates.find(t => t._id === form.kpi_template_id);

  // ── KPI handlers (unchanged) ──────────────────────────────────────────────
  const toggleKpi = (kpiItem) => {
    const name = kpiItem.kpi_name;
    const isSelected = form.selected_kpis.includes(name);
    if (isSelected) {
      setForm(f => ({ ...f, selected_kpis: f.selected_kpis.filter(k => k !== name), kpi_configs: f.kpi_configs.filter(c => c.kpi_name !== name) }));
    } else {
      setForm(f => ({ ...f, selected_kpis: [...f.selected_kpis, name], kpi_configs: [...f.kpi_configs, EMPTY_KPI_CONFIG(kpiItem)] }));
    }
  };

  const updateKpiConfig = (kpiName, field, val) => {
    setForm(f => ({
      ...f,
      kpi_configs: f.kpi_configs.map(c => {
        if (c.kpi_name !== kpiName) return c;
        const updated = { ...c, [field]: val };
        updated.rule_label = buildRuleLabel(updated);
        return updated;
      }),
    }));
  };

  const addSlabToKpi = (kpiName) => setForm(f => ({ ...f, kpi_configs: f.kpi_configs.map(c => { if (c.kpi_name !== kpiName) return c; const last = c.slabs[c.slabs.length - 1]; const newMin = last ? last.max_score + 1 : 0; return { ...c, slabs: [...c.slabs, { min_score: newMin, max_score: Math.min(newMin + 10, 100), type: "fixed", value: 0 }] }; }) }));
  const updateKpiSlab = (kpiName, slabIdx, field, val) => setForm(f => ({ ...f, kpi_configs: f.kpi_configs.map(c => { if (c.kpi_name !== kpiName) return c; const slabs = [...c.slabs]; slabs[slabIdx] = { ...slabs[slabIdx], [field]: field === "type" ? val : Number(val) }; return { ...c, slabs }; }) }));
  const removeKpiSlab = (kpiName, slabIdx) => setForm(f => ({ ...f, kpi_configs: f.kpi_configs.map(c => { if (c.kpi_name !== kpiName) return c; return { ...c, slabs: c.slabs.filter((_, i) => i !== slabIdx) }; }) }));

  const addProgSlab = (kpiName, progId) => setForm(f => ({ ...f, kpi_configs: f.kpi_configs.map(c => { if (c.kpi_name !== kpiName) return c; const ps = [...(c.program_slabs || [])]; const progIdx = ps.findIndex(p => p.program_id === progId); const mkNew = () => ({ min_score: 0, max_score: 10, type: "fixed", value: 0 }); if (progIdx >= 0) { ps[progIdx] = { ...ps[progIdx], slabs: [...ps[progIdx].slabs, mkNew()] }; } else { const ptEntry = c.program_targets.find(p => p.program_id === progId); ps.push({ program_id: progId, program_name: ptEntry?.program_name || progId, slabs: [mkNew()] }); } return { ...c, program_slabs: ps }; }) }));
  const updateProgSlab = (kpiName, progId, slabIdx, field, val) => setForm(f => ({ ...f, kpi_configs: f.kpi_configs.map(c => { if (c.kpi_name !== kpiName) return c; const ps = [...(c.program_slabs || [])]; const progIdx = ps.findIndex(p => p.program_id === progId); if (progIdx < 0) return c; const slabs = [...ps[progIdx].slabs]; slabs[slabIdx] = { ...slabs[slabIdx], [field]: field === "type" ? val : Number(val) }; ps[progIdx] = { ...ps[progIdx], slabs }; return { ...c, program_slabs: ps }; }) }));
  const removeProgSlab = (kpiName, progId, slabIdx) => setForm(f => ({ ...f, kpi_configs: f.kpi_configs.map(c => { if (c.kpi_name !== kpiName) return c; const ps = [...(c.program_slabs || [])]; const progIdx = ps.findIndex(p => p.program_id === progId); if (progIdx < 0) return c; ps[progIdx] = { ...ps[progIdx], slabs: ps[progIdx].slabs.filter((_, i) => i !== slabIdx) }; return { ...c, program_slabs: ps }; }) }));

  // ── Standalone slab handlers ──────────────────────────────────────────────
  const addStandaloneSlab = () => {
    setForm(f => {
      const last = f.standalone_slabs[f.standalone_slabs.length - 1];
      const newMin = last ? (Number(last.max_target) + 1) : 0;
      return {
        ...f,
        standalone_slabs: [...f.standalone_slabs, { min_target: newMin, max_target: 0, payout_type: "fixed", payout_value: 0 }],
      };
    });
  };

  const updateStandaloneSlab = (si, field, val) => {
    setForm(f => {
      const slabs = [...f.standalone_slabs];
      slabs[si] = { ...slabs[si], [field]: field === "payout_type" ? val : Number(val) };
      return { ...f, standalone_slabs: slabs };
    });
  };

  const removeStandaloneSlab = (si) => {
    setForm(f => ({ ...f, standalone_slabs: f.standalone_slabs.filter((_, i) => i !== si) }));
  };

  const handleTemplateChange = (templateId) => {
    setForm(f => ({ ...f, kpi_template_id: templateId, selected_kpis: [], kpi_configs: [] }));
  };

  const openCreate = () => { setForm(EMPTY_FORM); setEditId(null); setShowForm(true); };

  const openEdit = (p) => {
    const templateKpiItems = (() => {
      const templateId = p.kpi_template_id?._id || p.kpi_template_id;
      const tpl = kpiTemplates.find(t => t._id === templateId);
      return tpl?.kpi_items || [];
    })();

    const configs = (p.kpi_configs || []).map(c => {
      let program_targets = Array.isArray(c.program_targets) && c.program_targets.length > 0 ? c.program_targets : [];
      if (program_targets.length === 0 && c.is_admission_kpi) {
        const templateKpi = templateKpiItems.find(k => k.kpi_name === c.kpi_name);
        if (templateKpi?.program_targets?.length > 0) program_targets = templateKpi.program_targets;
      }
      const existing_program_slabs = c.program_slabs || [];
      const program_slabs = program_targets.map(pt => {
        const existing = existing_program_slabs.find(ps => ps.program_id === pt.program_id);
        return existing ? existing : { program_id: pt.program_id, program_name: pt.program_name, slabs: [] };
      });
      return { ...c, is_admission_kpi: c.is_admission_kpi || false, program_targets, program_slabs, slabs: c.slabs || [] };
    });

    setForm({
      name: p.name,
      description: p.description || "",   // 🆕
      department: p.department,
      plan_type: p.plan_type ?? "kpi_linked",
      period_type: p.period_type || "Monthly",
      period_month: p.period_month || new Date().getMonth() + 1,
      period_quarter: p.period_quarter || "Q1",
      period_half: p.period_half || "H1",
      period_year: p.period_year || CURRENT_YEAR,
      kpi_template_id: p.kpi_template_id?._id || p.kpi_template_id || "",
      selected_kpis: configs.map(c => c.kpi_name),
      kpi_configs: configs,
      completion_reward_type: p.completion_reward_type || "none",
      completion_reward_value: p.completion_reward_value || 0,
      completion_reward_label: p.completion_reward_label || "",
      standalone_payout_type: p.standalone_payout_type || "fixed",
      standalone_payout_value: p.standalone_payout_value || 0,
      standalone_metric: p.standalone_metric || "manual",
      standalone_metric_label: p.standalone_metric_label || "",
      standalone_target_type: p.standalone_target_type || "revenue",
      standalone_slabs: p.standalone_slabs || [],
      slabs: p.slabs || [],
    });
    setEditId(p._id);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.department) {
      showToast("Plan name & department are required", "error"); return;
    }
    if (form.plan_type === "kpi_linked") {
      if (!form.kpi_template_id) { showToast("Please select a KPI template", "error"); return; }
      if (form.kpi_configs.length === 0) { showToast("Select at least one KPI", "error"); return; }
    }
    if (form.plan_type === "standalone") {
      const errs = validateStandaloneSlabs(form.standalone_slabs);
      if (errs.length) { showToast(errs[0], "error"); return; }
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name, description: form.description,
        department: form.department, plan_type: form.plan_type,
        period_type: form.period_type,
        period_month: form.period_type === "Monthly" ? form.period_month : null,
        period_quarter: form.period_type === "Quarterly" ? form.period_quarter : null,
        period_half: form.period_type === "Half-Yearly" ? form.period_half : null,
        period_year: form.period_year,
        ...(form.plan_type === "kpi_linked" ? {
          kpi_template_id: form.kpi_template_id,
          kpi_configs: form.kpi_configs,
          completion_reward_type: form.completion_reward_type,
          completion_reward_value: form.completion_reward_value,
          completion_reward_label: form.completion_reward_label,
        } : {
          standalone_metric: form.standalone_metric,
          standalone_metric_label: form.standalone_metric_label,
          standalone_payout_type: form.standalone_payout_type,
          standalone_payout_value: form.standalone_payout_value,
          standalone_target_type: form.standalone_target_type,
          standalone_slabs: form.standalone_slabs,
        }),
      };

      if (editId) await axios.put(`${API_BASE}/api/incentive-plans/${editId}`, payload);
      else await axios.post(`${API_BASE}/api/incentive-plans`, payload);

      showToast(editId ? "Plan updated ✅" : "Plan created ✅");
      setShowForm(false);
      fetchAll();
    } catch (err) {
      showToast(err.response?.data?.message || "Save failed", "error");
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this plan?")) return;
    try {
      await axios.delete(`${API_BASE}/api/incentive-plans/${id}`);
      showToast("Deleted ✅"); fetchAll();
    } catch { showToast("Delete failed", "error"); }
  };

  const totalWeight = form.kpi_configs.reduce((s, c) => s + (c.weight || 0), 0);
  const totalTemplateKpis = selectedTemplate?.kpi_items?.length || 0;

   const filteredPlans = plans.filter(p =>
    !pageSearch.trim() ||
    p.name?.toLowerCase().includes(pageSearch.toLowerCase()) ||
    p.department?.toLowerCase().includes(pageSearch.toLowerCase()) ||
    p.kpi_template_id?.template_name?.toLowerCase().includes(pageSearch.toLowerCase())
  );
  
  return (
    <div style={{ padding: "28px 32px", fontFamily: "'Segoe UI',sans-serif", minHeight: "100vh", background: "#f4f6fb" }}>
      <style>{`
        @keyframes spin    { to { transform: rotate(360deg); } }
        @keyframes fadeIn  { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
        .plan-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.08); transform: translateY(-1px); }
        input:focus, select:focus { border-color: #6366f1 !important; box-shadow: 0 0 0 3px rgba(99,102,241,0.1); }
        .checkbox-kpi:hover { background: #f8fafc; }
      `}</style>

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", top: 20, right: 20, zIndex: 9999, background: toast.type === "error" ? "#ef4444" : "#22c55e", color: "#fff", padding: "12px 20px", borderRadius: 10, fontWeight: 600, fontSize: 14, boxShadow: "0 8px 24px rgba(0,0,0,0.15)", animation: "fadeIn 0.2s ease" }}>
          {toast.msg}
        </div>
      )}

      {/* Page Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#1e293b" }}>Incentive Plans</h2>
          <p style={{ margin: "4px 0 0", color: "#64748b", fontSize: 14 }}>Configure KPI-linked or standalone incentive rules per department</p>
        </div>
        <button onClick={openCreate} style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 20px", background: "#4f46e5", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 14, cursor: "pointer", boxShadow: "0 2px 8px rgba(79,70,229,0.3)" }}>
          <HugeiconsIcon icon={PlusSignIcon} size={16} color="#fff" strokeWidth={2.5} />
          New Plan
        </button>
      </div>
          <input
        value={pageSearch}
        onChange={e => setPageSearch(e.target.value)}
        placeholder="🔍 Search plans by name, department, or template..."
        style={{ ...inp, marginBottom: 20, maxWidth: 400 }}
      />

      {/* Summary Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 14, marginBottom: 24 }}>
        {[
          { label: "Total Plans", value: plans.length, color: "#4f46e5" },
          { label: "KPI-Linked", value: plans.filter(p => p.plan_type === "kpi_linked").length, color: "#7c3aed" },
          { label: "Standalone", value: plans.filter(p => p.plan_type === "standalone").length, color: "#d97706" },
          { label: "Departments", value: [...new Set(plans.map(p => p.department))].length, color: "#16a34a" },
        ].map(s => (
          <div key={s.label} style={{ background: "#fff", borderRadius: 12, padding: "16px 20px", border: "1px solid #e2e8f0" }}>
            <p style={{ margin: "0 0 4px", fontSize: 11, color: "#94a3b8", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em" }}>{s.label}</p>
            <p style={{ margin: 0, fontSize: 26, fontWeight: 800, color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Plan Cards */}
      {loading ? (
        <div style={{ textAlign: "center", padding: 80, color: "#64748b" }}>
          <div style={{ width: 36, height: 36, border: "4px solid #e2e8f0", borderTopColor: "#4f46e5", borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 12px" }} />
          Loading plans...
        </div>
      ) : plans.length === 0 ? (
        <div style={{ textAlign: "center", padding: 80, background: "#fff", borderRadius: 14, border: "1px solid #e2e8f0", color: "#94a3b8" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>📋</div>
          <p style={{ fontWeight: 700, fontSize: 16, margin: "0 0 6px", color: "#475569" }}>No plans yet</p>
          <p style={{ fontSize: 13, margin: 0 }}>Click "New Plan" to define your first department incentive rule</p>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(340px,1fr))", gap: 16 }}>
         {filteredPlans.map(plan => {
            const { color, bg } = getColor(plan.department);
            const isKpi = plan.plan_type === "kpi_linked";
            const period = periodLabel(plan);
            return (
              <div key={plan._id} className="plan-card" style={{ background: "#fff", borderRadius: 14, border: "1px solid #e2e8f0", overflow: "hidden", transition: "all 0.15s" }}>
                <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <HugeiconsIcon icon={Building04Icon} size={20} color={color} strokeWidth={1.8} />
                    </div>
                    <div>
                      <p style={{ margin: 0, fontWeight: 800, fontSize: 15, color: "#1e293b" }}>{plan.name}</p>
                      {plan.description && (
                        <p style={{ margin: "2px 0 4px", fontSize: 12, color: "#64748b", lineHeight: 1.4 }}>
                          {plan.description}
                        </p>
                      )}
                      <p style={{ margin: "3px 0 0", fontSize: 12, display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                        <span style={{ background: bg, color, fontWeight: 700, padding: "1px 8px", borderRadius: 5, fontSize: 11 }}>{plan.department}</span>
                        <span style={{ color: "#94a3b8", display: "flex", alignItems: "center", gap: 3 }}>
                          <HugeiconsIcon icon={Calendar01Icon} size={11} color="#94a3b8" strokeWidth={2} />
                          {period}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20, background: isKpi ? "#ede9fe" : "#fef9c3", color: isKpi ? "#7c3aed" : "#a16207" }}>
                      {isKpi ? "🔗 KPI-Linked" : "📋 Standalone"}
                    </span>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={() => openEdit(plan)} style={{ background: "#eff6ff", border: "none", borderRadius: 7, padding: "6px 10px", cursor: "pointer" }}>
                        <HugeiconsIcon icon={PencilEdit01Icon} size={14} color="#2563eb" strokeWidth={2} />
                      </button>
                      <button onClick={() => handleDelete(plan._id)} style={{ background: "#fef2f2", border: "none", borderRadius: 7, padding: "6px 10px", cursor: "pointer" }}>
                        <HugeiconsIcon icon={Delete02Icon} size={14} color="#dc2626" strokeWidth={2} />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Card body */}
                {isKpi ? (
                  <div style={{ padding: "12px 20px" }}>
                    {plan.kpi_template_id && (
                      <p style={{ margin: "0 0 8px", fontSize: 12, color: "#7c3aed", fontWeight: 700 }}>
                        🎯 {plan.kpi_template_id?.template_name} · {plan.kpi_configs?.length || 0} KPIs configured
                      </p>
                    )}
                    {(plan.kpi_configs || []).slice(0, 3).map((cfg, i) => (
                      <div key={i} style={{ padding: "4px 0", borderBottom: "1px dashed #f1f5f9", fontSize: 12 }}>
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                          <span style={{ color: "#475569", fontWeight: 500 }}>{cfg.kpi_name}</span>
                          <span style={{ color: "#64748b" }}>{cfg.rule_label || "—"}</span>
                        </div>
                      </div>
                    ))}
                    {plan.kpi_configs?.length > 3 && (
                      <p style={{ margin: "6px 0 0", fontSize: 11, color: "#94a3b8" }}>+{plan.kpi_configs.length - 3} more KPIs</p>
                    )}
                  </div>
                ) : (
                  <div style={{ padding: "12px 20px" }}>
                    {/* Standalone slab preview on card */}
                    {(plan.standalone_slabs || []).length > 0 ? (
                      <div>
                        <p style={{ margin: "0 0 6px", fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase" }}>
                          {STANDALONE_TARGET_TYPES.find(t => t.value === plan.standalone_target_type)?.icon || "💰"} Slab Structure
                        </p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                          {(plan.standalone_slabs || []).slice(0, 4).map((slab, si) => (
                            <span key={si} style={{ fontSize: 11, background: "#f0fdf4", color: "#15803d", padding: "3px 10px", borderRadius: 20, fontWeight: 600, border: "1px solid #86efac" }}>
                              {formatTarget(slab.min_target, plan.standalone_target_type)} →{" "}
                              {slab.payout_type === "fixed"
                                ? `₹${Number(slab.payout_value).toLocaleString("en-IN")}`
                                : slab.payout_type === "per_unit"
                                  ? `₹${Number(slab.payout_value).toLocaleString("en-IN")}/unit`
                                  : `${slab.payout_value}%`}
                            </span>
                          ))}
                          {(plan.standalone_slabs || []).length > 4 && (
                            <span style={{ fontSize: 11, color: "#94a3b8" }}>+{plan.standalone_slabs.length - 4} more</span>
                          )}
                        </div>
                      </div>
                    ) : (
                      <p style={{ margin: 0, fontSize: 12, color: "#92400e", fontWeight: 700 }}>
                        💰 {plan.standalone_payout_type === "percentage"
                          ? `${plan.standalone_payout_value}% of Salary`
                          : `₹${Number(plan.standalone_payout_value).toLocaleString("en-IN")} Fixed`}
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════
          MODAL
      ════════════════════════════════════════════════════════════ */}
      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ background: "#fff", borderRadius: 18, width: "100%", maxWidth: 700, maxHeight: "93vh", overflowY: "auto", boxShadow: "0 24px 64px rgba(0,0,0,0.22)", animation: "fadeIn 0.2s ease" }}>

            <div style={{ padding: "20px 26px", borderBottom: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#fff", zIndex: 10, borderRadius: "18px 18px 0 0" }}>
              <div>
                <h3 style={{ margin: 0, fontSize: 17, fontWeight: 800, color: "#1e293b" }}>
                  {editId ? "Edit Incentive Plan" : "New Incentive Plan"}
                </h3>
                <p style={{ margin: "2px 0 0", fontSize: 12, color: "#94a3b8" }}>Configure KPI targets, slabs & rewards</p>
              </div>
              <button onClick={() => setShowForm(false)} style={{ background: "#f1f5f9", border: "none", borderRadius: 8, padding: "6px 14px", cursor: "pointer", fontWeight: 700, fontSize: 14, color: "#475569" }}>✕</button>
            </div>

            <div style={{ padding: "22px 26px", display: "flex", flexDirection: "column", gap: 24 }}>

              {/* STEP 1: Basic Info */}
              <Section step={1} title="Basic Information" icon="📝">
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                  <div style={{ gridColumn: "1/-1" }}>
                    <label style={lbl}>Plan Name *</label>
                    <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Sales Q1 2025 Incentive" style={inp} />
                  </div>
                  <div style={{ gridColumn: "1/-1" }}>
                    <label style={lbl}>Description</label>
                    <textarea
                      value={form.description}
                      onChange={e => setForm({ ...form, description: e.target.value })}
                      placeholder="e.g. Project Report Successfully Avail Your Incentive."
                      rows={2}
                      style={{ ...inp, resize: "vertical", fontFamily: "inherit" }}
                    />
                  </div>
                  <div>
                    <label style={lbl}>Department *</label>
                    <SearchableSelect
                      options={depts.map(d => ({ value: d, label: d }))}
                      value={form.department}
                      onChange={(v) => setForm(f => ({ ...f, department: v, kpi_template_id: "", selected_kpis: [], kpi_configs: [] }))}
                      placeholder="Search department..."
                    />
                  </div>
                  <div>
                    <label style={lbl}>Plan Type *</label>
                    <div style={{ display: "flex", gap: 8 }}>
                      {[{ val: "kpi_linked", label: "🔗 KPI-Linked" }, { val: "standalone", label: "📋 Standalone" }].map(opt => (
                        <div key={opt.val} onClick={() => setForm(f => ({ ...f, plan_type: opt.val }))}
                          style={{ flex: 1, padding: "9px 12px", borderRadius: 9, cursor: "pointer", textAlign: "center", fontSize: 13, fontWeight: 700, transition: "all 0.15s", border: form.plan_type === opt.val ? "2px solid #4f46e5" : "2px solid #e2e8f0", background: form.plan_type === opt.val ? "#eef2ff" : "#fafafa", color: form.plan_type === opt.val ? "#4f46e5" : "#64748b" }}>
                          {opt.label}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Section>

              {/* STEP 2: Time Period */}
              <Section step={2} title="Time Period" icon="📅">
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 12 }}>
                  <div>
                    <label style={lbl}>Period Type</label>
                    <select value={form.period_type} onChange={e => setForm({ ...form, period_type: e.target.value })} style={inp}>
                      <option>Monthly</option><option>Quarterly</option><option>Half-Yearly</option><option>Yearly</option>
                    </select>
                  </div>
                  {form.period_type === "Monthly" && (
                    <div>
                      <label style={lbl}>Month</label>
                      <select value={form.period_month} onChange={e => setForm({ ...form, period_month: Number(e.target.value) })} style={inp}>
                        {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
                      </select>
                    </div>
                  )}
                  {form.period_type === "Quarterly" && (
                    <div>
                      <label style={lbl}>Quarter</label>
                      <select value={form.period_quarter} onChange={e => setForm({ ...form, period_quarter: e.target.value })} style={inp}>
                        {["Q1", "Q2", "Q3", "Q4"].map(q => <option key={q}>{q}</option>)}
                      </select>
                    </div>
                  )}
                  {form.period_type === "Half-Yearly" && (
                    <div>
                      <label style={lbl}>Half</label>
                      <select value={form.period_half} onChange={e => setForm({ ...form, period_half: e.target.value })} style={inp}>
                        <option>H1</option><option>H2</option>
                      </select>
                    </div>
                  )}
                  <div>
                    <label style={lbl}>Year</label>
                    <select value={form.period_year} onChange={e => setForm({ ...form, period_year: Number(e.target.value) })} style={inp}>
                      {YEARS.map(y => <option key={y}>{y}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ marginTop: 10, display: "inline-flex", alignItems: "center", gap: 6, background: "#eef2ff", borderRadius: 20, padding: "5px 14px", fontSize: 13, fontWeight: 700, color: "#4f46e5" }}>
                  <HugeiconsIcon icon={Calendar01Icon} size={14} color="#4f46e5" strokeWidth={2} />
                  Period: {periodLabel(form)}
                </div>
              </Section>

              {/* ═══════════════════════════════════════════════════
                  KPI-LINKED STEPS (unchanged)
              ═══════════════════════════════════════════════════ */}
              {form.plan_type === "kpi_linked" && (<>
                <Section step={3} title="Select KPIs" icon="🎯">
                  <div style={{ marginBottom: 14 }}>
                    <label style={lbl}>KPI Template *</label>
                    <SearchableSelect
                      options={filteredTemplates.map(t => ({ value: t._id, label: t.template_name, sublabel: t.role }))}
                      value={form.kpi_template_id}
                      onChange={(v) => handleTemplateChange(v)}
                      placeholder={!form.department ? "Select department first" : "Search KPI template..."}
                      disabled={!form.department}
                    />
                  </div>
                  {selectedTemplate && (<>
                    <p style={{ margin: "0 0 10px", fontSize: 12, color: "#64748b" }}>Check the KPIs you want to include:</p>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                      {selectedTemplate.kpi_items?.map(item => {
                        const isChecked = form.selected_kpis.includes(item.kpi_name);
                        return (
                          <div key={item.kpi_name} className="checkbox-kpi" onClick={() => toggleKpi(item)}
                            style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderRadius: 10, transition: "all 0.15s", border: isChecked ? "2px solid #4f46e5" : "2px solid #e2e8f0", background: isChecked ? "#eef2ff" : "#fafafa", cursor: "pointer", userSelect: "none" }}>
                            <div style={{ width: 20, height: 20, borderRadius: 5, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", border: isChecked ? "2px solid #4f46e5" : "2px solid #cbd5e1", background: isChecked ? "#4f46e5" : "#fff" }}>
                              {isChecked && <span style={{ color: "#fff", fontSize: 12, fontWeight: 800 }}>✓</span>}
                            </div>
                            <span style={{ flex: 1, fontSize: 13, fontWeight: isChecked ? 700 : 500, color: isChecked ? "#3730a3" : "#475569" }}>{item.kpi_name}</span>
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                              <div style={{ width: 60, height: 5, background: "#e2e8f0", borderRadius: 99, overflow: "hidden" }}>
                                <div style={{ width: `${item.weight}%`, height: "100%", borderRadius: 99, background: isChecked ? "#4f46e5" : "#94a3b8" }} />
                              </div>
                              <span style={{ fontSize: 12, fontWeight: 700, minWidth: 32, color: isChecked ? "#4f46e5" : "#94a3b8" }}>{item.weight}%</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    {form.selected_kpis.length > 0 && (
                      <div style={{ marginTop: 12, padding: "10px 14px", borderRadius: 9, display: "flex", justifyContent: "space-between", alignItems: "center", background: totalWeight === 100 ? "#f0fdf4" : "#fff7ed", border: `1px solid ${totalWeight === 100 ? "#86efac" : "#fed7aa"}` }}>
                        <span style={{ fontSize: 12, fontWeight: 600, color: totalWeight === 100 ? "#15803d" : "#c2410c" }}>
                          {totalWeight === 100 ? "✅ Weight total is 100%" : `⚠ Selected weight total: ${totalWeight}%`}
                        </span>
                        <span style={{ fontSize: 12, color: "#64748b" }}>{form.selected_kpis.length} / {totalTemplateKpis} KPIs selected</span>
                      </div>
                    )}
                  </>)}
                </Section>

                {form.kpi_configs.length > 0 && (
                  <Section step={4} title="Configure Each KPI" icon="⚙️">
                    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                      {form.kpi_configs.map(cfg => {
                        const isAdm = cfg.is_admission_kpi;
                        return (
                          <div key={cfg.kpi_name} style={{ border: `1.5px solid ${isAdm ? "#bae6fd" : "#e2e8f0"}`, borderRadius: 12, overflow: "hidden" }}>
                            <div style={{ padding: "12px 16px", background: isAdm ? "#f0f9ff" : "#f8fafc", borderBottom: `1px solid ${isAdm ? "#bae6fd" : "#e2e8f0"}`, display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                              <HugeiconsIcon icon={Target01Icon} size={16} color={isAdm ? "#0369a1" : "#4f46e5"} strokeWidth={2} />
                              <span style={{ fontWeight: 800, fontSize: 14, color: "#1e293b" }}>{cfg.kpi_name}</span>
                              <span style={{ fontSize: 11, padding: "2px 8px", background: isAdm ? "#e0f2fe" : "#eef2ff", color: isAdm ? "#0369a1" : "#4f46e5", borderRadius: 20, fontWeight: 700 }}>Weight: {cfg.weight}%</span>
                            </div>
                            <div style={{ padding: "14px 16px", display: "flex", flexDirection: "column", gap: 12 }}>
                              {isAdm ? (
                                <AdmissionKpiConfig
                                  key={`${cfg.kpi_name}-${(cfg.program_targets || []).map(pt => pt.program_id).join("-")}`}
                                  cfg={cfg}
                                  onAddProgSlab={addProgSlab}
                                  onUpdateProgSlab={updateProgSlab}
                                  onRemoveProgSlab={removeProgSlab}
                                />
                              ) : (
                                <>
                                  <div style={{ display: "grid", gridTemplateColumns: "1fr 140px 150px", gap: 10 }}>
                                    <div>
                                      <label style={lbl}>Target Value *</label>
                                      <input value={cfg.target} onChange={e => updateKpiConfig(cfg.kpi_name, "target", e.target.value)} placeholder="e.g. 120" style={inp} />
                                    </div>
                                    <div>
                                      <label style={lbl}>Value Type</label>
                                      <select value={cfg.value_type} onChange={e => updateKpiConfig(cfg.kpi_name, "value_type", e.target.value)} style={inp}>
                                        {VALUE_TYPES.map(vt => <option key={vt.value} value={vt.value}>{vt.label}</option>)}
                                      </select>
                                    </div>
                                    <div>
                                      <label style={lbl}>Operator</label>
                                      <select value={cfg.operator} onChange={e => updateKpiConfig(cfg.kpi_name, "operator", e.target.value)} style={inp}>
                                        {OPERATORS.map(op => <option key={op.value} value={op.value}>{op.label}</option>)}
                                      </select>
                                    </div>
                                  </div>
                                  {cfg.rule_label && (
                                    <div style={{ padding: "8px 12px", background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 8, fontSize: 12, fontWeight: 700, color: "#15803d" }}>
                                      📌 Rule: Achieve <strong>{cfg.kpi_name}</strong> {cfg.rule_label}
                                    </div>
                                  )}
                                  <SlabEditor
                                    slabs={cfg.slabs}
                                    cfg={cfg}
                                    onAdd={() => addSlabToKpi(cfg.kpi_name)}
                                    onUpdate={(si, field, val) => updateKpiSlab(cfg.kpi_name, si, field, val)}
                                    onRemove={(si) => removeKpiSlab(cfg.kpi_name, si)}
                                  />
                                </>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </Section>
                )}

                {form.kpi_configs.length > 0 && (
                  <Section step={5} title="Completion Reward" icon="🏆">
                    <div style={{ background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "12px 14px", marginBottom: 14 }}>
                      <p style={{ margin: 0, fontSize: 13, color: "#92400e", fontWeight: 600 }}>
                        🎯 If an employee achieves <strong>100%</strong> across <strong>ALL KPIs</strong>, award this bonus reward:
                      </p>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                      <div>
                        <label style={lbl}>Reward Type</label>
                        <select value={form.completion_reward_type} onChange={e => setForm({ ...form, completion_reward_type: e.target.value })} style={inp}>
                          <option value="none">No Reward</option>
                          <option value="fixed">Fixed Amount ₹</option>
                          <option value="percentage">% of Salary</option>
                        </select>
                      </div>
                      {form.completion_reward_type !== "none" && (<>
                        <div>
                          <label style={lbl}>{form.completion_reward_type === "fixed" ? "Amount (₹)" : "Percentage (%)"}</label>
                          <input type="number" min="0" value={form.completion_reward_value}
                            onChange={e => setForm({ ...form, completion_reward_value: Number(e.target.value) })}
                            style={inp} />
                        </div>
                        <div>
                          <label style={lbl}>Reward Label</label>
                          <input value={form.completion_reward_label}
                            onChange={e => setForm({ ...form, completion_reward_label: e.target.value })}
                            placeholder="e.g. Star Performer Bonus" style={inp} />
                        </div>
                      </>)}
                    </div>
                  </Section>
                )}
              </>)}

              {/* ═══════════════════════════════════════════════════
                  STANDALONE — NEW SLAB-BASED CONFIG
              ═══════════════════════════════════════════════════ */}
              {form.plan_type === "standalone" && (
                <>
                  <Section step={3} title="Metric & Target Type" icon="📊">
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                      <div>
                        <label style={lbl}>Metric / Trigger</label>
                        <select value={form.standalone_metric} onChange={e => setForm({ ...form, standalone_metric: e.target.value })} style={inp}>
                          <option value="manual">Manual Entry</option>
                          <option value="attendance">Attendance %</option>
                          <option value="custom">Custom Metric</option>
                        </select>
                      </div>
                      {form.standalone_metric === "custom" && (
                        <div>
                          <label style={lbl}>Custom Metric Name</label>
                          <input value={form.standalone_metric_label}
                            onChange={e => setForm({ ...form, standalone_metric_label: e.target.value })}
                            placeholder="e.g. Sales Revenue" style={inp} />
                        </div>
                      )}
                    </div>

                    {/* Target type selector */}
                    <div style={{ marginTop: 16 }}>
                      <label style={lbl}>Target Measurement Type</label>
                      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                        {STANDALONE_TARGET_TYPES.map(t => (
                          <div
                            key={t.value}
                            onClick={() => setForm(f => ({ ...f, standalone_target_type: t.value, standalone_slabs: [] }))}
                            style={{
                              flex: 1, minWidth: 120, padding: "12px 14px", borderRadius: 10, cursor: "pointer",
                              textAlign: "center", transition: "all 0.15s",
                              border: form.standalone_target_type === t.value ? "2px solid #4f46e5" : "2px solid #e2e8f0",
                              background: form.standalone_target_type === t.value ? "#eef2ff" : "#fafafa",
                            }}
                          >
                            <div style={{ fontSize: 22, marginBottom: 4 }}>{t.icon}</div>
                            <div style={{ fontSize: 12, fontWeight: 700, color: form.standalone_target_type === t.value ? "#4f46e5" : "#64748b" }}>{t.label}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Section>

                  <Section step={4} title="Payout Slabs" icon="💰">
                    <div style={{ background: "#f0f9ff", border: "1px solid #bae6fd", borderRadius: 10, padding: "12px 14px", marginBottom: 16 }}>
                      <p style={{ margin: 0, fontSize: 13, color: "#0369a1", fontWeight: 600 }}>
                        💡 Define target ranges and the payout for each range.
                        Example: ₹0–₹1L → ₹1,000 | ₹1L–₹2L → ₹2,000 | ₹2L+ → ₹5,000
                      </p>
                    </div>
                    <StandaloneSlabEditor
                      slabs={form.standalone_slabs}
                      targetType={form.standalone_target_type}
                      onAdd={addStandaloneSlab}
                      onUpdate={updateStandaloneSlab}
                      onRemove={removeStandaloneSlab}
                    />
                  </Section>
                </>
              )}

              {/* Actions */}
              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", borderTop: "1px solid #f1f5f9", paddingTop: 16 }}>
                <button onClick={() => setShowForm(false)} style={{ padding: "10px 20px", background: "#f1f5f9", border: "none", borderRadius: 9, fontWeight: 700, fontSize: 14, cursor: "pointer", color: "#475569" }}>Cancel</button>
                <button onClick={handleSave} disabled={saving}
                  style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 24px", color: "#fff", border: "none", borderRadius: 9, fontWeight: 700, fontSize: 14, background: saving ? "#a5b4fc" : "#4f46e5", cursor: saving ? "not-allowed" : "pointer" }}>
                  <HugeiconsIcon icon={CheckmarkCircle01Icon} size={16} color="#fff" strokeWidth={2} />
                  {saving ? "Saving..." : editId ? "Update Plan" : "Create Plan"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ step, title, icon, children }) {
  return (
    <div style={{ border: "1.5px solid #e2e8f0", borderRadius: 14, overflow: "hidden" }}>
      <div style={{ padding: "12px 18px", background: "#f8fafc", borderBottom: "1.5px solid #e2e8f0", display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#4f46e5", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: "#fff", flexShrink: 0 }}>{step}</div>
        <span style={{ fontSize: 14, fontWeight: 800, color: "#1e293b" }}>{icon} {title}</span>
      </div>
      <div style={{ padding: "16px 18px" }}>{children}</div>
    </div>
  );
}