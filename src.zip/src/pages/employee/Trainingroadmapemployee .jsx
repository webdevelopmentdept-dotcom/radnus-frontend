import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";
import EmployeeLayout from "./EmployeeLayout";
import {
  BookOpen, Award, CheckCircle2, Clock, AlertTriangle,
  Target, GraduationCap, ChevronRight, Check, Star,
  Calendar, Layers, Info, RefreshCw, Zap, TrendingUp,
  FileText, Users, BarChart2,
} from "lucide-react";

const API_BASE = import.meta.env.VITE_API_BASE_URL;

// ─── Global Styles ─────────────────────────────────────────────
const STYLES = `
  @keyframes fadeUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
  @keyframes spin   { to{transform:rotate(360deg)} }

  .tr-page { padding: 24px 28px; min-height: 100vh; background: #f4f6fb; font-family: 'Segoe UI', sans-serif; }

  @media (max-width: 768px) {
    .tr-page { padding: 14px !important; }
    .tr-header-row { flex-direction: column !important; align-items: flex-start !important; gap: 10px !important; }
    .tr-stats-grid { grid-template-columns: repeat(3, 1fr) !important; }
    .tr-tabs { flex-wrap: wrap !important; }
    .tr-tabs button { font-size: 11px !important; padding: 6px 10px !important; }
    .tr-cards-grid { grid-template-columns: 1fr !important; }
    .tr-roadmap-header { flex-direction: column !important; align-items: flex-start !important; gap: 8px !important; }
    .tr-table-wrap { overflow-x: auto !important; }
  }

  @media (max-width: 480px) {
    .tr-stats-grid { grid-template-columns: repeat(2, 1fr) !important; }
    .tr-tabs button { flex: 1 !important; justify-content: center !important; }
  }
`;

// ─── Constants ─────────────────────────────────────────────────
const STATUS_CONFIG = {
  pending:     { label: "Pending",     color: "#6b7280", bg: "#f3f4f6" },
  in_progress: { label: "In Progress", color: "#3b82f6", bg: "#eff6ff" },
  completed:   { label: "Completed",   color: "#10b981", bg: "#ecfdf5" },
  overdue:     { label: "Overdue",     color: "#ef4444", bg: "#fef2f2" },
  waived:      { label: "Waived",      color: "#8b5cf6", bg: "#f5f3ff" },
  needs_hr_review: { label: "Needs HR Review",  color: "#dc2626", bg: "#fef2f2" }, // ✅ NEW
};

const TYPE_CONFIG = {
  induction:        { label: "Induction",       color: "#3b82f6" },
  job_role:         { label: "Job Role",         color: "#8b5cf6" },
  cross_functional: { label: "Cross-Functional", color: "#f59e0b" },
  culture:          { label: "Culture",          color: "#10b981" },
  refresher:        { label: "Refresher",        color: "#6b7280" },
  department:       { label: "Department",       color: "#ef4444" },
};

function getEmployeeId() {
  return (
    localStorage.getItem("employee_id") ||
    localStorage.getItem("employeeId")  ||
    localStorage.getItem("emp_id")      ||
    null
  );
}

// ─── Training Card ──────────────────────────────────────────────
function TrainingCard({ record, onStart, onViewDetails }) {
  const st  = STATUS_CONFIG[record.status] || STATUS_CONFIG.pending;
  const typ = TYPE_CONFIG[record.programId?.type] || TYPE_CONFIG.job_role;
  const isOverdue = record.dueDate && new Date(record.dueDate) < new Date() && record.status !== "completed";
  const prog = record.programId;

  return (
    <div style={{
      background: "#fff", borderRadius: 13, padding: "16px",
      borderLeft: `4px solid ${isOverdue ? "#ef4444" : st.color}`,
      boxShadow: "0 1px 4px rgba(0,0,0,.06)", height: "100%",
      boxSizing: "border-box",
    }}>
      {/* Top badges */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8, flexWrap: "wrap", gap: 4 }}>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <span style={{ background: typ.color, color: "#fff", borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700 }}>{typ.label}</span>
          <span style={{ background: isOverdue ? "#fef2f2" : st.bg, color: isOverdue ? "#ef4444" : st.color, border: `1px solid ${isOverdue ? "#ef4444" : st.color}33`, borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700 }}>
            {isOverdue ? "Overdue" : st.label}
          </span>
          {record.certificationIssued && (
            <span style={{ background: "#fffbeb", color: "#92400e", border: "1px solid #fde68a", borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700, display: "flex", alignItems: "center", gap: 3 }}>
              <Award size={9} /> Certified
            </span>
          )}
        </div>
        {prog?.duration && <span style={{ fontSize: 11, color: "#9ca3af" }}>{prog.duration}</span>}
      </div>

      {/* Title */}
      <p style={{ margin: "0 0 6px", fontWeight: 700, fontSize: 14, color: "#111827" }}>{prog?.title}</p>

      {/* Modules */}
      {prog?.modules?.length > 0 && (
        <div style={{ marginBottom: 8 }}>
          {prog.modules.slice(0, 3).map((m, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 5 }}>
              <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#9ca3af", flexShrink: 0 }} />
              <span style={{ fontSize: 12, color: "#6b7280" }}>{m}</span>
            </div>
          ))}
          {prog.modules.length > 3 && <span style={{ fontSize: 11, color: "#9ca3af" }}>+{prog.modules.length - 3} more topics</span>}
        </div>
      )}

      {/* Certification */}
      {prog?.certification && (
        <div style={{ background: "#fffbeb", borderRadius: 7, padding: "5px 10px", marginBottom: 8, border: "1px solid #fde68a", display: "flex", alignItems: "center", gap: 5 }}>
          <Award size={11} color="#92400e" />
          <p style={{ margin: 0, fontSize: 11, color: "#92400e" }}>{prog.certification}</p>
        </div>
      )}

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8, flexWrap: "wrap", gap: 6 }}>
        <div style={{ fontSize: 11, color: "#6b7280", display: "flex", gap: 12, flexWrap: "wrap" }}>
          {record.dueDate && (
            <span style={{ color: isOverdue ? "#ef4444" : "inherit", display: "flex", alignItems: "center", gap: 3 }}>
              <Calendar size={11} /> Due: {new Date(record.dueDate).toLocaleDateString("en-IN")}
            </span>
          )}
          {record.assessmentScore !== null && record.assessmentScore !== undefined && (
            <span style={{ color: record.assessmentScore >= 80 ? "#10b981" : "#ef4444" }}>
              Score: {record.assessmentScore}%
            </span>
          )}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {/* ✅ NEW — opens the course-content modal (product list, SOPs,
              videos, procedures) for this program. */}
          <button onClick={() => onViewDetails(record)}
            style={{ padding: "5px 12px", border: "1.5px solid #3b82f6", borderRadius: 7, background: "#fff", color: "#3b82f6", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
            View Details
          </button>
          {record.status === "pending" && (
            <button onClick={() => onStart(record._id)}
              style={{ padding: "5px 12px", border: "none", borderRadius: 7, background: "#3b82f6", color: "#fff", fontSize: 11, fontWeight: 600, cursor: "pointer" }}>
              Start Training
            </button>
          )}
          {record.status === "in_progress" && (
            <span style={{ background: "#3b82f6", color: "#fff", borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 700 }}>In Progress</span>
          )}
          {record.status === "completed" && (
            <CheckCircle2 size={16} color="#10b981" />
          )}
        </div>
      </div>

      {/* Progress log */}
      {record.progressLog?.length > 0 && (
        <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid #f3f4f6" }}>
          <p style={{ margin: "0 0 3px", color: "#9ca3af", fontSize: 11 }}>Latest update:</p>
          <p style={{ margin: 0, fontSize: 12 }}>{record.progressLog[record.progressLog.length - 1]?.note}</p>
        </div>
      )}
    </div>
  );
}

// ─── Training Details Modal ──────────────────────────────────────
// Shows the actual course content for a program: for "equipment" type
// programs (the shared "Equipment Training — All Products" program),
// that means every linked product's SOP, training video, operating
// procedure, and safety instructions — plus a "Mark as Studied"
// checklist per product, and a "Take Test" button once every product
// is studied. For other program types, just the module list /
// certification info already on the card.
function TrainingDetailsModal({ record: initialRecord, onClose, onRefresh, onOpenQuiz }) {
  const [record, setRecord]     = useState(initialRecord); // local copy — updated immediately from mark-studied response
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [openProductId, setOpenProductId] = useState(null);
  const [marking, setMarking]   = useState(null); // productId currently being marked

  const prog = record.programId;
  const isEquipment = prog?.type === "equipment";

  useEffect(() => {
    if (!isEquipment || !prog?._id) { setLoading(false); return; }
    (async () => {
      try {
        const res = await axios.get(`${API_BASE}/api/training/programs/${prog._id}/products`);
        setProducts(res.data.data || []);
      } catch (e) {
        setError(e?.response?.data?.message || "Failed to load course content");
      } finally { setLoading(false); }
    })();
  }, [isEquipment, prog?._id]);

  const isStudied = (productId) =>
    !!record.productProgress?.find(p => String(p.productId) === String(productId))?.studied;

  const studiedCount = products.filter(p => isStudied(p._id)).length;
  const allStudied = products.length > 0 && studiedCount === products.length;
  const attemptsUsed = record.quizAttempts?.length || 0;
  const alreadyAttempted = attemptsUsed >= 1;

  const handleMarkStudied = async (productId) => {
    setMarking(productId);
    try {
      const res = await axios.put(`${API_BASE}/api/training/my/${record._id}/study-product`, { productId });
      setRecord(prev => ({ ...prev, ...res.data.data })); // update this modal immediately
      onRefresh?.(); // background refresh so the card list / stats stay in sync
    } catch (e) {
      // silent — the button will just stay unmarked, HR/employee can retry
    } finally {
      setMarking(null);
    }
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 9998, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div style={{ background: "#fff", borderRadius: 14, maxWidth: 640, width: "100%", maxHeight: "85vh", overflowY: "auto", padding: 22 }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <div>
            <p style={{ margin: 0, fontWeight: 800, fontSize: 17, color: "#111827" }}>{prog?.title}</p>
            {prog?.certification && <p style={{ margin: "3px 0 0", fontSize: 12, color: "#92400e" }}>🏅 {prog.certification}</p>}
          </div>
          <button onClick={onClose} style={{ border: "none", background: "none", fontSize: 20, cursor: "pointer", color: "#9ca3af", lineHeight: 1 }}>×</button>
        </div>

        {/* Non-equipment programs: nothing extra to fetch, just show what's already known */}
        {!isEquipment && (
          <div style={{ marginTop: 14 }}>
            <p style={{ fontSize: 13, color: "#374151", marginBottom: 8 }}>Modules covered:</p>
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: "#374151" }}>
              {prog?.modules?.map((m, i) => <li key={i} style={{ marginBottom: 4 }}>{m}</li>)}
            </ul>
            {prog?.conductedBy && <p style={{ fontSize: 12, color: "#6b7280", marginTop: 10 }}>Conducted by: {prog.conductedBy}</p>}
          </div>
        )}

        {/* Equipment program: list every linked product's actual content */}
        {isEquipment && (
          <div style={{ marginTop: 14 }}>
            {loading && <p style={{ fontSize: 13, color: "#9ca3af" }}>Loading course content…</p>}
            {error && <p style={{ fontSize: 13, color: "#ef4444" }}>{error}</p>}
            {!loading && !error && products.length === 0 && (
              <p style={{ fontSize: 13, color: "#9ca3af" }}>No products are linked to this training yet.</p>
            )}
            {!loading && products.length > 0 && (
              <>
                <p style={{ fontSize: 12, color: "#6b7280", marginBottom: 6 }}>
                  This training covers {products.length} product{products.length > 1 ? "s" : ""}. Tap one to see its details, then mark it studied.
                </p>

                {/* Study progress bar */}
                <div style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: "#374151" }}>Study progress</span>
                    <span style={{ fontSize: 11, fontWeight: 700, color: allStudied ? "#10b981" : "#3b82f6" }}>{studiedCount}/{products.length} studied</span>
                  </div>
                  <div style={{ height: 8, background: "#f3f4f6", borderRadius: 4, overflow: "hidden" }}>
                    <div style={{ height: "100%", background: allStudied ? "#10b981" : "#3b82f6", width: `${(studiedCount / products.length) * 100}%`, transition: "width .3s" }} />
                  </div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {products.map(p => {
                    const isOpen = openProductId === p._id;
                    const studied = isStudied(p._id);
                    return (
                      <div key={p._id} style={{ border: `1px solid ${studied ? "#a7f3d0" : "#e5e7eb"}`, borderRadius: 10, overflow: "hidden" }}>
                        <button
                          onClick={() => setOpenProductId(isOpen ? null : p._id)}
                          style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: isOpen ? "#f9fafb" : "#fff", border: "none", cursor: "pointer", textAlign: "left" }}
                        >
                          {p.images?.[0]?.url ? (
                            <img src={p.images[0].url} alt={p.productName} style={{ width: 36, height: 36, borderRadius: 7, objectFit: "cover", flexShrink: 0 }} />
                          ) : (
                            <div style={{ width: 36, height: 36, borderRadius: 7, background: "#f3f4f6", flexShrink: 0 }} />
                          )}
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <p style={{ margin: 0, fontWeight: 700, fontSize: 13, color: "#111827" }}>{p.productName}</p>
                            <p style={{ margin: 0, fontSize: 11, color: "#9ca3af" }}>{p.productCode} · {p.category} · {p.skillLevel}</p>
                          </div>
                          {studied && (
                            <span style={{ display: "flex", alignItems: "center", gap: 3, background: "#ecfdf5", color: "#10b981", borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700, flexShrink: 0 }}>
                              <CheckCircle2 size={10} /> Studied
                            </span>
                          )}
                          <ChevronRight size={16} color="#9ca3af" style={{ transform: isOpen ? "rotate(90deg)" : "none", transition: "transform .15s", flexShrink: 0 }} />
                        </button>

                        {isOpen && (
                          <div style={{ padding: "10px 12px 14px", borderTop: "1px solid #f3f4f6", fontSize: 12, color: "#374151" }}>
                            {p.trainingVideoUrl && (
                              <p style={{ margin: "0 0 8px" }}>
                                🎥 <a href={p.trainingVideoUrl} target="_blank" rel="noreferrer" style={{ color: "#3b82f6", fontWeight: 600 }}>Watch training video</a>
                              </p>
                            )}
                            {p.sopId?.fileUrl && (
                              <p style={{ margin: "0 0 8px" }}>
                                📄 <a href={p.sopId.fileUrl} target="_blank" rel="noreferrer" style={{ color: "#3b82f6", fontWeight: 600 }}>{p.sopId.title || "View SOP"}</a>
                              </p>
                            )}
                            {p.applications && (
                              <div style={{ marginBottom: 8 }}>
                                <p style={{ margin: "0 0 2px", fontWeight: 700, color: "#6b7280", fontSize: 11 }}>APPLICATIONS</p>
                                <p style={{ margin: 0 }}>{p.applications}</p>
                              </div>
                            )}
                            {p.operatingProcedure && (
                              <div style={{ marginBottom: 8 }}>
                                <p style={{ margin: "0 0 2px", fontWeight: 700, color: "#6b7280", fontSize: 11 }}>OPERATING PROCEDURE</p>
                                <p style={{ margin: 0, whiteSpace: "pre-line" }}>{p.operatingProcedure}</p>
                              </div>
                            )}
                            {p.safetyInstructions && (
                              <div>
                                <p style={{ margin: "0 0 2px", fontWeight: 700, color: "#ef4444", fontSize: 11 }}>⚠ SAFETY INSTRUCTIONS</p>
                                <p style={{ margin: 0, whiteSpace: "pre-line" }}>{p.safetyInstructions}</p>
                              </div>
                            )}
                            {!p.trainingVideoUrl && !p.sopId?.fileUrl && !p.operatingProcedure && !p.safetyInstructions && !p.applications && (
                              <p style={{ margin: 0, color: "#9ca3af" }}>No detailed content added for this product yet — check with your trainer.</p>
                            )}

                            {/* ✅ NEW — Mark as Studied */}
                            <button
                              onClick={() => handleMarkStudied(p._id)}
                              disabled={studied || marking === p._id}
                              style={{
                                marginTop: 10, padding: "6px 14px", border: "none", borderRadius: 7,
                                background: studied ? "#ecfdf5" : "#3b82f6", color: studied ? "#10b981" : "#fff",
                                fontSize: 11, fontWeight: 700, cursor: studied ? "default" : "pointer",
                                display: "flex", alignItems: "center", gap: 5,
                              }}
                            >
                              {marking === p._id ? (
                                <span style={{ width: 11, height: 11, border: "2px solid #fff", borderTopColor: "transparent", borderRadius: "50%", animation: "spin .6s linear infinite" }} />
                              ) : (
                                <CheckCircle2 size={12} />
                              )}
                              {studied ? "Studied" : "Mark as Studied"}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* ✅ NEW — Take Test panel: unlocks once every product is studied. One attempt only. */}
                <div style={{ marginTop: 16, padding: "12px 14px", borderRadius: 10, background: allStudied ? "#eff6ff" : "#f9fafb", border: `1px solid ${allStudied ? "#bfdbfe" : "#e5e7eb"}` }}>
                  {alreadyAttempted ? (
                    record.status === "completed" ? (
                      <p style={{ margin: 0, fontSize: 12, color: "#10b981", fontWeight: 600 }}>
                        ✅ You passed with {record.assessmentScore}% and your certification has been issued.
                      </p>
                    ) : (
                      <p style={{ margin: 0, fontSize: 12, color: "#dc2626", fontWeight: 600 }}>
                        You scored {record.assessmentScore}% on your one attempt — below the 70% pass mark. This has been flagged for HR review.
                      </p>
                    )
                  ) : (
                    <>
                      {!allStudied && (
                        <p style={{ margin: "0 0 8px", fontSize: 12, color: "#6b7280" }}>
                          Study all {products.length} products above to unlock the test.
                        </p>
                      )}
                      {allStudied && (
                        <p style={{ margin: "0 0 8px", fontSize: 12, color: "#1e40af" }}>
                          You get one attempt — answer carefully before submitting.
                        </p>
                      )}
                      <button
                        onClick={() => { onOpenQuiz?.(record); onClose(); }}
                        disabled={!allStudied}
                        style={{
                          padding: "8px 16px", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 700,
                          background: allStudied ? "#3b82f6" : "#e5e7eb", color: allStudied ? "#fff" : "#9ca3af",
                          cursor: allStudied ? "pointer" : "not-allowed", width: "100%",
                        }}
                      >
                        Take Test
                      </button>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Quiz Modal ────────────────────────────────────────────────
// Combined MCQ quiz pooled across every product linked to the
// record's program. Fetches fresh (shuffled) questions on open,
// submits, auto-scores server-side, and shows pass/fail + attempts.
function QuizModal({ record, onClose, onRefresh }) {
  const [questions, setQuestions] = useState([]);
  const [meta, setMeta]           = useState(null); // { passThreshold }
  const [answers, setAnswers]     = useState({}); // { questionId: selectedOptionIndex }
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult]       = useState(null); // { score, passed, status, certificationIssued }

  const loadQuiz = useCallback(async () => {
    setLoading(true); setError(null); setResult(null); setAnswers({});
    try {
      const res = await axios.get(`${API_BASE}/api/training/my/${record._id}/quiz`);
      setQuestions(res.data.data.questions || []);
      setMeta(res.data.data);
    } catch (e) {
      setError(e?.response?.data?.message || "Failed to load quiz");
    } finally { setLoading(false); }
  }, [record._id]);

  useEffect(() => { loadQuiz(); }, [loadQuiz]);

  const selectAnswer = (questionId, optionIndex) => setAnswers(a => ({ ...a, [questionId]: optionIndex }));

  const allAnswered = questions.length > 0 && questions.every(q => answers[q._id] !== undefined);

  const handleSubmit = async () => {
    if (!allAnswered) return;
    setSubmitting(true);
    try {
      const payload = { answers: questions.map(q => ({ questionId: q._id, selectedOptionIndex: answers[q._id] })) };
      const res = await axios.post(`${API_BASE}/api/training/my/${record._id}/quiz/submit`, payload);
      setResult(res.data.data);
      onRefresh?.();
    } catch (e) {
      setError(e?.response?.data?.message || "Failed to submit quiz");
    } finally { setSubmitting(false); }
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div style={{ background: "#fff", borderRadius: 14, maxWidth: 640, width: "100%", maxHeight: "88vh", overflowY: "auto", padding: 22 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
          <div>
            <p style={{ margin: 0, fontWeight: 800, fontSize: 17, color: "#111827" }}>{record.programId?.title} — Test</p>
            {meta && !result && (
              <p style={{ margin: "3px 0 0", fontSize: 12, color: "#6b7280" }}>
                Pass mark: {meta.passThreshold}% · You get one attempt — answer carefully.
              </p>
            )}
          </div>
          <button onClick={onClose} style={{ border: "none", background: "none", fontSize: 20, cursor: "pointer", color: "#9ca3af", lineHeight: 1 }}>×</button>
        </div>

        {loading && <p style={{ fontSize: 13, color: "#9ca3af", textAlign: "center", padding: "24px 0" }}>Loading test…</p>}
        {error && !loading && (
          <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 10, padding: "12px 14px", fontSize: 13, color: "#dc2626" }}>{error}</div>
        )}

        {/* ── Result screen ── */}
        {result && (
          <div style={{ textAlign: "center", padding: "20px 10px" }}>
            <div style={{
              width: 72, height: 72, borderRadius: "50%", margin: "0 auto 14px",
              background: result.passed ? "#ecfdf5" : "#fef2f2",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              {result.passed ? <Award size={32} color="#10b981" /> : <AlertTriangle size={32} color="#ef4444" />}
            </div>
            <p style={{ margin: "0 0 4px", fontWeight: 800, fontSize: 22, color: result.passed ? "#10b981" : "#ef4444" }}>{result.score}%</p>
            <p style={{ margin: "0 0 14px", fontWeight: 700, fontSize: 14, color: "#111827" }}>
              {result.passed ? "Passed! Certification issued 🎉" : `Not yet — needs ${meta?.passThreshold ?? 70}% to pass`}
            </p>
            {!result.passed && (
              <p style={{ margin: "0 0 14px", fontSize: 12, color: "#dc2626" }}>
                This has been flagged for HR review.
              </p>
            )}
            <button onClick={onClose} style={{ padding: "8px 18px", border: "1.5px solid #e5e7eb", borderRadius: 8, background: "#fff", color: "#374151", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
              Close
            </button>
          </div>
        )}

        {/* ── Question list ── */}
        {!loading && !error && !result && questions.length > 0 && (
          <>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {questions.map((q, qi) => (
                <div key={q._id} style={{ border: "1px solid #e5e7eb", borderRadius: 10, padding: "12px 14px" }}>
                  <p style={{ margin: "0 0 8px", fontWeight: 700, fontSize: 13, color: "#111827" }}>{qi + 1}. {q.questionText}</p>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    {q.options.map((o, oi) => (
                      <label key={oi} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "#374151", cursor: "pointer", padding: "6px 8px", borderRadius: 7, background: answers[q._id] === oi ? "#eff6ff" : "transparent" }}>
                        <input type="radio" name={q._id} checked={answers[q._id] === oi} onChange={() => selectAnswer(q._id, oi)} />
                        {o}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={handleSubmit}
              disabled={!allAnswered || submitting}
              style={{
                marginTop: 16, width: "100%", padding: "10px 16px", border: "none", borderRadius: 9,
                background: allAnswered ? "#3b82f6" : "#e5e7eb", color: allAnswered ? "#fff" : "#9ca3af",
                fontSize: 13, fontWeight: 700, cursor: allAnswered ? "pointer" : "not-allowed",
              }}
            >
              {submitting ? "Submitting…" : `Submit Test (${Object.keys(answers).length}/${questions.length} answered)`}
            </button>
          </>
        )}
      </div>
    </div>
  );
}


export default function TrainingRoadmapEmployee() {
  const [records, setRecords]     = useState([]);
  const [stats, setStats]         = useState(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState(null);
  const [toast, setToast]         = useState(null);
  const [activeTab, setActiveTab] = useState("my_trainings");
  const [detailsRecord, setDetailsRecord] = useState(null); // ✅ NEW — record shown in the details modal, or null
  const [quizRecord, setQuizRecord] = useState(null); // ✅ NEW — record whose quiz is open, or null

  const employeeId = getEmployeeId();

  const showMsg = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchData = useCallback(async () => {
    if (!employeeId) { setError("session"); setLoading(false); return; }
    setLoading(true); setError(null);
    try {
      const res = await axios.get(`${API_BASE}/api/training/my/${employeeId}`);
      setRecords(res.data.data || []);
      setStats(res.data.stats);
    } catch (e) {
      setError(e?.response?.data?.message || "Failed to load");
    } finally { setLoading(false); }
  }, [employeeId]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleStart = async (recordId) => {
    try {
      await axios.put(`${API_BASE}/api/training/my/${recordId}/start`);
      showMsg("Training started! Good luck 🚀");
      fetchData();
    } catch (e) { showMsg(e?.response?.data?.message || "Failed", "error"); }
  };

  // ── Loading ─────────────────────────────────────────────────
  if (loading) return (
    <EmployeeLayout>
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", padding: 80 }}>
        <div style={{ width: 36, height: 36, border: "3px solid #e5e7eb", borderTopColor: "#3b82f6", borderRadius: "50%", animation: "spin .8s linear infinite" }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    </EmployeeLayout>
  );

  // ── Session ─────────────────────────────────────────────────
  if (error === "session") return (
    <EmployeeLayout>
      <div style={{ textAlign: "center", padding: 60 }}>
        <AlertTriangle size={40} color="#f59e0b" style={{ marginBottom: 12 }} />
        <h5 style={{ color: "#6b7280" }}>Session expired. Please login again.</h5>
      </div>
    </EmployeeLayout>
  );

  if (error) return (
    <EmployeeLayout>
      <div style={{ margin: 16, padding: 14, background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 10, color: "#dc2626", fontSize: 13 }}>{error}</div>
    </EmployeeLayout>
  );

  // ── Derived data ────────────────────────────────────────────
  const pending    = records.filter(r => r.status === "pending");
  const inProgress = records.filter(r => r.status === "in_progress");
  const completed  = records.filter(r => r.status === "completed");
  const overdue    = records.filter(r => r.dueDate && new Date(r.dueDate) < new Date() && r.status !== "completed");
  const completionRate = stats?.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;

  return (
    <EmployeeLayout>
      <style>{STYLES}</style>

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", top: 20, right: 16, zIndex: 9999, background: toast.type === "error" ? "#ef4444" : "#10b981", color: "#fff", padding: "12px 20px", borderRadius: 10, fontWeight: 600, fontSize: 14, boxShadow: "0 8px 24px rgba(0,0,0,.2)", maxWidth: "calc(100vw - 32px)" }}>
          {toast.msg}
        </div>
      )}

      <div className="tr-page">

        {/* ── Header ── */}
        <div className="tr-header-row" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20, gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: 12, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <GraduationCap size={24} color="#fff" />
            </div>
            <div>
              <h4 style={{ margin: 0, fontWeight: 800, fontSize: 19, color: "#1a1a2e" }}>My Training Journey</h4>
              <p style={{ margin: 0, color: "#6b7280", fontSize: 12 }}>Radnus Policy 3.15 — Job-Role Based Mandatory Training (RCA)</p>
            </div>
          </div>
          <button onClick={fetchData} disabled={loading}
            style={{ padding: "8px 14px", border: "1.5px solid #e5e7eb", borderRadius: 9, background: "#fff", cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 600, color: "#374151", flexShrink: 0 }}>
            <RefreshCw size={13} /> Refresh
          </button>
        </div>

        {/* ── Framework Banner ── */}
        <div style={{ background: "linear-gradient(135deg,#eff6ff,#f5f3ff)", borderRadius: 13, padding: "14px 18px", marginBottom: 16, border: "1px solid #bfdbfe" }}>
          <p style={{ margin: "0 0 6px", fontWeight: 700, fontSize: 13, color: "#1a1a2e" }}>Your Learning Framework: Learn → Apply → Lead</p>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap", fontSize: 12, color: "#374151" }}>
            <span><strong style={{ color: "#3b82f6" }}>Learn:</strong> Foundation & Skill Learning → Acquire job knowledge</span>
            <span><strong style={{ color: "#8b5cf6" }}>Apply:</strong> Real-world Implementation → Demonstrate proficiency</span>
            <span><strong style={{ color: "#10b981" }}>Lead:</strong> Coaching & Mentorship → Guide others</span>
          </div>
        </div>

        {/* ── Progress Overview ── */}
        {stats && (
          <div style={{ background: "#fff", borderRadius: 13, padding: "18px 20px", marginBottom: 16, boxShadow: "0 1px 4px rgba(0,0,0,.06)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <p style={{ margin: 0, fontWeight: 700, fontSize: 14 }}>My Progress</p>
              <span style={{ fontWeight: 800, fontSize: 18, color: completionRate >= 95 ? "#10b981" : completionRate >= 60 ? "#f59e0b" : "#ef4444" }}>
                {completionRate}%
              </span>
            </div>
            {/* Progress bar */}
            <div style={{ height: 10, background: "#f3f4f6", borderRadius: 6, marginBottom: 16, overflow: "hidden" }}>
              <div style={{ height: "100%", borderRadius: 6, background: completionRate >= 95 ? "#10b981" : completionRate >= 60 ? "#f59e0b" : "#3b82f6", width: `${completionRate}%`, transition: "width .4s" }} />
            </div>
            {/* Stats grid */}
            <div className="tr-stats-grid" style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 10 }}>
              {[
                { label: "Total",       value: stats.total,      color: "#111827", bg: "#f3f4f6" },
                { label: "Completed",   value: stats.completed,  color: "#10b981", bg: "#ecfdf5" },
                { label: "In Progress", value: stats.inProgress, color: "#3b82f6", bg: "#eff6ff" },
                { label: "Pending",     value: stats.pending,    color: "#6b7280", bg: "#f3f4f6" },
                { label: "Overdue",     value: overdue.length,   color: "#ef4444", bg: "#fef2f2" },
                { label: "Certified",   value: stats.certified,  color: "#f59e0b", bg: "#fffbeb" },
              ].map((s, i) => (
                <div key={i} style={{ background: s.bg, borderRadius: 9, padding: "8px 10px", textAlign: "center" }}>
                  <p style={{ margin: 0, fontWeight: 800, fontSize: 20, color: s.color, lineHeight: 1 }}>{s.value}</p>
                  <p style={{ margin: "3px 0 0", fontSize: 10, fontWeight: 700, color: s.color, textTransform: "uppercase", opacity: 0.8 }}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Overdue Alert ── */}
        {overdue.length > 0 && (
          <div style={{ background: "#fef2f2", border: "1px solid #fca5a5", borderRadius: 10, padding: "10px 14px", marginBottom: 14, display: "flex", alignItems: "flex-start", gap: 8, fontSize: 13 }}>
            <AlertTriangle size={16} color="#ef4444" style={{ flexShrink: 0, marginTop: 1 }} />
            <p style={{ margin: 0, color: "#991b1b" }}>
              You have <strong>{overdue.length} overdue training{overdue.length > 1 ? "s" : ""}</strong>. Please complete them immediately. Managers must confirm 100% training compliance before probation/promotion.
            </p>
          </div>
        )}

        {/* ── Tabs ── */}
        <div className="tr-tabs" style={{ display: "flex", gap: 6, marginBottom: 16, background: "#fff", borderRadius: 12, padding: 4, border: "1.5px solid #e5e7eb", width: "fit-content", maxWidth: "100%", overflowX: "auto" }}>
          {[
            { key: "my_trainings", label: `All (${records.length})`,            icon: <BookOpen size={13} /> },
            { key: "pending",      label: `Pending (${pending.length})`,         icon: <Clock size={13} /> },
            { key: "in_progress",  label: `In Progress (${inProgress.length})`,  icon: <Zap size={13} /> },
            { key: "completed",    label: `Completed (${completed.length})`,     icon: <CheckCircle2 size={13} /> },
            { key: "roadmap",      label: "Training Roadmap",                    icon: <Layers size={13} /> },
          ].map(tab => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              style={{ padding: "8px 14px", border: "none", borderRadius: 9, cursor: "pointer", fontWeight: 600, fontSize: 12, background: activeTab === tab.key ? "#1a1a2e" : "transparent", color: activeTab === tab.key ? "#fff" : "#6b7280", transition: "all .2s", display: "flex", alignItems: "center", gap: 5, whiteSpace: "nowrap" }}>
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        {/* ══ MY TRAININGS ══ */}
        {activeTab === "my_trainings" && (
          records.length === 0 ? (
            <div style={{ textAlign: "center", padding: "48px 24px", background: "#fff", borderRadius: 14, border: "1.5px solid #e5e7eb" }}>
              <GraduationCap size={40} color="#d1d5db" style={{ marginBottom: 12 }} />
              <p style={{ margin: "0 0 4px", color: "#374151", fontWeight: 600 }}>No trainings assigned yet.</p>
              <p style={{ margin: 0, color: "#9ca3af", fontSize: 13 }}>HR will assign trainings based on your role and department.</p>
            </div>
          ) : (
            <div className="tr-cards-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {records.map(r => <TrainingCard key={r._id} record={r} onStart={handleStart} onViewDetails={setDetailsRecord} />)}
            </div>
          )
        )}

        {/* ══ PENDING ══ */}
        {activeTab === "pending" && (
          pending.length === 0 ? (
            <div style={{ textAlign: "center", padding: "48px 24px", background: "#fff", borderRadius: 14, border: "1.5px solid #e5e7eb" }}>
              <CheckCircle2 size={36} color="#10b981" style={{ marginBottom: 12 }} />
              <p style={{ margin: 0, color: "#6b7280" }}>No pending trainings! Great job.</p>
            </div>
          ) : (
            <div className="tr-cards-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {pending.map(r => <TrainingCard key={r._id} record={r} onStart={handleStart} onViewDetails={setDetailsRecord} />)}
            </div>
          )
        )}

        {/* ══ IN PROGRESS ══ */}
        {activeTab === "in_progress" && (
          inProgress.length === 0 ? (
            <div style={{ textAlign: "center", padding: "48px 24px", background: "#fff", borderRadius: 14, border: "1.5px solid #e5e7eb" }}>
              <Clock size={36} color="#d1d5db" style={{ marginBottom: 12 }} />
              <p style={{ margin: 0, color: "#6b7280" }}>No trainings in progress.</p>
            </div>
          ) : (
            <div className="tr-cards-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {inProgress.map(r => <TrainingCard key={r._id} record={r} onStart={handleStart} onViewDetails={setDetailsRecord} />)}
            </div>
          )
        )}

        {/* ══ COMPLETED ══ */}
        {activeTab === "completed" && (
          completed.length === 0 ? (
            <div style={{ textAlign: "center", padding: "48px 24px", background: "#fff", borderRadius: 14, border: "1.5px solid #e5e7eb" }}>
              <BookOpen size={36} color="#d1d5db" style={{ marginBottom: 12 }} />
              <p style={{ margin: 0, color: "#6b7280" }}>No trainings completed yet.</p>
            </div>
          ) : (
            <div>
              {/* Certificates earned */}
              {completed.filter(r => r.certificationIssued).length > 0 && (
                <div style={{ background: "linear-gradient(135deg,#fffbeb,#fef3c7)", borderRadius: 13, padding: "14px 18px", marginBottom: 14, border: "1px solid #fde68a" }}>
                  <p style={{ margin: "0 0 10px", fontWeight: 700, fontSize: 13, color: "#92400e" }}>🏆 Certifications Earned</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {completed.filter(r => r.certificationIssued).map((r, i) => (
                      <span key={i} style={{ background: "#f59e0b", color: "#fff", borderRadius: 20, padding: "5px 12px", fontSize: 12, fontWeight: 600, display: "flex", alignItems: "center", gap: 5 }}>
                        <Award size={11} /> {r.programId?.certification || r.programId?.title}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              <div className="tr-cards-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                {completed.map(r => <TrainingCard key={r._id} record={r} onStart={handleStart} onViewDetails={setDetailsRecord} />)}
              </div>
            </div>
          )
        )}

        {/* ══ ROADMAP ══ */}
        {activeTab === "roadmap" && (
          <div>
            <div style={{ background: "#ecfdf5", border: "1px solid #6ee7b7", borderRadius: 10, padding: "10px 14px", marginBottom: 16, display: "flex", gap: 8, alignItems: "flex-start", fontSize: 12 }}>
              <Info size={14} color="#059669" style={{ flexShrink: 0, marginTop: 1 }} />
              <p style={{ margin: 0, color: "#065f46", lineHeight: 1.6 }}>
                This is the standard Radnus training roadmap for all employees (L1–L6). Your assigned trainings depend on your role, level, and department. All trainings are tracked via Radnus Corporate Academy (RCA).
              </p>
            </div>

            <p style={{ margin: "0 0 12px", fontWeight: 700, fontSize: 14 }}>Job-Role Based Mandatory Training (L1–L6)</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
              {[
                { level: "L1", label: "Intern / Trainee",       color: "#6b7280", duration: "7 Days",    cert: "RCA Foundation Certificate",          by: "HR & Culture",          modules: ["Company Induction", "Basic Communication", "Workplace Etiquette", "Radnus Culture"] },
                { level: "L2", label: "Executive",              color: "#3b82f6", duration: "1 Month",    cert: "RCA Role Certificate",                by: "Dept. Head + Trainer",  modules: ["Product & Service Training", "CRM & ERP Usage", "Customer Handling", "Basic Reporting"] },
                { level: "L3", label: "Senior Executive / AM",  color: "#8b5cf6", duration: "2 Months",   cert: "RCA Performance Certificate",         by: "L&D Team",              modules: ["Advanced Product Knowledge", "Dept SOP Training", "Team Coordination", "Basic Leadership"] },
                { level: "L4", label: "Manager / Sr. Manager",  color: "#f59e0b", duration: "3 Months",   cert: "RCA Leadership Readiness Badge",      by: "HR + L&D",              modules: ["Strategic Planning", "People Management", "Coaching & Mentoring", "Business Review"] },
                { level: "L5", label: "GM / AVP",               color: "#ef4444", duration: "3–6 Months", cert: "RCA Business Leadership Certificate", by: "CEO Office + External", modules: ["Business Growth Strategy", "Financial Awareness", "Data-driven Decision Making", "Leadership Communication"] },
                { level: "L6", label: "VP / Director / CXO",   color: "#10b981", duration: "6 Months",   cert: "RCA Executive Leadership Certificate", by: "CEO + Advisory Board",  modules: ["Vision Alignment", "Corporate Governance", "Digital Transformation", "Cross-Functional Leadership"] },
              ].map((r, i) => (
                <div key={i} style={{ background: "#fff", borderRadius: 12, padding: "14px 18px", borderLeft: `4px solid ${r.color}`, boxShadow: "0 1px 4px rgba(0,0,0,.06)" }}>
                  <div className="tr-roadmap-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, gap: 10 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <span style={{ background: r.color, color: "#fff", borderRadius: 20, padding: "4px 12px", fontSize: 13, fontWeight: 700 }}>{r.level}</span>
                      <div>
                        <p style={{ margin: 0, fontWeight: 700, fontSize: 14 }}>{r.label}</p>
                        <p style={{ margin: 0, color: "#6b7280", fontSize: 12 }}>Duration: {r.duration} · By: {r.by}</p>
                      </div>
                    </div>
                    <div style={{ background: `${r.color}10`, borderRadius: 8, padding: "5px 12px", border: `1px solid ${r.color}33`, flexShrink: 0 }}>
                      <p style={{ margin: 0, fontSize: 11, color: r.color, display: "flex", alignItems: "center", gap: 4 }}>
                        <Award size={11} /> {r.cert}
                      </p>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {r.modules.map((m, j) => (
                      <span key={j} style={{ background: "#f3f4f6", color: "#374151", borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 600 }}>{m}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Frequency Table */}
            <p style={{ margin: "0 0 12px", fontWeight: 700, fontSize: 14 }}>Training Frequency & Review</p>
            <div className="tr-table-wrap" style={{ background: "#fff", borderRadius: 12, overflow: "hidden", boxShadow: "0 1px 4px rgba(0,0,0,.06)", marginBottom: 16 }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead>
                  <tr style={{ background: "#f9fafb" }}>
                    {["Training Type", "When", "Who Conducts"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontWeight: 700, color: "#6b7280", fontSize: 11, textTransform: "uppercase", borderBottom: "2px solid #e5e7eb" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { type: "Induction Training",            when: "On Joining",      by: "HR & L&D" },
                    { type: "Job Role Training",             when: "Within 30 Days",  by: "Department Trainer" },
                    { type: "Cross-Functional / Leadership", when: "Every 6 Months",  by: "L&D + HR" },
                    { type: "Culture & Engagement",          when: "Quarterly",       by: "Culture Team" },
                    { type: "Refresher Training",            when: "Annual",          by: "HR & L&D" },
                  ].map((r, i) => (
                    <tr key={i} style={{ borderTop: "1px solid #f3f4f6" }}>
                      <td style={{ padding: "10px 14px", fontWeight: 600 }}>{r.type}</td>
                      <td style={{ padding: "10px 14px" }}><span style={{ background: "#f3f4f6", color: "#374151", borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 600 }}>{r.when}</span></td>
                      <td style={{ padding: "10px 14px", color: "#6b7280" }}>{r.by}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Governance note */}
            <div style={{ background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "10px 14px", display: "flex", gap: 8, alignItems: "flex-start", fontSize: 12 }}>
              <Info size={14} color="#d97706" style={{ flexShrink: 0, marginTop: 1 }} />
              <p style={{ margin: 0, color: "#78350f", lineHeight: 1.6 }}>
                <strong>Training Governance:</strong> All trainings are tracked in RCA (Radnus Corporate Academy) via your dashboard. Your manager must ensure 100% training compliance before confirming probation or promotion.
              </p>
            </div>
          </div>
        )}

      </div>

      {/* ✅ NEW — course-content modal, opened via "View Details" on a card */}
      {detailsRecord && (
        <TrainingDetailsModal
          record={detailsRecord}
          onClose={() => { setDetailsRecord(null); fetchData(); }}
          onRefresh={fetchData}
          onOpenQuiz={(record) => setQuizRecord(record)}
        />
      )}

      {/* ✅ NEW — quiz-taking modal, opened via "Take Test" in details modal */}
      {quizRecord && (
        <QuizModal
          record={quizRecord}
          onClose={() => { setQuizRecord(null); fetchData(); }}
          onRefresh={fetchData}
        />
      )}
    </EmployeeLayout>
  );
}