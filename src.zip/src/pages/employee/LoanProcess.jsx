import React, { useState, useEffect, useRef } from "react";
import { Eye, Download } from "lucide-react";
import EmployeeLayout from "./EmployeeLayout";

// ── Static config ────────────────────────────────────────────────────────
const DOC_FIELDS = [
    { key: "aadharCard", label: "Aadhar Card" },
    { key: "passportPhoto", label: "Passport Photo" },
    { key: "signature", label: "Customer Signature" },
    { key: "study10th12th", label: "Study 10th / 12th" },
    { key: "community", label: "Community Certificate" },
    { key: "pancard", label: "Pancard" },
    { key: "rationCard", label: "Ration Card" },
    { key: "bankPassbook", label: "Bank Pass Book" },
    { key: "gasBill", label: "Gas Bill", optional: true },
    { key: "ebBill", label: "EB Bill", optional: true }
];

const CHECKLIST_STAGES = [
    { key: "cibilVerification", label: "CIBIL Verification" },
    { key: "documentCollection", label: "Document Collection" },
    { key: "applicationProcess", label: "Online Loan Application", incentiveLinked: true, remarkLabel: "Application Number", remarkPlaceholder: "Application Number" },
    { key: "quotation", label: "Quotation" },
    { key: "auditorReference", label: "Auditor Reference" },
    { key: "documentPayment", label: "Document Payment" },
    { key: "finalisationVerification", label: "Finalisation & Verification" },
    { key: "finalSubmission", label: "Final Submission" },
    { key: "courier", label: "Projection Dispatch/Courier", incentiveLinked: true, remarkLabel: "Courier Slip No", remarkPlaceholder: "Courier Slip No" },
    { key: "completed", label: "Completed" },
];

// These 2 stages drive incentive eligibility
const INCENTIVE_LINKED_KEYS = ["applicationProcess", "courier"];

const DATE_ENABLED_STAGES = ["documentPayment", "courier"]; // date field intha rendu stages ku mattum
const AMOUNT_ENABLED_STAGES = ["documentPayment"]; // amount field Document Payment ku mattum // date field intha rendu stages ku mattum
const DOC_PAYMENT_OPTIONS = [5000, 10000];
const SCHEME_OPTIONS = [
    { value: "PMEGP", label: "PMEGP - Prime Minister's Employment Generation Programme" },
    { value: "UYEGP", label: "UYEGP - Unemployed Youth Employment Generation Programme" },
    { value: "AABCS", label: "AABCS - Annal Ambedkar Business Champions Scheme" },
    { value: "NEEDS", label: "NEEDS - New Entrepreneur-cum-Enterprise Development Scheme" },
    { value: "TABCEDCO", label: "TABCEDCO - Tamil Nadu Backward Classes Economic Development Corporation" },
    { value: "TWEES", label: "TWEES - Tamil Nadu Women Entrepreneur Empowerment Scheme" },
    { value: "PMFME", label: "PMFME - Pradhan Mantri Formalization Of Micro Food Processing Enterprises Scheme" },
];

// PMEGP eligible business list — fixed list so everyone picks from the same
// names instead of typing free text (report-a consistent-a eduka idhu mukkiyam).
const BUSINESS_TYPE_OPTIONS = [
    "Mobile Service Center",
    "TV Service Center",
    "Tailoring Shop & Garments",
    "Manufacturing of Food Industry",
    "Medicine Manufacturing",
    "Farm Fresh Organic Products",
    "Milk Products Manufacturing",
    "Mara Chekku Machine",
    "Auto Mobile Work",
    "LED Screen Manufacturing",
    "Manufacture of Paper Cups, Tissue & Table Paper Roll",
    "Pet Bottle Manufacturing",
    "Beauty Parlour & Saloon",
    "Areca Plate Manufacturing",
    "Bricks Manufacturing (Stone Cutting)",
    "Speaker and PCB Manufacturing",
    "Electrical Equipments",
    "Manufacturing of Bags & Suitcase",
    "Cement Blocking (Fly Ash Bricks)",
    "Power Laundry Service",
    "Samosa Manufacturing",
    "Bakery Products Manufacturing",
    "Agarbatti Manufacturing",
    "Manufacturing of PP Covers and Rolls",
    "Computer Assembling (Computer & Mobile Service)",
    "Iron Grill Making (Shutter Material Parts Production)",
    "Beverages / Soft Drink Processing",
    "Engineering Works / Mechanic Workshop",
    "Chicken Farming Business",
    "Cow Farming Business",
    "Goat Farming Business",
    "Cattle Food Manufacturing",
    "Cloud Kitchen",
    "Xerox Shop",
    "Car Taxi Loan",
    "Aadhar Service Centre",
    "Pani Puri Manufacturing ",
    "Honey Spoon Manufacturing",
    "Gold Manufacturing",
    "Soap And Detergent Manufacturing",
    "Diesel Generators Manufacturing",
    "Manufacturing Of Steel Rack",
    "1 Gram Gold Jewellery ",
    "Aqua purifier",
    "AC Spare Parts",
    "Man Power Agency",
    "Construction",
    // ── Agriculture & Allied Activities ──
    "Paddy Cultivation",
    "Vegetable Farming",
    "Fruit Orchards",
    "Dairy Farming",
    "Sheep Breeding",
    "Poultry Farming",
    "Inland Fisheries",
    "Beekeeping",
    "Organic Farming",
    "Vermicompost Production",
    "Mushroom Cultivation",
    "Floriculture",
    "Agro-Service Centers",
    "Fish Aquarium",
    "Cotton Recycling",
    // ── Small Trade & Retail Stores ──
    "Grocery Store (Kirana Shop)",
    "Textile and Readymade Garment Shop",
    "Footwear Retail Shop",
    "Fancy and Stationery Store",
    "Electrical and Hardware Shop",
    "Mobile Phone Sales Shop",
    "Sports Goods Shop",
    "Medical Store (Pharmacy)",
    "Vessel and Utensil Shop",
    "Meat and Fish Retail Stall",
    "Vegetable and Fruit Vending Stall",
    "Flower Shop",
    "Home Appliances",
    "Tiles and Granites",
    // ── Services & Self-Employment ──
    "Hotel, Restaurant, and Tea Stall",
    "Catering Service",
    "Hair Salon",
    "Photocopy (Xerox) and DTP Center",
    "Mobile and Electronics Repair Shop",
    "DTP and Digital Printing Unit",
    "Tailoring and Embroidery Unit",
    "Tuition and Coaching Center",
    "Two-Wheeler Repair Workshop",
    "Car Washing and Servicing Unit",
    "Electrical Wiring and Plumbing Service",
    "Dry Cleaning and Laundry Service",
    "Photography and Video Studio",
    " Gymnasium/Gym",
    "Cane Furniture Manufacturing",
    "Centering Business",
    "Travels",
    "Transport Business",
    // ── Transport Sector ──
    "Auto-Rickshaw Service",
    "E-Rickshaw Service",
    "Tourist Taxi and Cab Service",
    "Mini-Truck Goods Transport",
    "Pick-Up Van Delivery Service",
    // ── Handicrafts & Traditional Occupations ──
    "Pottery and Clay Crafts Unit",
    "Handloom and Powerloom Weaving",
    "Leather Goods Manufacturing",
    "Woodcarving and Carpentry Workshop",
    "Blacksmithy and Metal Welding Shop",
    "Cane and Bamboo Furniture Making",
    "Candle and Camphor Making",
    "Coir Product Manufacturing",
    "Wall Painting And Wall Art",
    // ── Professional Services ──
    "Medical Clinic",
    "Dental Clinic",
    "Physiotherapy Center",
    "Engineering Consultancy Firm",
    "Architectural Design Studio",
    "Legal Consultancy Office",
    "Auditing and Tax Consultancy Firm",
    "Computer Training Institute",
];

// Fixed bank list — nationalised banks + City Union Bank + Federal Bank.
const BANK_NAME_OPTIONS = [
    "State Bank of India",
    "Punjab National Bank",
    "Bank of Baroda",
    "Canara Bank",
    "Union Bank of India",
    "Bank of India",
    "Indian Bank",
    "Central Bank of India",
    "Indian Overseas Bank",
    "UCO Bank",
    "Bank of Maharashtra",
    "Punjab & Sind Bank",
    "City Union Bank",
    "Tamilnadu Mercantile Bank",
    "Federal Bank",
    "Karur Vysya Bank",
];

const todayStr = () => new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"

// "28/10/2026, 5:21 pm" — customer system-la add aana neram
const fmtAdded = (d) =>
    d
        ? new Date(d).toLocaleString("en-IN", {
            day: "2-digit", month: "2-digit", year: "numeric",
            hour: "numeric", minute: "2-digit", hour12: true,
        })
        : "—";


const BLANK_FORM = {
    customerName: "",
    loanDate: todayStr(),
    communicationAddress: "",
    unitAddress: "",
    businessType: "",
    businessSubType: "",
    scheme: "",
    loanValue: "",
    contactNo: "",
    mailId: "",
    bankName: "",
    ifscCode: "",
    fatherName: "",
    fatherOccupation: "",
    maritalStatus: "",
    spouseName: "",
    spouseOccupation: "",
};

// ── Searchable dropdown (combobox) ──────────────────────────────────────────
// Reused for Business Type + Bank Name so employees pick from the fixed list
// instead of typing free text (keeps report data consistent). Works with the
// existing handleChange(e) functions by dispatching a fake {target:{name,value}}
// event, so no other form-state logic needs to change.
function SearchableSelect({ name, value, onChange, options, placeholder, invalid }) {
    const [query, setQuery] = useState(value || "");
    const [open, setOpen] = useState(false);
    const wrapRef = useRef(null);

    useEffect(() => {
        setQuery(value || "");
    }, [value]);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (wrapRef.current && !wrapRef.current.contains(e.target)) {
                setOpen(false);
                setQuery(value || ""); // typed but didn't pick — revert the box text
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [value]);

    const filtered = options.filter((opt) =>
        opt.toLowerCase().includes((query || "").toLowerCase())
    );

    const selectOption = (opt) => {
        onChange({ target: { name, value: opt } });
        setQuery(opt);
        setOpen(false);
    };

    return (
        <div className="lp-searchable-select" ref={wrapRef}>
            <input
                name={name}
                value={query}
                onChange={(e) => {
                    setQuery(e.target.value);
                    setOpen(true);
                    // clear the real form value until they actually pick a list item —
                    // stops half-typed / made-up names from being saved
                    onChange({ target: { name, value: "" } });
                }}
                onFocus={() => setOpen(true)}
                placeholder={placeholder}
                autoComplete="off"
                className={invalid ? "lp-input-invalid" : ""}
            />
            {open && (
                <div className="lp-searchable-dropdown">
                    {filtered.length === 0 && <div className="lp-searchable-empty">No match found</div>}
                    {filtered.map((opt) => (
                        <div
                            key={opt}
                            className={`lp-searchable-option ${opt === value ? "selected" : ""}`}
                            onMouseDown={() => selectOption(opt)}
                        >
                            {opt}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default function LoanProcess() {
    const API = import.meta.env.VITE_API_BASE_URL;
    const authHeaders = () => ({
        Authorization: `Bearer ${localStorage.getItem("employeeToken") || sessionStorage.getItem("employeeToken")}`,
    });

    const [tab, setTab] = useState("form");
    const [form, setForm] = useState(BLANK_FORM);
    const [files, setFiles] = useState({}); // { aadharCard: File, ... }
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState("");
    const [successMsg, setSuccessMsg] = useState("");
    const [fieldErrors, setFieldErrors] = useState({}); // { customerName: "message", ... }
    const [docErrors, setDocErrors] = useState({}); // { aadharCard: "message", ... }

    const [customers, setCustomers] = useState([]);
    const [loadingList, setLoadingList] = useState(false);
    const [expandedId, setExpandedId] = useState(null);
    const [reasonDraft, setReasonDraft] = useState({}); // { [customerId]: text }
    const [remarkDraft, setRemarkDraft] = useState({}); // { [customerId]: { [stageKey]: text } }
    const remarkInputRefs = useRef({}); // { "customerId-stageKey": <input> } 

    /* ------------------------ TAB 2 — CUSTOMER DATA (view/edit/delete) --- */
    const [expandedDataId, setExpandedDataId] = useState(null);
    const [editingId, setEditingId] = useState(null); // customerId currently in edit mode
    const [editForm, setEditForm] = useState(BLANK_FORM);
    const [editFiles, setEditFiles] = useState({}); // new files chosen to replace existing docs
    const [editFieldErrors, setEditFieldErrors] = useState({});
    const [editDocErrors, setEditDocErrors] = useState({});
    const [editSaving, setEditSaving] = useState(false);
    const [editError, setEditError] = useState("");
    const [deletingId, setDeletingId] = useState(null);
    const [rowMsg, setRowMsg] = useState({}); // { [customerId]: "Saved" | "Deleted" }
    const [isTelecaller, setIsTelecaller] = useState(false);
    const [isApplication, setIsApplication] = useState(false);
    const [accessLoaded, setAccessLoaded] = useState(false);
    const [allCustomers, setAllCustomers] = useState([]);
    const [loadingAll, setLoadingAll] = useState(false);
    const [expandedViewAllId, setExpandedViewAllId] = useState(null);
    const [appTab, setAppTab] = useState("pending");   // "pending" | "completed"
    const [appDate, setAppDate] = useState({});         // { [customerId]: "YYYY-MM-DD" }
    const [appSavingId, setAppSavingId] = useState(null);
    const [appSearch, setAppSearch] = useState("");
    const [appSort, setAppSort] = useState("added");// "newest" | "oldest"
    const [appFrom, setAppFrom] = useState("");   // YYYY-MM-DD
    const [appTo, setAppTo] = useState("");       // YYYY-MM-DD
    const myEmployeeId = localStorage.getItem("employeeId");
    const todayDate = new Date().toLocaleDateString("en-CA");
    /* ------------------------ LOAD CHECKLIST TAB ------------------------ */
    const loadCustomers = async () => {
        setLoadingList(true);
        try {
            const res = await fetch(`${API}/api/loan-process/all`, { headers: authHeaders() });
            const data = await res.json();
            if (data.success) setCustomers(data.data || []);
        } catch (err) {
            console.error("LOAD LOAN CUSTOMERS ERROR", err);
        } finally {
            setLoadingList(false);
        }
    };

    useEffect(() => {
        if (tab === "checklist" || tab === "data") loadCustomers();
        if (tab === "viewAll") loadAllCustomers();
    }, [tab]);

    // Telecaller / Application access — token vachu backend la irundhu edukkurom
    useEffect(() => {
        fetch(`${API}/api/loan-process/my-access`, { headers: authHeaders() })
            .then((r) => r.json())
            .then((data) => {
                const tele = !!data?.isTelecaller;
                const app = !!data?.isApplication;
                setIsTelecaller(tele);
                setIsApplication(app);
                // Application-only person → land directly on "View Details"
                if (!tele && app) setTab("viewAll");
            })
            .catch(() => { })
            .finally(() => setAccessLoaded(true));
    }, []);

    const loadAllCustomers = async () => {
        setLoadingAll(true);
        try {
            const res = await fetch(`${API}/api/loan-process/all?viewAll=true`, { headers: authHeaders() });
            const data = await res.json();
            if (data.success) setAllCustomers(data.data || []);
        } catch (err) {
            console.error("LOAD ALL LOAN CUSTOMERS ERROR", err);
        } finally {
            setLoadingAll(false);
        }
    };

    const appCall = async (id, action, method, body) => {
        setAppSavingId(id);
        try {
            const res = await fetch(`${API}/api/loan-process/${id}/application/${action}`, {
                method,
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify(body || {}),
            });
            const data = await res.json();
            if (!data.success) alert(data.message || "Couldn't save — please try again.");
            await loadAllCustomers();
            return !!data.success;
        } catch (err) {
            console.error("APPLICATION ACTION ERROR", err);
            alert("Network error — please try again.");
            return false;
        } finally {
            setAppSavingId(null);
        }
    };
    const takeApplication = async (c) => {
        const ok = await appCall(c._id, "claim", "POST");
        if (ok) setAppTab("mine");   // eduthadha My Applications tab-ku poidum
    };
    const releaseApplication = (c) => {
        if (!window.confirm(`Release ${c.customerName}? Others can take it.`)) return;
        appCall(c._id, "release", "POST");
    };
    const completeApplication = (c) => {
        const date = appDate[c._id] || todayDate;
        if (!window.confirm(`Mark ${c.customerName}'s application as COMPLETED on ${date}?`)) return;
        appCall(c._id, "complete", "PATCH", { date });
    };

    const t = (d) => new Date(d).getTime() || 0;

    const SORTERS = {
        // add pannina neram (system created time)
        added: (a, b) => t(b.createdAt) - t(a.createdAt),
        // card-la theriyura Loan Date: pudhusu mela
        dateNew: (a, b) => t(b.loanDate || b.createdAt) - t(a.loanDate || a.createdAt) || t(b.createdAt) - t(a.createdAt),
        // card-la theriyura Loan Date: pazhasu mela
        dateOld: (a, b) => t(a.loanDate || a.createdAt) - t(b.loanDate || b.createdAt) || t(a.createdAt) - t(b.createdAt),
    };

    const isMineApp = (c) =>
        !!myEmployeeId && String(c.application?.assignedTo?.employeeId || "") === String(myEmployeeId);

    // Pending = yaarum edukaadhadhu mattum
    const pendingApps = allCustomers
        .filter((c) => c.application?.status !== "COMPLETED" && !c.application?.assignedTo?.employeeId)
        .sort(SORTERS[appSort] || SORTERS.added);

    // My Applications = naan eduthu innum mudikkaadhadhu (latest eduthadhu mela)
    const myApps = allCustomers
        .filter((c) => c.application?.status !== "COMPLETED" && isMineApp(c))
        .sort((a, b) => t(b.application?.assignedTo?.assignedAt) - t(a.application?.assignedTo?.assignedAt));
    const completedApps = allCustomers
        .filter((c) => c.application?.status === "COMPLETED")
        .sort((a, b) => new Date(b.application.completedAt) - new Date(a.application.completedAt));
    const toDay = (d) => (d ? new Date(d).toLocaleDateString("en-CA") : ""); // local YYYY-MM-DD

    const matchesAppFilter = (c) => {
        const q = appSearch.trim().toLowerCase();
        if (q) {
            const hay = `${c.customerName || ""} ${c.contactNo || ""} ${c.staffId?.name || c.staffName || ""}`.toLowerCase();
            if (!hay.includes(q)) return false;
        }
        // Pending tab → customer date (loanDate), Completed tab → completed date
        const day = toDay(appTab === "completed" ? c.application?.completedAt : c.loanDate);
        if (appFrom && (!day || day < appFrom)) return false;
        if (appTo && (!day || day > appTo)) return false;
        return true;
    };

    const appList = (
        appTab === "completed" ? completedApps : appTab === "mine" ? myApps : pendingApps
    ).filter(matchesAppFilter);

    /* ------------------------ TAB 1 — FORM ------------------------ */
    const handleChange = (e) => {
        const { name, value } = e.target;
        const nextValue = name === "ifscCode" ? value.toUpperCase() : value;
        setForm({ ...form, [name]: nextValue });
        // clear the error for this field as soon as the user edits it
        if (fieldErrors[name]) {
            setFieldErrors((prev) => {
                const next = { ...prev };
                delete next[name];
                return next;
            });
        }
    };

    const handleFile = (key, file) => {
        setFiles({ ...files, [key]: file });
        if (docErrors[key]) {
            setDocErrors((prev) => {
                const next = { ...prev };
                delete next[key];
                return next;
            });
        }
    };

    const resetForm = () => {
        setForm({ ...BLANK_FORM, loanDate: todayStr() });
        setFiles({});
        setFieldErrors({});
        setDocErrors({});
    };

    /* ------------------------ VALIDATION ------------------------ */
    const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const IFSC_RE = /^[A-Z]{4}0[A-Z0-9]{6}$/;
    const PHONE_RE = /^[6-9]\d{9}$/; // 10 digit Indian mobile number

    const downloadDoc = async (url, filename) => {
        try {
            const res = await fetch(url);
            const blob = await res.blob();
            const blobUrl = window.URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = blobUrl;
            link.download = filename || "document";
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(blobUrl);
        } catch (err) {
            console.error("DOC DOWNLOAD ERROR", err);
            window.open(url, "_blank"); // fallback — at least let them see it
        }
    };

    const validateForm = () => {
        const fErrs = {};
        const dErrs = {};

        // ---- Customer Details: every field mandatory + format checks ----
        if (!form.customerName.trim()) {
            fErrs.customerName = "Customer Name is required.";
        }

        if (!form.contactNo.trim()) {
            fErrs.contactNo = "Contact No is required.";
        } else if (!PHONE_RE.test(form.contactNo.trim())) {
            fErrs.contactNo = "Enter a valid 10 digit mobile number.";
        }

        if (!form.mailId.trim()) {
            fErrs.mailId = "Mail ID is required.";
        } else if (!EMAIL_RE.test(form.mailId.trim())) {
            fErrs.mailId = "Enter a valid email address.";
        }

        if (!form.businessType.trim()) {
            fErrs.businessType = "Business Type is required.";
        }

        if (!form.scheme.trim()) {
            fErrs.scheme = "Scheme is required.";
        }

        if (!form.loanDate) {
            fErrs.loanDate = "Date is required.";
        }

        if (!String(form.loanValue).trim()) {
            fErrs.loanValue = "Loan Value is required.";
        } else if (Number(form.loanValue) <= 0 || Number.isNaN(Number(form.loanValue))) {
            fErrs.loanValue = "Enter a valid loan amount.";
        }

        if (!form.bankName.trim()) {
            fErrs.bankName = "Bank Name is required.";
        }

        if (!form.ifscCode.trim()) {
            fErrs.ifscCode = "IFSC Code is required.";
        } else if (!IFSC_RE.test(form.ifscCode.trim())) {
            fErrs.ifscCode = "Enter a valid IFSC code (e.g. ABCD0123456).";
        }

        if (!form.communicationAddress.trim()) {
            fErrs.communicationAddress = "Communication Address is required.";
        }

        if (!form.unitAddress.trim()) {
            fErrs.unitAddress = "Unit Address is required.";
        }

        if (!form.maritalStatus) {
            fErrs.maritalStatus = "Marital Status is required.";
        }

        // ---- Govt Documents: every document upload mandatory ----
        DOC_FIELDS.forEach((doc) => {
            if (doc.optional) return;
            if (!files[doc.key]) {
                dErrs[doc.key] = `${doc.label} is required.`;
            }
        });
        return { fErrs, dErrs };
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSuccessMsg("");

        const { fErrs, dErrs } = validateForm();
        setFieldErrors(fErrs);
        setDocErrors(dErrs);

        if (Object.keys(fErrs).length > 0 || Object.keys(dErrs).length > 0) {
            setError("Please fill all required fields and upload all documents correctly.");
            return;
        }

        setSaving(true);
        try {
            const fd = new FormData();
            Object.entries(form).forEach(([k, v]) => fd.append(k, v));
            Object.entries(files).forEach(([k, file]) => {
                if (file) fd.append(k, file);
            });

            const res = await fetch(`${API}/api/loan-process/create`, {
                method: "POST",
                headers: authHeaders(), // NOTE: don't set Content-Type — browser sets multipart boundary
                body: fd,
            });
            const data = await res.json();

            if (!data.success) {
                setError(data.message || "Something went wrong. Please try again.");
                setSaving(false);
                return;
            }

            setSuccessMsg(`${form.customerName} saved. Switching to Checklist…`);
            resetForm();
            setSaving(false);

            setTimeout(() => {
                setSuccessMsg("");
                setTab("checklist");
            }, 900);
        } catch (err) {
            console.error("LOAN CUSTOMER SUBMIT ERROR", err);
            setError("Server error. Please try again.");
            setSaving(false);
        }
    };

    /* ------------------------ TAB 2 — CHECKLIST ------------------------ */
    const toggleStage = async (customerId, field, currentValue) => {
        const current = customers.find((c) => c._id === customerId);

        if (current?.incentive?.eligibility === "Paid" && INCENTIVE_LINKED_KEYS.includes(field)) {
            alert("Incentive already paid for this loan. Online Loan Application / Projection Dispatch can't be changed anymore.");
            return;
        }

        // Can't tick Online Loan Application / Projection Dispatch without its proof number filled in first.
        if (currentValue !== true && INCENTIVE_LINKED_KEYS.includes(field)) {
            const remarkNow = (remarkDraft[customerId]?.[field] ?? current?.checklistRemarks?.[field] ?? "").trim();
            if (!remarkNow) {
                const stage = CHECKLIST_STAGES.find((s) => s.key === field);
                alert(`Enter the ${stage?.remarkLabel || "number"} first — it's proof for the incentive, then you can check this box.`);
                return;
            }
        }

        if (currentValue === true && INCENTIVE_LINKED_KEYS.includes(field)) {
            const ok = window.confirm(
                "Unchecking this will revert the incentive eligibility for this loan. Are you sure?"
            );
            if (!ok) return;
        }

        // Document Payment tick panna amount (5000 / 10000) kandippa select pannanum
        if (field === "documentPayment" && currentValue !== true) {
            const amt = Number(current?.checklistAmounts?.documentPayment);
            if (!current?.documentPaymentExternal && !DOC_PAYMENT_OPTIONS.includes(amt)) {
                alert("Select the document payment amount (₹5,000 or ₹10,000) or 'Done elsewhere' first, then tick Document Payment.");
                return;
            }
        }

        // optimistic update
        setCustomers((prev) =>
            prev.map((c) =>
                c._id === customerId ? { ...c, checklist: { ...c.checklist, [field]: !currentValue } } : c
            )
        );
        try {
            const res = await fetch(`${API}/api/loan-process/${customerId}/checklist`, {
                method: "PATCH",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify({ field, value: !currentValue }),
            });
            const data = await res.json();
            if (data.success) {
                setCustomers((prev) => prev.map((c) => (c._id === customerId ? data.customer : c)));
            } else {
                alert(data.message || "Couldn't update — please try again.");
                loadCustomers(); // revert on failure
            }
        } catch (err) {
            console.error("CHECKLIST TOGGLE ERROR", err);
            loadCustomers();
        }
    };

    const saveReason = async (customerId) => {
        const current = customers.find((c) => c._id === customerId);
        const reasonForPending = reasonDraft[customerId] ?? current?.reasonForPending ?? "";
        try {
            // Reuse the "completed" field's current value so the PATCH doesn't
            // accidentally flip a checklist stage while only saving the reason text.
            const currentCompleted = !!current?.checklist?.completed;
            await fetch(`${API}/api/loan-process/${customerId}/checklist`, {
                method: "PATCH",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify({ field: "completed", value: currentCompleted, reasonForPending }),
            });
        } catch (err) {
            console.error("REASON SAVE ERROR", err);
        }
    };

    const saveRemark = async (customerId, field) => {
        const current = customers.find((c) => c._id === customerId);
        const remark = remarkDraft[customerId]?.[field] ?? current?.checklistRemarks?.[field] ?? "";
        let currentValue = !!current?.checklist?.[field];

        // Application Number / Courier Slip No is proof — clearing it auto-unchecks the box.
        if (INCENTIVE_LINKED_KEYS.includes(field) && currentValue && !remark.trim()) {
            currentValue = false;
        }

        try {
            const res = await fetch(`${API}/api/loan-process/${customerId}/checklist`, {
                method: "PATCH",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify({ field, value: currentValue, remark }),
            });
            const data = await res.json();
            if (data.success) {
                setCustomers((prev) => prev.map((c) => (c._id === customerId ? data.customer : c)));
            } else if (data.message) {
                alert(data.message);
                loadCustomers();
            }
        } catch (err) {
            console.error("REMARK SAVE ERROR", err);
        }
    };

    const clearRemark = async (customerId, field) => {
        const key = `${customerId}-${field}`;
        if (remarkInputRefs.current[key]) remarkInputRefs.current[key].value = "";

        setRemarkDraft((prev) => ({
            ...prev,
            [customerId]: { ...(prev[customerId] || {}), [field]: "" },
        }));

        const current = customers.find((c) => c._id === customerId);
        let currentValue = !!current?.checklist?.[field];

        if (INCENTIVE_LINKED_KEYS.includes(field) && currentValue) {
            currentValue = false;
        }

        try {
            const res = await fetch(`${API}/api/loan-process/${customerId}/checklist`, {
                method: "PATCH",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify({ field, value: currentValue, remark: "" }),
            });
            const data = await res.json();
            if (data.success) {
                setCustomers((prev) => prev.map((c) => (c._id === customerId ? data.customer : c)));
            } else {
                console.error("REMARK CLEAR FAILED:", res.status, data.message);
                if (data.message) alert(data.message);
                loadCustomers();
            }
        } catch (err) {
            console.error("REMARK CLEAR ERROR", err);
        }
    };
    const saveDate = async (customerId, field, dateValue) => {
        const current = customers.find((c) => c._id === customerId);
        const currentValue = !!current?.checklist?.[field];
        try {
            const res = await fetch(`${API}/api/loan-process/${customerId}/checklist`, {
                method: "PATCH",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify({ field, value: currentValue, date: dateValue }),
            });
            const data = await res.json();
            if (data.success) {
                setCustomers((prev) => prev.map((c) => (c._id === customerId ? data.customer : c)));
            } else {
                console.error("DATE SAVE FAILED:", res.status, data.message);
            }
        } catch (err) {
            console.error("DATE SAVE ERROR", err);
        }
    };


    const saveAmount = async (customerId, field, amountValue) => {
        const current = customers.find((c) => c._id === customerId);
        const oldVal = current?.documentPaymentExternal ? "ELSEWHERE" : (current?.checklistAmounts?.[field] ?? "");
        if (String(oldVal) === String(amountValue)) return; // maaralana save venaam
        const currentValue = !!current?.checklist?.[field];
        try {
            const res = await fetch(`${API}/api/loan-process/${customerId}/checklist`, {
                method: "PATCH",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify({ field, value: currentValue, amount: amountValue }),
            });
            const data = await res.json();
            if (data.success) {
                setCustomers((prev) => prev.map((c) => (c._id === customerId ? data.customer : c)));
            } else {
                alert(data.message || "Amount save aagala");
            }
        } catch (err) {
            console.error("AMOUNT SAVE ERROR", err);
        }
    };


    /* ------------------------ TAB 2 — CUSTOMER DATA (edit/delete) ------- */
    const startEdit = (customer) => {
        setExpandedDataId(customer._id);
        setEditingId(customer._id);
        setEditForm({
            customerName: customer.customerName || "",
            loanDate: customer.loanDate ? new Date(customer.loanDate).toISOString().slice(0, 10) : todayStr(),
            communicationAddress: customer.communicationAddress || "",
            unitAddress: customer.unitAddress || "",
            businessType: customer.businessType || "",
            businessSubType: customer.businessSubType || "",

            scheme: customer.scheme || "",
            loanValue: customer.loanValue ?? "",
            contactNo: customer.contactNo || "",
            mailId: customer.mailId || "",
            bankName: customer.bankName || "",
            ifscCode: customer.ifscCode || "",
            fatherName: customer.fatherName || "",
            fatherOccupation: customer.fatherOccupation || "",
            maritalStatus: customer.maritalStatus || "",
            spouseName: customer.spouseName || "",
            spouseOccupation: customer.spouseOccupation || "",
        });
        setEditFiles({});
        setEditFieldErrors({});
        setEditDocErrors({});
        setEditError("");
    };

    const cancelEdit = () => {
        setEditingId(null);
        setEditForm(BLANK_FORM);
        setEditFiles({});
        setEditFieldErrors({});
        setEditDocErrors({});
        setEditError("");
    };

    const handleEditChange = (e) => {
        const { name, value } = e.target;
        const nextValue = name === "ifscCode" ? value.toUpperCase() : value;
        setEditForm((prev) => ({ ...prev, [name]: nextValue }));
        if (editFieldErrors[name]) {
            setEditFieldErrors((prev) => {
                const next = { ...prev };
                delete next[name];
                return next;
            });
        }
    };

    const handleEditFile = (key, file) => {
        setEditFiles((prev) => ({ ...prev, [key]: file }));
        if (editDocErrors[key]) {
            setEditDocErrors((prev) => {
                const next = { ...prev };
                delete next[key];
                return next;
            });
        }
    };

    const validateEditForm = (customer) => {
        const fErrs = {};
        const dErrs = {};

        if (!editForm.customerName.trim()) fErrs.customerName = "Customer Name is required.";

        if (!editForm.contactNo.trim()) {
            fErrs.contactNo = "Contact No is required.";
        } else if (!PHONE_RE.test(editForm.contactNo.trim())) {
            fErrs.contactNo = "Enter a valid 10 digit mobile number.";
        }

        if (!editForm.mailId.trim()) {
            fErrs.mailId = "Mail ID is required.";
        } else if (!EMAIL_RE.test(editForm.mailId.trim())) {
            fErrs.mailId = "Enter a valid email address.";
        }

        if (!editForm.businessType.trim()) fErrs.businessType = "Business Type is required.";

        if (!editForm.scheme.trim()) fErrs.scheme = "Scheme is required.";

        if (!editForm.loanDate) fErrs.loanDate = "Date is required.";

        if (!String(editForm.loanValue).trim()) {
            fErrs.loanValue = "Loan Value is required.";
        } else if (Number(editForm.loanValue) <= 0 || Number.isNaN(Number(editForm.loanValue))) {
            fErrs.loanValue = "Enter a valid loan amount.";
        }

        if (!editForm.bankName.trim()) fErrs.bankName = "Bank Name is required.";

        if (!editForm.ifscCode.trim()) {
            fErrs.ifscCode = "IFSC Code is required.";
        } else if (!IFSC_RE.test(editForm.ifscCode.trim())) {
            fErrs.ifscCode = "Enter a valid IFSC code (e.g. ABCD0123456).";
        }

        if (!editForm.communicationAddress.trim()) fErrs.communicationAddress = "Communication Address is required.";
        if (!editForm.unitAddress.trim()) fErrs.unitAddress = "Unit Address is required.";
        if (!editForm.maritalStatus) fErrs.maritalStatus = "Marital Status is required.";

        // A document is "missing" only if there's no existing uploaded doc AND no new file chosen now
        // (skip this check entirely for docs marked optional, e.g. Gas Bill, EB Bill)
        DOC_FIELDS.forEach((doc) => {
            if (doc.optional) return;
            const alreadyUploaded = !!customer?.documents?.[doc.key]?.url;
            if (!alreadyUploaded && !editFiles[doc.key]) {
                dErrs[doc.key] = `${doc.label} is required.`;
            }
        });

        return { fErrs, dErrs };
    };

    const saveEdit = async (customer) => {
        const { fErrs, dErrs } = validateEditForm(customer);
        setEditFieldErrors(fErrs);
        setEditDocErrors(dErrs);
        if (Object.keys(fErrs).length > 0 || Object.keys(dErrs).length > 0) {
            setEditError("Please fill all required fields correctly.");
            return;
        }

        setEditSaving(true);
        setEditError("");
        try {
            // 1) Save basic details
            const res = await fetch(`${API}/api/loan-process/${customer._id}`, {
                method: "PUT",
                headers: { ...authHeaders(), "Content-Type": "application/json" },
                body: JSON.stringify(editForm),
            });
            const data = await res.json();
            if (!data.success) {
                setEditError(data.message || "Failed to save changes.");
                setEditSaving(false);
                return;
            }
            let updatedCustomer = data.customer;

            // 2) If any documents were replaced, upload them
            const changedDocKeys = Object.keys(editFiles).filter((k) => editFiles[k]);
            if (changedDocKeys.length > 0) {
                const fd = new FormData();
                changedDocKeys.forEach((k) => fd.append(k, editFiles[k]));
                const docRes = await fetch(`${API}/api/loan-process/${customer._id}/documents`, {
                    method: "PATCH",
                    headers: authHeaders(),
                    body: fd,
                });
                const docData = await docRes.json();
                if (docData.success) updatedCustomer = docData.customer;
            }

            setCustomers((prev) => prev.map((c) => (c._id === customer._id ? updatedCustomer : c)));
            setRowMsg((prev) => ({ ...prev, [customer._id]: "Saved successfully." }));
            setTimeout(() => setRowMsg((prev) => ({ ...prev, [customer._id]: "" })), 2500);
            cancelEdit();
        } catch (err) {
            console.error("CUSTOMER EDIT SAVE ERROR", err);
            setEditError("Server error. Please try again.");
        } finally {
            setEditSaving(false);
        }
    };

    const deleteCustomer = async (customerId) => {
        if (!window.confirm("Delete this customer record permanently? This cannot be undone.")) return;
        setDeletingId(customerId);
        try {
            const res = await fetch(`${API}/api/loan-process/${customerId}`, {
                method: "DELETE",
                headers: authHeaders(),
            });
            const data = await res.json();
            if (data.success) {
                setCustomers((prev) => prev.filter((c) => c._id !== customerId));
                if (expandedDataId === customerId) setExpandedDataId(null);
                if (editingId === customerId) cancelEdit();
            } else {
                alert(data.message || "Failed to delete customer.");
            }
        } catch (err) {
            console.error("CUSTOMER DELETE ERROR", err);
            alert("Server error. Please try again.");
        } finally {
            setDeletingId(null);
        }
    };

    /* ------------------------ RENDER ------------------------ */
    return (
        <EmployeeLayout>
            <div className="lp-root container-fluid px-4 py-4">
                <style>{`
          .lp-root {
            --lp-bg: #F6F7FB;
            --lp-surface: #FFFFFF;
            --lp-border: #E4E7EE;
            --lp-text: #101828;
            --lp-text-muted: #64748B;
            --lp-primary: #2A3EB1;
            --lp-primary-dark: #212F8B;
            --lp-primary-soft: #EEF1FD;
            --lp-accent: #0F9D80;
            --lp-accent-soft: #E7F7F2;
            --lp-danger: #D8434B;
            --lp-danger-soft: #FDEEEE;
            --lp-radius-lg: 16px;
            --lp-radius-md: 12px;
            --lp-radius-sm: 8px;
            --lp-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
            --lp-shadow-md: 0 8px 24px rgba(16, 24, 40, 0.08);
            background: var(--lp-bg);
            min-height: 100vh;
            font-family: "Inter", "Segoe UI", system-ui, -apple-system, sans-serif;
            color: var(--lp-text);
          }
          .lp-tabs { display: flex; gap: 8px; margin-bottom: 24px; border-bottom: 1px solid var(--lp-border); }
          .lp-tab-btn {
            padding: 12px 20px; border: none; background: none; cursor: pointer;
            font-weight: 600; font-size: 14px; color: var(--lp-text-muted);
            border-bottom: 2px solid transparent; margin-bottom: -1px;
          }
          .lp-tab-btn.active { color: var(--lp-primary); border-bottom-color: var(--lp-primary); }
          .lp-card {
            background: var(--lp-surface); border: 1px solid var(--lp-border);
            border-radius: var(--lp-radius-lg); box-shadow: var(--lp-shadow-sm);
            padding: 24px; margin-bottom: 20px;
          }
          .lp-section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--lp-text-muted); margin-bottom: 14px; }
          .lp-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
          .lp-field label { font-size: 13px; font-weight: 600; margin-bottom: 6px; display: block; }
         .lp-field input, .lp-field select {
  width: 100%; padding: 10px 12px; border: 1px solid var(--lp-border);
  border-radius: var(--lp-radius-sm); font-size: 14px; background: var(--lp-bg);
}
.lp-field input:focus, .lp-field select:focus { outline: none; border-color: var(--lp-primary); background: var(--lp-surface); }
.lp-field input.lp-input-invalid, .lp-field select.lp-input-invalid { border-color: var(--lp-danger); background: var(--lp-danger-soft); }
          .lp-searchable-select { position: relative; }
          .lp-searchable-dropdown {
            position: absolute; top: calc(100% + 4px); left: 0; right: 0; z-index: 40;
            background: var(--lp-surface); border: 1px solid var(--lp-border); border-radius: var(--lp-radius-sm);
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.12); max-height: 220px; overflow-y: auto;
          }
          .lp-searchable-option { padding: 9px 12px; font-size: 13.5px; cursor: pointer; }
          .lp-searchable-option:hover, .lp-searchable-option.selected { background: var(--lp-primary-soft, #EEF1FD); color: var(--lp-primary); }
          .lp-searchable-empty { padding: 9px 12px; font-size: 13px; color: var(--lp-text-muted); }
          .lp-field-error { color: var(--lp-danger); font-size: 12px; margin-top: 4px; }
          .lp-doc-box.invalid { border-color: var(--lp-danger); background: var(--lp-danger-soft); border-style: solid; }
          .lp-doc-error { color: var(--lp-danger); font-size: 11px; margin-top: 2px; font-weight: 600; }
          .lp-row-actions { display: flex; gap: 8px; }
          .lp-btn-sm {
            padding: 6px 14px; border-radius: var(--lp-radius-sm); font-size: 12px; font-weight: 600;
            cursor: pointer; border: 1px solid var(--lp-border); background: var(--lp-surface);
          }
          .lp-btn-sm.edit { color: var(--lp-primary); border-color: var(--lp-primary); }
          .lp-btn-sm.edit:hover { background: var(--lp-primary-soft); }
          .lp-btn-sm.delete { color: var(--lp-danger); border-color: var(--lp-danger); }
          .lp-btn-sm.delete:hover { background: var(--lp-danger-soft); }
          .lp-btn-sm:disabled { opacity: 0.5; cursor: not-allowed; }
          .lp-view-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px 20px; }
          .lp-view-item .lp-view-label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.03em; color: var(--lp-text-muted); font-weight: 700; margin-bottom: 3px; }
          .lp-view-item .lp-view-value { font-size: 14px; color: var(--lp-text); }
          .lp-view-doc-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-top: 10px; }
          @media (max-width: 1200px) { .lp-view-doc-grid { grid-template-columns: repeat(4, 1fr); } }
          @media (max-width: 992px) { .lp-view-doc-grid { grid-template-columns: repeat(3, 1fr); } }
          @media (max-width: 700px) { .lp-view-doc-grid { grid-template-columns: repeat(2, 1fr); } }
          @media (max-width: 460px) { .lp-view-doc-grid { grid-template-columns: 1fr; } }
          .lp-view-doc { border: 1px solid var(--lp-border); border-radius: var(--lp-radius-sm); padding: 12px 14px; font-size: 12px; background: var(--lp-surface); }
          .lp-view-doc a { color: var(--lp-primary); font-weight: 600; text-decoration: none; }
          .lp-view-doc a:hover { text-decoration: underline; }
          .lp-view-doc.missing { color: var(--lp-danger); border-color: var(--lp-danger-soft); background: var(--lp-danger-soft); }
          .lp-doc-icon-row { display: flex; gap: 8px; }
          .lp-icon-btn {
            display: flex; align-items: center; justify-content: center; padding: 7px;
            border: 1px solid var(--lp-border); border-radius: var(--lp-radius-sm);
            background: var(--lp-bg); color: var(--lp-primary); cursor: pointer; transition: 0.15s;
          }
          .lp-icon-btn:hover { background: var(--lp-primary-soft); border-color: var(--lp-primary); }
          .lp-icon-btn svg { flex-shrink: 0; }
          .lp-row-msg { font-size: 12px; color: var(--lp-accent); font-weight: 600; margin-top: 4px; }
          .lp-doc-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
          @media (max-width: 1200px) { .lp-doc-grid { grid-template-columns: repeat(3, 1fr); } }
          @media (max-width: 992px) { .lp-doc-grid { grid-template-columns: repeat(2, 1fr); } }
          @media (max-width: 460px) { .lp-doc-grid { grid-template-columns: 1fr; } }
          .lp-doc-box {
            border: 1.5px dashed var(--lp-border); border-radius: var(--lp-radius-sm);
            padding: 14px; text-align: center; cursor: pointer; transition: 0.15s;
            background: var(--lp-bg); display: block;
          }
          .lp-doc-box:hover { border-color: var(--lp-primary); background: var(--lp-primary-soft); }
          .lp-doc-box.filled { border-style: solid; border-color: var(--lp-accent); background: var(--lp-accent-soft); }
          .lp-doc-label { font-size: 13px; font-weight: 600; margin-bottom: 4px; }
          .lp-doc-status { font-size: 12px; color: var(--lp-text-muted); }
          .lp-doc-box.filled .lp-doc-status { color: var(--lp-accent); font-weight: 600; }
          .lp-btn-primary {
            background: var(--lp-primary); color: #fff; border: none; padding: 12px 28px;
            border-radius: var(--lp-radius-sm); font-weight: 600; font-size: 14px; cursor: pointer;
          }
          .lp-btn-primary:hover { background: var(--lp-primary-dark); }
          .lp-btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
          .lp-alert-error { background: var(--lp-danger-soft); color: var(--lp-danger); padding: 10px 14px; border-radius: var(--lp-radius-sm); font-size: 13px; margin-bottom: 16px; }
          .lp-alert-success { background: var(--lp-accent-soft); color: var(--lp-accent); padding: 10px 14px; border-radius: var(--lp-radius-sm); font-size: 13px; margin-bottom: 16px; }
          .lp-cust-card { border: 1px solid var(--lp-border); border-radius: var(--lp-radius-md); margin-bottom: 14px; overflow: visible; }
          .lp-cust-head { display: flex; justify-content: space-between; align-items: center; padding: 16px 20px; cursor: pointer; background: var(--lp-surface); border-radius: var(--lp-radius-md) var(--lp-radius-md) 0 0; }
          .lp-cust-head:hover { background: var(--lp-bg); }
          .lp-progress-bar { height: 6px; background: var(--lp-border); border-radius: 4px; overflow: hidden; width: 140px; }
          .lp-progress-fill { height: 100%; background: var(--lp-accent); transition: width 0.3s; }
          .lp-checklist-body { padding: 16px 20px; border-top: 1px solid var(--lp-border); background: var(--lp-bg); border-radius: 0 0 var(--lp-radius-md) var(--lp-radius-md); }
          .lp-stage-row { display: flex; align-items: center; gap: 10px; padding: 8px 0; font-size: 14px; cursor: pointer; }
          .lp-stage-row input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; accent-color: var(--lp-accent); }
          .lp-badge { font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; }
          .lp-badge.done { background: var(--lp-accent-soft); color: var(--lp-accent); }
          .lp-badge.progress { background: var(--lp-primary-soft); color: var(--lp-primary); }

          /* ══════════════ MOBILE RESPONSIVE FIXES ══════════════ */
          @media (max-width: 576px) {
            .lp-root.container-fluid { padding-left: 12px !important; padding-right: 12px !important; padding-top: 16px !important; padding-bottom: 16px !important; }
            .lp-root h4 { font-size: 18px; }
            .lp-tabs { flex-wrap: nowrap; overflow-x: auto; -webkit-overflow-scrolling: touch; gap: 4px; margin-bottom: 18px; scrollbar-width: none; }
            .lp-tabs::-webkit-scrollbar { display: none; }
            .lp-tab-btn { padding: 10px 12px; font-size: 12.5px; white-space: nowrap; flex-shrink: 0; }
            .lp-card { padding: 14px; margin-bottom: 14px; border-radius: var(--lp-radius-md); }
            .lp-grid { grid-template-columns: 1fr; gap: 12px; }
            .lp-field input, .lp-field select { font-size: 16px; padding: 10px; }
            .lp-doc-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
            .lp-view-doc-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
            .lp-view-grid { grid-template-columns: 1fr; gap: 10px 0; }
            .lp-view-item[style*="span 2"], .lp-field[style*="span 2"] { grid-column: span 1 !important; }
            .lp-cust-head { padding: 12px 14px; flex-wrap: wrap; gap: 8px; }
            .lp-cust-head > div:first-child { min-width: 0; overflow: hidden; text-overflow: ellipsis; }
            .lp-cust-head > div:first-child > div { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .lp-progress-bar { width: 70px; }
            .lp-checklist-body { padding: 12px 14px; }
            .lp-row-actions { flex-wrap: wrap; }
            .lp-btn-sm { padding: 6px 10px; font-size: 11px; }
            .lp-btn-primary { width: 100%; padding: 12px 20px; }
            .lp-doc-icon-row { flex-wrap: wrap; }
          }

          @media (max-width: 380px) {
            .lp-doc-grid { grid-template-columns: 1fr; }
            .lp-view-doc-grid { grid-template-columns: 1fr; }
            .lp-tab-btn { padding: 9px 10px; font-size: 12px; }
          }
        `}</style>

                <h4 style={{ fontWeight: 700, marginBottom: 4 }}>Loan Process</h4>
                <p style={{ color: "var(--lp-text-muted)", fontSize: 14, marginBottom: 24 }}>
                    {isTelecaller
                        ? "Add customer details and documents, then track the process through checklist."
                        : "View every telecaller's customer details and documents to submit applications."}
                </p>

                <div className="lp-tabs">
                    {accessLoaded && isTelecaller && (
                        <>
                            <button className={`lp-tab-btn ${tab === "form" ? "active" : ""}`} onClick={() => setTab("form")}>
                                Customer Details
                            </button>
                            <button className={`lp-tab-btn ${tab === "data" ? "active" : ""}`} onClick={() => setTab("data")}>
                                Customer Data {customers.length > 0 && `(${customers.length})`}
                            </button>
                            <button className={`lp-tab-btn ${tab === "checklist" ? "active" : ""}`} onClick={() => setTab("checklist")}>
                                Checklist {customers.length > 0 && `(${customers.length})`}
                            </button>
                        </>
                    )}
                    {accessLoaded && isApplication && (
                        <button className={`lp-tab-btn ${tab === "viewAll" ? "active" : ""}`} onClick={() => setTab("viewAll")}>
                            View Details
                        </button>
                    )}
                </div>

                {accessLoaded && !isTelecaller && !isApplication && (
                    <p style={{ color: "var(--lp-text-muted)" }}>You don't have access to Loan Process.</p>
                )}

                {/* ══════════════ TAB 1 — CUSTOMER FORM ══════════════ */}
                {tab === "form" && isTelecaller && (
                    <form onSubmit={handleSubmit}>
                        {error && <div className="lp-alert-error">{error}</div>}
                        {successMsg && <div className="lp-alert-success">{successMsg}</div>}

                        <div className="lp-card">
                            <div className="lp-section-title">Customer Basic Details</div>
                            <div className="lp-grid">
                                <div className="lp-field">
                                    <label>Customer Name *</label>
                                    <input
                                        name="customerName"
                                        value={form.customerName}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.customerName ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.customerName && <div className="lp-field-error">{fieldErrors.customerName}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>Date *</label>
                                    <input
                                        name="loanDate"
                                        type="date"
                                        value={form.loanDate}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.loanDate ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.loanDate && <div className="lp-field-error">{fieldErrors.loanDate}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>Contact No *</label>
                                    <input
                                        name="contactNo"
                                        value={form.contactNo}
                                        onChange={handleChange}
                                        required
                                        maxLength={10}
                                        inputMode="numeric"
                                        className={fieldErrors.contactNo ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.contactNo && <div className="lp-field-error">{fieldErrors.contactNo}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>Mail ID *</label>
                                    <input
                                        name="mailId"
                                        type="email"
                                        value={form.mailId}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.mailId ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.mailId && <div className="lp-field-error">{fieldErrors.mailId}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>Business Type *</label>
                                    <SearchableSelect
                                        name="businessType"
                                        value={form.businessType}
                                        onChange={handleChange}
                                        options={BUSINESS_TYPE_OPTIONS}
                                        placeholder="Type to search business type…"
                                        invalid={!!fieldErrors.businessType}
                                    />
                                    {fieldErrors.businessType && <div className="lp-field-error">{fieldErrors.businessType}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>Business Sub-Type (optional)</label>
                                    <input
                                        name="businessSubType"
                                        value={form.businessSubType}
                                        onChange={handleChange}
                                        placeholder="e.g. Masala, Pani Puri"
                                    />
                                </div>

                                <div className="lp-field">
                                    <label>Scheme *</label>
                                    <select
                                        name="scheme"
                                        value={form.scheme}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.scheme ? "lp-input-invalid" : ""}
                                    >
                                        <option value="">Select Scheme</option>
                                        {SCHEME_OPTIONS.map((opt) => (
                                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                                        ))}
                                    </select>
                                    {fieldErrors.scheme && <div className="lp-field-error">{fieldErrors.scheme}</div>}
                                </div>

                                <div className="lp-field">
                                    <label>Loan Value *</label>
                                    <input
                                        name="loanValue"
                                        type="number"
                                        value={form.loanValue}
                                        onChange={handleChange}
                                        required
                                        min="1"
                                        className={fieldErrors.loanValue ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.loanValue && <div className="lp-field-error">{fieldErrors.loanValue}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>Bank Name *</label>
                                    <SearchableSelect
                                        name="bankName"
                                        value={form.bankName}
                                        onChange={handleChange}
                                        options={BANK_NAME_OPTIONS}
                                        placeholder="Type to search bank…"
                                        invalid={!!fieldErrors.bankName}
                                    />
                                    {fieldErrors.bankName && <div className="lp-field-error">{fieldErrors.bankName}</div>}
                                </div>
                                <div className="lp-field">
                                    <label>IFSC Code *</label>
                                    <input
                                        name="ifscCode"
                                        value={form.ifscCode}
                                        onChange={handleChange}
                                        required
                                        maxLength={11}
                                        style={{ textTransform: "uppercase" }}
                                        className={fieldErrors.ifscCode ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.ifscCode && <div className="lp-field-error">{fieldErrors.ifscCode}</div>}
                                </div>
                                <div className="lp-field" style={{ gridColumn: "span 2" }}>
                                    <label>Communication Address *</label>
                                    <input
                                        name="communicationAddress"
                                        value={form.communicationAddress}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.communicationAddress ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.communicationAddress && (
                                        <div className="lp-field-error">{fieldErrors.communicationAddress}</div>
                                    )}
                                </div>
                                <div className="lp-field" style={{ gridColumn: "span 2" }}>
                                    <label>Unit Address *</label>
                                    <input
                                        name="unitAddress"
                                        value={form.unitAddress}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.unitAddress ? "lp-input-invalid" : ""}
                                    />
                                    {fieldErrors.unitAddress && <div className="lp-field-error">{fieldErrors.unitAddress}</div>}
                                </div>

                                <div className="lp-field">
                                    <label>Father Name</label>
                                    <input name="fatherName" value={form.fatherName} onChange={handleChange} />
                                </div>
                                <div className="lp-field">
                                    <label>Father Occupation</label>
                                    <input name="fatherOccupation" value={form.fatherOccupation} onChange={handleChange} />
                                </div>
                                <div className="lp-field">
                                    <label>Marital Status *</label>
                                    <select
                                        name="maritalStatus"
                                        value={form.maritalStatus}
                                        onChange={handleChange}
                                        required
                                        className={fieldErrors.maritalStatus ? "lp-input-invalid" : ""}
                                    >
                                        <option value="">Select</option>
                                        <option value="Married">Married</option>
                                        <option value="Unmarried">Unmarried</option>
                                    </select>
                                    {fieldErrors.maritalStatus && <div className="lp-field-error">{fieldErrors.maritalStatus}</div>}
                                </div>
                                {form.maritalStatus === "Married" && (
                                    <>
                                        <div className="lp-field">
                                            <label>Spouse Name</label>
                                            <input name="spouseName" value={form.spouseName} onChange={handleChange} />
                                        </div>
                                        <div className="lp-field">
                                            <label>Spouse Occupation</label>
                                            <input name="spouseOccupation" value={form.spouseOccupation} onChange={handleChange} />
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="lp-card">
                            <div className="lp-section-title">Govt Documents</div>
                            <p style={{ color: "var(--lp-danger)", fontSize: 12.5, fontWeight: 600, marginTop: -8, marginBottom: 14 }}>
                                * Maximum file size allowed per document: 5MB
                            </p>
                            <div className="lp-doc-grid">
                                {DOC_FIELDS.map((doc) => (
                                    <div key={doc.key}>
                                        <label
                                            className={`lp-doc-box ${files[doc.key] ? "filled" : ""} ${docErrors[doc.key] ? "invalid" : ""
                                                }`}
                                        >
                                            <div className="lp-doc-label">
                                                {doc.label} {doc.optional ? <span style={{ fontWeight: 400, color: "var(--lp-text-muted)" }}>(optional)</span> : "*"}
                                            </div>
                                            <div className="lp-doc-status">
                                                {files[doc.key] ? `✅ ${files[doc.key].name}` : "Click to upload"}
                                            </div>
                                            <input
                                                type="file"
                                                accept="image/*,application/pdf"
                                                style={{ display: "none" }}
                                                onChange={(e) => handleFile(doc.key, e.target.files[0])}
                                            />
                                        </label>
                                        {docErrors[doc.key] && <div className="lp-doc-error">{docErrors[doc.key]}</div>}
                                    </div>
                                ))}
                            </div>
                        </div>

                        <button type="submit" className="lp-btn-primary" disabled={saving}>
                            {saving ? "Saving…" : "Submit"}
                        </button>
                    </form>
                )}

                {/* ══════════════ TAB 2 — CUSTOMER DATA (view / edit / delete) ══════════════ */}
                {tab === "data" && isTelecaller && (
                    <div className="lp-card">
                        {loadingList && <p style={{ color: "var(--lp-text-muted)" }}>Loading…</p>}
                        {!loadingList && customers.length === 0 && (
                            <p style={{ color: "var(--lp-text-muted)" }}>
                                No customers yet. Add one from the "Customer Details" tab.
                            </p>
                        )}

                        {customers.map((c) => {
                            const isOpen = expandedDataId === c._id;
                            const isEditing = editingId === c._id;

                            return (
                                <div className="lp-cust-card" key={c._id}>
                                    <div
                                        className="lp-cust-head"
                                        onClick={() => {
                                            if (isEditing) return; // don't collapse while editing
                                            setExpandedDataId(isOpen ? null : c._id);
                                        }}
                                    >
                                        <div>
                                            <div style={{ fontWeight: 700, fontSize: 15 }}>{c.customerName}</div>
                                            <div style={{ fontSize: 12, color: "var(--lp-text-muted)" }}>
                                                {c.contactNo} {c.businessType && `· ${c.businessType}`}
                                            </div>
                                        </div>
                                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                            <div className="lp-row-actions" onClick={(e) => e.stopPropagation()}>
                                                {!isEditing && (
                                                    <button type="button" className="lp-btn-sm edit" onClick={() => startEdit(c)}>
                                                        Edit
                                                    </button>
                                                )}
                                                <button
                                                    type="button"
                                                    className="lp-btn-sm delete"
                                                    disabled={deletingId === c._id}
                                                    onClick={() => deleteCustomer(c._id)}
                                                >
                                                    {deletingId === c._id ? "Deleting…" : "Delete"}
                                                </button>
                                            </div>
                                            <span style={{ fontSize: 18, color: "var(--lp-text-muted)" }}>{isOpen ? "▲" : "▼"}</span>
                                        </div>
                                    </div>

                                    {isOpen && !isEditing && (
                                        <div className="lp-checklist-body">
                                            <div className="lp-view-grid">
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Mail ID</div>
                                                    <div className="lp-view-value">{c.mailId || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Contact No</div>
                                                    <div className="lp-view-value">{c.contactNo || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Date</div>
                                                    <div className="lp-view-value">{c.loanDate ? new Date(c.loanDate).toLocaleDateString() : "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Scheme</div>
                                                    <div className="lp-view-value">{c.scheme || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Loan Value</div>
                                                    <div className="lp-view-value">{c.loanValue || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Bank Name</div>
                                                    <div className="lp-view-value">{c.bankName || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">IFSC Code</div>
                                                    <div className="lp-view-value">{c.ifscCode || "—"}</div>
                                                </div>
                                                <div className="lp-view-item" style={{ gridColumn: "span 2" }}>
                                                    <div className="lp-view-label">Communication Address</div>
                                                    <div className="lp-view-value">{c.communicationAddress || "—"}</div>
                                                </div>
                                                <div className="lp-view-item" style={{ gridColumn: "span 2" }}>
                                                    <div className="lp-view-label">Unit Address</div>
                                                    <div className="lp-view-value">{c.unitAddress || "—"}</div>
                                                </div>
                                            </div>

                                            <div style={{ marginTop: 16 }}>
                                                <div className="lp-section-title">Govt Documents</div>
                                                <div className="lp-view-doc-grid">
                                                    {DOC_FIELDS.map((doc) => {
                                                        const uploaded = c.documents?.[doc.key]?.url;
                                                        return (
                                                            <div className={`lp-view-doc ${uploaded ? "" : "missing"}`} key={doc.key}>
                                                                <div style={{ fontWeight: 600, marginBottom: 6 }}>{doc.label}</div>
                                                                {uploaded ? (
                                                                    <div className="lp-doc-icon-row">
                                                                        <button
                                                                            type="button"
                                                                            className="lp-icon-btn"
                                                                            title="View"
                                                                            onClick={() => window.open(uploaded, "_blank", "noopener,noreferrer")}
                                                                        >
                                                                            <Eye size={16} />
                                                                        </button>
                                                                        <button
                                                                            type="button"
                                                                            className="lp-icon-btn"
                                                                            title="Download"
                                                                            onClick={() => downloadDoc(uploaded, `${c.customerName}_${doc.label}`)}
                                                                        >
                                                                            <Download size={16} />
                                                                        </button>
                                                                    </div>
                                                                ) : (
                                                                    "Not uploaded"
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>

                                            {rowMsg[c._id] && <div className="lp-row-msg">{rowMsg[c._id]}</div>}
                                        </div>
                                    )}

                                    {isOpen && isEditing && (
                                        <div className="lp-checklist-body">
                                            {editError && <div className="lp-alert-error">{editError}</div>}

                                            <div className="lp-section-title">Customer Basic Details</div>
                                            <div className="lp-grid" style={{ marginBottom: 20 }}>
                                                <div className="lp-field">
                                                    <label>Customer Name *</label>
                                                    <input
                                                        name="customerName"
                                                        value={editForm.customerName}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.customerName ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.customerName && (
                                                        <div className="lp-field-error">{editFieldErrors.customerName}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Date *</label>
                                                    <input
                                                        name="loanDate"
                                                        type="date"
                                                        value={editForm.loanDate}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.loanDate ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.loanDate && (
                                                        <div className="lp-field-error">{editFieldErrors.loanDate}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Contact No *</label>
                                                    <input
                                                        name="contactNo"
                                                        value={editForm.contactNo}
                                                        onChange={handleEditChange}
                                                        maxLength={10}
                                                        inputMode="numeric"
                                                        className={editFieldErrors.contactNo ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.contactNo && (
                                                        <div className="lp-field-error">{editFieldErrors.contactNo}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Mail ID *</label>
                                                    <input
                                                        name="mailId"
                                                        type="email"
                                                        value={editForm.mailId}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.mailId ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.mailId && <div className="lp-field-error">{editFieldErrors.mailId}</div>}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Business Type *</label>
                                                    <SearchableSelect
                                                        name="businessType"
                                                        value={editForm.businessType}
                                                        onChange={handleEditChange}
                                                        options={BUSINESS_TYPE_OPTIONS}
                                                        placeholder="Type to search business type…"
                                                        invalid={!!editFieldErrors.businessType}
                                                    />
                                                    {editFieldErrors.businessType && (
                                                        <div className="lp-field-error">{editFieldErrors.businessType}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Business Sub-Type (optional)</label>
                                                    <input
                                                        name="businessSubType"
                                                        value={editForm.businessSubType}
                                                        onChange={handleEditChange}
                                                        placeholder="e.g. Masala, Pani Puri"
                                                    />
                                                </div>


                                                <div className="lp-field">
                                                    <label>Scheme *</label>
                                                    <select
                                                        name="scheme"
                                                        value={editForm.scheme}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.scheme ? "lp-input-invalid" : ""}
                                                    >
                                                        <option value="">Select Scheme</option>
                                                        {SCHEME_OPTIONS.map((opt) => (
                                                            <option key={opt.value} value={opt.value}>
                                                                {opt.label}
                                                            </option>
                                                        ))}
                                                    </select>
                                                    {editFieldErrors.scheme && (
                                                        <div className="lp-field-error">{editFieldErrors.scheme}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Loan Value *</label>
                                                    <input
                                                        name="loanValue"
                                                        type="number"
                                                        value={editForm.loanValue}
                                                        onChange={handleEditChange}
                                                        min="1"
                                                        className={editFieldErrors.loanValue ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.loanValue && (
                                                        <div className="lp-field-error">{editFieldErrors.loanValue}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Bank Name *</label>
                                                    <SearchableSelect
                                                        name="bankName"
                                                        value={editForm.bankName}
                                                        onChange={handleEditChange}
                                                        options={BANK_NAME_OPTIONS}
                                                        placeholder="Type to search bank…"
                                                        invalid={!!editFieldErrors.bankName}
                                                    />
                                                    {editFieldErrors.bankName && (
                                                        <div className="lp-field-error">{editFieldErrors.bankName}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>IFSC Code *</label>
                                                    <input
                                                        name="ifscCode"
                                                        value={editForm.ifscCode}
                                                        onChange={handleEditChange}
                                                        maxLength={11}
                                                        style={{ textTransform: "uppercase" }}
                                                        className={editFieldErrors.ifscCode ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.ifscCode && (
                                                        <div className="lp-field-error">{editFieldErrors.ifscCode}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field" style={{ gridColumn: "span 2" }}>
                                                    <label>Communication Address *</label>
                                                    <input
                                                        name="communicationAddress"
                                                        value={editForm.communicationAddress}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.communicationAddress ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.communicationAddress && (
                                                        <div className="lp-field-error">{editFieldErrors.communicationAddress}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field" style={{ gridColumn: "span 2" }}>
                                                    <label>Unit Address *</label>
                                                    <input
                                                        name="unitAddress"
                                                        value={editForm.unitAddress}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.unitAddress ? "lp-input-invalid" : ""}
                                                    />
                                                    {editFieldErrors.unitAddress && (
                                                        <div className="lp-field-error">{editFieldErrors.unitAddress}</div>
                                                    )}
                                                </div>
                                                <div className="lp-field">
                                                    <label>Father Name</label>
                                                    <input name="fatherName" value={editForm.fatherName} onChange={handleEditChange} />
                                                </div>
                                                <div className="lp-field">
                                                    <label>Father Occupation</label>
                                                    <input name="fatherOccupation" value={editForm.fatherOccupation} onChange={handleEditChange} />
                                                </div>
                                                <div className="lp-field">
                                                    <label>Marital Status *</label>
                                                    <select
                                                        name="maritalStatus"
                                                        value={editForm.maritalStatus}
                                                        onChange={handleEditChange}
                                                        className={editFieldErrors.maritalStatus ? "lp-input-invalid" : ""}
                                                    >
                                                        <option value="">Select</option>
                                                        <option value="Married">Married</option>
                                                        <option value="Unmarried">Unmarried</option>
                                                    </select>
                                                    {editFieldErrors.maritalStatus && (
                                                        <div className="lp-field-error">{editFieldErrors.maritalStatus}</div>
                                                    )}
                                                </div>
                                                {editForm.maritalStatus === "Married" && (
                                                    <>
                                                        <div className="lp-field">
                                                            <label>Spouse Name</label>
                                                            <input name="spouseName" value={editForm.spouseName} onChange={handleEditChange} />
                                                        </div>
                                                        <div className="lp-field">
                                                            <label>Spouse Occupation</label>
                                                            <input name="spouseOccupation" value={editForm.spouseOccupation} onChange={handleEditChange} />
                                                        </div>
                                                    </>
                                                )}
                                            </div>

                                            <div className="lp-section-title">
                                                Govt Documents{" "}
                                                <span style={{ textTransform: "none", fontWeight: 400 }}>
                                                    (click a box to replace that document)
                                                </span>
                                            </div>
                                            <div className="lp-doc-grid">
                                                {DOC_FIELDS.map((doc) => {
                                                    const uploaded = c.documents?.[doc.key]?.url;
                                                    const newFile = editFiles[doc.key];
                                                    return (
                                                        <div key={doc.key}>
                                                            <label
                                                                className={`lp-doc-box ${uploaded || newFile ? "filled" : ""} ${editDocErrors[doc.key] ? "invalid" : ""
                                                                    }`}
                                                            >
                                                                <div className="lp-doc-label">
                                                                    {doc.label} {doc.optional ? <span style={{ fontWeight: 400, color: "var(--lp-text-muted)" }}>(optional)</span> : "*"}
                                                                </div>
                                                                <div className="lp-doc-status">
                                                                    {newFile
                                                                        ? `✅ New: ${newFile.name}`
                                                                        : uploaded
                                                                            ? "✅ Uploaded — click to replace"
                                                                            : "Click to upload"}
                                                                </div>
                                                                <input
                                                                    type="file"
                                                                    accept="image/*,application/pdf"
                                                                    style={{ display: "none" }}
                                                                    onChange={(e) => handleEditFile(doc.key, e.target.files[0])}
                                                                />
                                                            </label>
                                                            {editDocErrors[doc.key] && (
                                                                <div className="lp-doc-error">{editDocErrors[doc.key]}</div>
                                                            )}
                                                        </div>
                                                    );
                                                })}
                                            </div>

                                            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                                                <button
                                                    type="button"
                                                    className="lp-btn-primary"
                                                    disabled={editSaving}
                                                    onClick={() => saveEdit(c)}
                                                >
                                                    {editSaving ? "Saving…" : "Save Changes"}
                                                </button>
                                                <button
                                                    type="button"
                                                    className="lp-btn-sm"
                                                    style={{ padding: "12px 20px" }}
                                                    disabled={editSaving}
                                                    onClick={cancelEdit}
                                                >
                                                    Cancel
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}

                {/* ══════════════ TAB 3 — CHECKLIST ══════════════ */}
                {tab === "checklist" && isTelecaller && (
                    <div className="lp-card">
                        {loadingList && <p style={{ color: "var(--lp-text-muted)" }}>Loading…</p>}
                        {!loadingList && customers.length === 0 && (
                            <p style={{ color: "var(--lp-text-muted)" }}>
                                No customers yet. Add one from the "Customer Details" tab.
                            </p>
                        )}

                        {customers.map((c) => {
                            const total = CHECKLIST_STAGES.length;
                            const doneCount = Object.values(c.checklist || {}).filter(Boolean).length;
                            const pct = c.processPercent ?? Math.round((doneCount / total) * 100);
                            const isOpen = expandedId === c._id;

                            return (
                                <div className="lp-cust-card" key={c._id}>
                                    <div className="lp-cust-head" onClick={() => setExpandedId(isOpen ? null : c._id)}>
                                        <div>
                                            <div style={{ fontWeight: 700, fontSize: 15 }}>{c.customerName}</div>
                                            <div style={{ fontSize: 12, color: "var(--lp-text-muted)" }}>{c.contactNo}</div>
                                        </div>
                                        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                                            {c.incentive?.eligibility === "Eligible for Processing" && (
                                                <span className="lp-badge" style={{ background: "#fff4d6", color: "#8a6100" }}>
                                                    Eligible for incentive
                                                </span>
                                            )}
                                            {c.documentPaymentExternal && (
                                                <span className="lp-badge" style={{ background: "#fff7ed", color: "#b45309" }}>
                                                    No incentive · payment elsewhere
                                                </span>
                                            )}
                                            {c.incentive?.eligibility === "Paid" && (
                                                <span className="lp-badge done">
                                                    ₹{c.incentive.amount} paid
                                                </span>
                                            )}
                                            {c.incentive?.eligibility === "Rejected" && (
                                                <span
                                                    className="lp-badge"
                                                    style={{ background: "#fee2e2", color: "#b91c1c" }}
                                                    title={c.incentive.rejectedRemark}
                                                >
                                                    Rejected: {c.incentive.rejectedRemark}
                                                </span>
                                            )}
                                            {c.incentive?.eligibility === "Removed" && (
                                                <span
                                                    className="lp-badge"
                                                    style={{ background: "#f3f4f6", color: "#6b7280" }}
                                                    title={c.incentive.removedRemark}
                                                >
                                                    Not available
                                                </span>
                                            )}
                                            <span className={`lp-badge ${c.status === "COMPLETED" ? "done" : "progress"}`}>
                                                {c.status === "COMPLETED" ? "Completed" : `${pct}%`}
                                            </span>
                                            <div className="lp-progress-bar">
                                                <div className="lp-progress-fill" style={{ width: `${pct}%` }} />
                                            </div>
                                            <span style={{ fontSize: 18, color: "var(--lp-text-muted)" }}>{isOpen ? "▲" : "▼"}</span>
                                        </div>
                                    </div>

                                    {isOpen && (
                                        <div className="lp-checklist-body">
                                            {CHECKLIST_STAGES.map((stage) => (
                                                <div className="lp-stage-row" key={stage.key} style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                                                    <label style={{ display: "flex", alignItems: "center", gap: 6, minWidth: 180 }}>
                                                        <input
                                                            type="checkbox"
                                                            checked={!!c.checklist?.[stage.key]}
                                                            disabled={
                                                                (c.followup?.status && c.followup.status !== "NONE") ||
                                                                (stage.incentiveLinked && c.incentive?.eligibility === "Paid") ||
                                                                (stage.incentiveLinked &&
                                                                    !c.checklist?.[stage.key] &&
                                                                    !(remarkDraft[c._id]?.[stage.key] ?? c.checklistRemarks?.[stage.key] ?? "").trim())
                                                            }
                                                            title={
                                                                stage.incentiveLinked && c.incentive?.eligibility === "Paid"
                                                                    ? "Incentive already paid — locked"
                                                                    : stage.incentiveLinked &&
                                                                        !c.checklist?.[stage.key] &&
                                                                        !(remarkDraft[c._id]?.[stage.key] ?? c.checklistRemarks?.[stage.key] ?? "").trim()
                                                                        ? `Enter the ${stage.remarkLabel} first — it's proof for the incentive`
                                                                        : undefined
                                                            }
                                                            onChange={() => toggleStage(c._id, stage.key, c.checklist?.[stage.key])}
                                                        />
                                                        {stage.label}
                                                    </label>
                                                    <div style={{ position: "relative", flex: "1 1 200px", display: "flex", alignItems: "center" }}>
                                                        <input
                                                            ref={(el) => { remarkInputRefs.current[`${c._id}-${stage.key}`] = el; }}
                                                            type="text"
                                                            placeholder={stage.remarkPlaceholder || "Remark (optional)"}
                                                            defaultValue={c.checklistRemarks?.[stage.key] || ""}
                                                            disabled={stage.incentiveLinked && c.incentive?.eligibility === "Paid"}
                                                            onChange={(e) =>
                                                                setRemarkDraft((prev) => ({
                                                                    ...prev,
                                                                    [c._id]: { ...(prev[c._id] || {}), [stage.key]: e.target.value },
                                                                }))
                                                            }
                                                            onBlur={() => saveRemark(c._id, stage.key)}
                                                            style={{
                                                                width: "100%", padding: "4px 26px 4px 10px", border: "1px solid var(--lp-border)",
                                                                borderRadius: 6, fontSize: 12, background: "var(--lp-surface)",
                                                            }}
                                                        />
                                                        {(remarkDraft[c._id]?.[stage.key] ?? c.checklistRemarks?.[stage.key]) && (
                                                            <button
                                                                type="button"
                                                                title="Clear remark"
                                                                disabled={stage.incentiveLinked && c.incentive?.eligibility === "Paid"}
                                                                onMouseDown={(e) => e.preventDefault()}
                                                                onClick={() => clearRemark(c._id, stage.key)}
                                                                style={{
                                                                    position: "absolute", right: 6, background: "transparent", border: "none",
                                                                    cursor: "pointer", color: "var(--lp-text-muted)", fontSize: 14, lineHeight: 1,
                                                                    padding: 2,
                                                                }}
                                                            >
                                                                ✕
                                                            </button>
                                                        )}
                                                    </div>

                                                    {AMOUNT_ENABLED_STAGES.includes(stage.key) && (() => {
                                                        const saved = c.checklistAmounts?.[stage.key];
                                                        const isValid = DOC_PAYMENT_OPTIONS.includes(Number(saved));
                                                        const isExternal = !!c.documentPaymentExternal;
                                                        return (
                                                            <select
                                                                value={isExternal ? "ELSEWHERE" : isValid ? String(saved) : ""}
                                                                disabled={(c.followup?.status && c.followup.status !== "NONE") || c.incentive?.eligibility === "Paid"}
                                                                onChange={(e) => saveAmount(c._id, stage.key, e.target.value)}
                                                                title={isExternal ? "Payment done elsewhere — no incentive for this loan" : ""}
                                                                style={{
                                                                    width: 150, padding: "4px 8px",
                                                                    border: `1px solid ${isExternal ? "#d97706" : "var(--lp-border)"}`,
                                                                    borderRadius: 6, fontSize: 12,
                                                                    background: isExternal ? "#fff7ed" : "var(--lp-surface)",
                                                                }}
                                                            >
                                                                <option value="">
                                                                    {saved && !isValid && !isExternal ? `Select (old ₹${saved})` : "Select amount"}
                                                                </option>
                                                                {DOC_PAYMENT_OPTIONS.map((a) => (
                                                                    <option key={a} value={a}>₹{a.toLocaleString()}</option>
                                                                ))}
                                                                <option value="ELSEWHERE">Done elsewhere</option>
                                                            </select>
                                                        );
                                                    })()}

                                                    {DATE_ENABLED_STAGES.includes(stage.key) && (
                                                        <input
                                                            type="date"
                                                            value={c.checklistDates?.[stage.key] ? c.checklistDates[stage.key].slice(0, 10) : ""}
                                                            disabled={stage.incentiveLinked && c.incentive?.eligibility === "Paid"}
                                                            onChange={(e) => saveDate(c._id, stage.key, e.target.value)}
                                                            style={{
                                                                padding: "4px 8px", border: "1px solid var(--lp-border)",
                                                                borderRadius: 6, fontSize: 12, background: "var(--lp-surface)",
                                                            }}
                                                        />
                                                    )}
                                                </div>
                                            ))}



                                            <div style={{ marginTop: 12 }}>
                                                <label style={{ fontSize: 13, fontWeight: 600, display: "block", marginBottom: 6 }}>
                                                    Reason for Pending
                                                </label>
                                                <input
                                                    defaultValue={c.reasonForPending || ""}
                                                    onChange={(e) => setReasonDraft({ ...reasonDraft, [c._id]: e.target.value })}
                                                    onBlur={() => saveReason(c._id)}
                                                    style={{
                                                        width: "100%", padding: "8px 12px", border: "1px solid var(--lp-border)",
                                                        borderRadius: "8px", fontSize: 13, background: "var(--lp-surface)",
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}

                {/* ══════════════ TAB 4 — VIEW DETAILS ══════════════ */}
                {tab === "viewAll" && isApplication && (
                    <div className="lp-card">
                        <div className="lp-tabs" style={{ marginBottom: 12 }}>
                            <button className={`lp-tab-btn ${appTab === "pending" ? "active" : ""}`} onClick={() => setAppTab("pending")}>
                                Pending ({pendingApps.length})
                            </button>
                            <button className={`lp-tab-btn ${appTab === "mine" ? "active" : ""}`} onClick={() => setAppTab("mine")}>
                                My Applications ({myApps.length})
                            </button>
                            <button className={`lp-tab-btn ${appTab === "completed" ? "active" : ""}`} onClick={() => setAppTab("completed")}>
                                Completed ({completedApps.length})
                            </button>
                        </div>
                        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center", marginBottom: 14 }}>
                            <input
                                placeholder="Search customer name, mobile or telecaller…"
                                value={appSearch}
                                onChange={(e) => setAppSearch(e.target.value)}
                                style={{ flex: "1 1 260px", padding: "9px 14px", border: "1px solid var(--lp-border)", borderRadius: 8, fontSize: 14 }}
                            />
                            <select
                                value={appSort}
                                onChange={(e) => setAppSort(e.target.value)}
                                style={{ padding: "9px 12px", border: "1px solid var(--lp-border)", borderRadius: 8, fontSize: 14 }}
                            >
                                <option value="added">Recently added</option>
                                <option value="dateNew">Date: newest first</option>
                                <option value="dateOld">Date: oldest first</option>
                            </select>
                            <label style={{ fontSize: 12, color: "var(--lp-text-muted)", display: "flex", alignItems: "center", gap: 6 }}>
                                From
                                <input type="date" value={appFrom} max={appTo || undefined} onChange={(e) => setAppFrom(e.target.value)}
                                    style={{ padding: "8px 10px", border: "1px solid var(--lp-border)", borderRadius: 8 }} />
                            </label>
                            <label style={{ fontSize: 12, color: "var(--lp-text-muted)", display: "flex", alignItems: "center", gap: 6 }}>
                                To
                                <input type="date" value={appTo} min={appFrom || undefined} onChange={(e) => setAppTo(e.target.value)}
                                    style={{ padding: "8px 10px", border: "1px solid var(--lp-border)", borderRadius: 8 }} />
                            </label>
                            {(appSearch || appFrom || appTo) && (
                                <button
                                    className="lp-btn-sm"
                                    onClick={() => { setAppSearch(""); setAppFrom(""); setAppTo(""); }}
                                >
                                    ✕ Clear
                                </button>
                            )}
                        </div>
                        {loadingAll && <p style={{ color: "var(--lp-text-muted)" }}>Loading…</p>}
                        {!loadingAll && appList.length === 0 && (
                            <p style={{ color: "var(--lp-text-muted)" }}>{(appSearch || appFrom || appTo) ? "No records match your search." : "No customer records found."}</p>
                        )}

                        {appList.map((c) => {
                            const total = CHECKLIST_STAGES.length;
                            const doneCount = Object.values(c.checklist || {}).filter(Boolean).length;
                            const pct = c.processPercent ?? Math.round((doneCount / total) * 100);
                            const isOpen = expandedViewAllId === c._id;
                            const staffLabel = c.staffId?.name || c.staffName || "Unknown";

                            return (
                                <div className="lp-cust-card" key={c._id}>
                                    <div
                                        className="lp-cust-head"
                                        onClick={() => setExpandedViewAllId(isOpen ? null : c._id)}
                                    >
                                        <div>
                                            <div style={{ fontWeight: 700, fontSize: 15 }}>{c.customerName}</div>
                                            <div style={{ fontSize: 12, color: "var(--lp-text-muted)" }}>
                                                {c.contactNo} · {staffLabel} · {c.loanDate ? new Date(c.loanDate).toLocaleDateString("en-IN") : "—"}
                                            </div>
                                            <div style={{ fontSize: 12, color: "var(--lp-text-muted)", marginTop: 2 }}>
                                                🕒 Added: {fmtAdded(c.createdAt)}
                                            </div>
                                        </div>
                                        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                                            {c.application?.assignedTo?.name && (
                                                <span className="lp-badge" style={{ background: "#e0e7ff", color: "#3730a3" }}>
                                                    {c.application.status === "COMPLETED"
                                                        ? `✔ ${c.application.assignedTo.name} · ${new Date(c.application.completedAt).toLocaleDateString("en-IN")}`
                                                        : `Taken by ${c.application.assignedTo.name}`}
                                                </span>
                                            )}
                                            {c.followup?.status === "PENDING" && (
                                                <span className="lp-badge" style={{ background: "#fff4d6", color: "#8a6100" }}>
                                                    With Followup team
                                                </span>
                                            )}
                                            {c.followup?.status === "COMPLETED" && (
                                                <span className="lp-badge done">Loan Sanctioned</span>
                                            )}
                                            <span className={`lp-badge ${c.status === "COMPLETED" ? "done" : "progress"}`}>
                                                {c.status === "COMPLETED" ? "Completed" : `${pct}%`}
                                            </span>
                                            <div className="lp-progress-bar">
                                                <div className="lp-progress-fill" style={{ width: `${pct}%` }} />
                                            </div>
                                            <span style={{ fontSize: 18, color: "var(--lp-text-muted)" }}>{isOpen ? "▲" : "▼"}</span>
                                        </div>
                                    </div>

                                    {isOpen && (
                                        <div className="lp-checklist-body">
                                            <div className="lp-view-grid">
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Scheme</div>
                                                    <div className="lp-view-value">{c.scheme || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Business Type</div>
                                                    <div className="lp-view-value">{c.businessType || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Business Sub-Type</div>
                                                    <div className="lp-view-value">{c.businessSubType || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Loan Date</div>
                                                    <div className="lp-view-value">{c.loanDate ? new Date(c.loanDate).toLocaleDateString("en-IN") : "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Mail ID</div>
                                                    <div className="lp-view-value">{c.mailId || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Contact No</div>
                                                    <div className="lp-view-value">{c.contactNo || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Loan Value</div>
                                                    <div className="lp-view-value">{c.loanValue || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Bank Name</div>
                                                    <div className="lp-view-value">{c.bankName || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">IFSC Code</div>
                                                    <div className="lp-view-value">{c.ifscCode || "—"}</div>
                                                </div>
                                                <div className="lp-view-item" style={{ gridColumn: "span 2" }}>
                                                    <div className="lp-view-label">Communication Address</div>
                                                    <div className="lp-view-value">{c.communicationAddress || "—"}</div>
                                                </div>
                                                <div className="lp-view-item" style={{ gridColumn: "span 2" }}>
                                                    <div className="lp-view-label">Unit Address</div>
                                                    <div className="lp-view-value">{c.unitAddress || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Father Name</div>
                                                    <div className="lp-view-value">{c.fatherName || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Father Occupation</div>
                                                    <div className="lp-view-value">{c.fatherOccupation || "—"}</div>
                                                </div>
                                                <div className="lp-view-item">
                                                    <div className="lp-view-label">Marital Status</div>
                                                    <div className="lp-view-value">{c.maritalStatus || "—"}</div>
                                                </div>
                                                {c.maritalStatus === "Married" && (
                                                    <>
                                                        <div className="lp-view-item">
                                                            <div className="lp-view-label">Spouse Name</div>
                                                            <div className="lp-view-value">{c.spouseName || "—"}</div>
                                                        </div>
                                                        <div className="lp-view-item">
                                                            <div className="lp-view-label">Spouse Occupation</div>
                                                            <div className="lp-view-value">{c.spouseOccupation || "—"}</div>
                                                        </div>
                                                    </>
                                                )}
                                            </div>

                                            <div style={{ marginTop: 16 }}>
                                                <div className="lp-section-title">Govt Documents</div>
                                                <div className="lp-view-doc-grid">
                                                    {DOC_FIELDS.map((doc) => {
                                                        const uploaded = c.documents?.[doc.key]?.url;
                                                        return (
                                                            <div className={`lp-view-doc ${uploaded ? "" : "missing"}`} key={doc.key}>
                                                                <div style={{ fontWeight: 600, marginBottom: 6 }}>{doc.label}</div>
                                                                {uploaded ? (
                                                                    <div className="lp-doc-icon-row">
                                                                        <button
                                                                            type="button"
                                                                            className="lp-icon-btn"
                                                                            title="View"
                                                                            onClick={() => window.open(uploaded, "_blank", "noopener,noreferrer")}
                                                                        >
                                                                            <Eye size={16} />
                                                                        </button>
                                                                        <button
                                                                            type="button"
                                                                            className="lp-icon-btn"
                                                                            title="Download"
                                                                            onClick={() => downloadDoc(uploaded, `${c.customerName}_${doc.label}`)}
                                                                        >
                                                                            <Download size={16} />
                                                                        </button>
                                                                    </div>
                                                                ) : (
                                                                    "Not uploaded"
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    {(() => {
                                        const app = c.application || {};
                                        const ownerId = app.assignedTo?.employeeId;
                                        const isMine = ownerId && String(ownerId) === String(myEmployeeId);
                                        const busy = appSavingId === c._id;
                                        const box = { display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", padding: 12, marginBottom: 14, borderRadius: 10, background: "var(--lp-bg)", border: "1px solid var(--lp-border)" };

                                        if (app.status === "COMPLETED") {
                                            return (
                                                <div style={box}>
                                                    ✔ Application completed by <b>{app.assignedTo?.name}</b> on{" "}
                                                    <b>{new Date(app.completedAt).toLocaleDateString("en-IN")}</b>
                                                </div>
                                            );
                                        }
                                        if (!ownerId) {
                                            return (
                                                <div style={box}>
                                                    <span>Nobody has taken this application yet.</span>
                                                    <button className="lp-btn-sm edit" disabled={busy} onClick={() => takeApplication(c)}>
                                                        Take this application
                                                    </button>
                                                </div>
                                            );
                                        }
                                        if (!isMine) {
                                            return <div style={box}>🔒 Being handled by <b>{app.assignedTo?.name}</b> — read only.</div>;
                                        }
                                        return (
                                            <div style={box}>
                                                <span>✅ You are handling this application.</span>
                                                <input
                                                    type="date"
                                                    max={todayDate}
                                                    value={appDate[c._id] || todayDate}
                                                    onChange={(e) => setAppDate((p) => ({ ...p, [c._id]: e.target.value }))}
                                                />
                                                <button className="lp-btn-sm edit" disabled={busy} onClick={() => completeApplication(c)}>Complete</button>
                                                <button className="lp-btn-sm delete" disabled={busy} onClick={() => releaseApplication(c)}>Release</button>
                                            </div>
                                        );
                                    })()}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </EmployeeLayout>
    );
}