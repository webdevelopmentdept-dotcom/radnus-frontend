import React, { useState, useEffect } from "react";
import LoanModeToggle, { useLoanMode } from "./LoanModeToggle";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ComposedChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const PIE_COLORS = ["#2A3EB1", "#0F9D80", "#F5A623", "#E5484D", "#7C5CFC", "#0EA5E9"];

export default function AdminLoanAnalytics() {
  const API = import.meta.env.VITE_API_BASE_URL;
  const [mode, setMode] = useLoanMode();
  const staffLabel = mode === "marketing" ? "Executive" : "Telecaller";

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const loadOverview = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (fromDate) params.append("fromDate", fromDate);
      if (toDate) params.append("toDate", toDate);
      params.append("mode", mode);

      const res = await fetch(`${API}/api/admin-loan-analytics/overview?${params.toString()}`);

      const json = await res.json();
      if (json.success) setData(json.data);
    } catch (err) {
      console.error("LOAN ANALYTICS OVERVIEW ERROR", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOverview();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  const formatRupee = (n) => `₹${Number(n || 0).toLocaleString("en-IN")}`;

  const clearFilters = () => {
    setFromDate("");
    setToDate("");
  };

  // ── Followup funnel: Total → Handed over → DIC → Bank → Sanctioned ──
  const fu = data?.followup || {};
  const ap = data?.applicationSummary || {};
  const applicationStaff = data?.applicationStaff || [];
  const followupStaff = data?.followupStaff || [];
  const totalApps = data?.summary?.totalApplications || 0;
  const followupFunnel = data
    ? [
      { key: "total", label: "Total Applications", count: totalApps, base: null },
      { key: "handed", label: `${staffLabel} Completed (Handed over)`, count: fu.handedOver || 0, base: totalApps },
      { key: "dic", label: "DIC Office Forwarded", count: fu.dicForwarded || 0, base: fu.handedOver || 0 },
      { key: "bank", label: "Bank Process Started", count: fu.bankReached || 0, base: fu.handedOver || 0 },
      { key: "sanctioned", label: "Bank Sanctioned (Completed)", count: fu.sanctioned || 0, base: fu.handedOver || 0 },
    ]
    : [];

  return (
    <div className="ala-root">
      <style>{`
        .ala-root {
          --lp-bg: #F6F7FB;
          --lp-surface: #FFFFFF;
          --lp-border: #E4E7EE;
          --lp-text: #101828;
          --lp-text-muted: #64748B;
          --lp-primary: #2A3EB1;
          --lp-primary-soft: #EEF1FD;
          --lp-accent: #0F9D80;
          --lp-accent-soft: #E7F7F2;
          --lp-warn: #B98900;
          --lp-danger: #b91c1c;
          --lp-radius-lg: 16px;
          --lp-radius-md: 12px;
          --lp-radius-sm: 8px;
          --lp-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
          font-family: "Inter", "Segoe UI", system-ui, -apple-system, sans-serif;
          color: var(--lp-text);
        }
        .ala-filters { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; align-items: center; }
        .ala-filters input {
          padding: 6px 10px; border: 1px solid var(--lp-border); border-radius: var(--lp-radius-sm);
          font-size: 13px; background: var(--lp-surface);
        }
        .ala-reset-btn {
          padding: 6px 12px; border: 1px solid var(--lp-border); border-radius: var(--lp-radius-sm);
          font-size: 12.5px; font-weight: 700; background: var(--lp-surface);
          color: var(--lp-primary); cursor: pointer;
        }
        .ala-reset-btn:hover { background: var(--lp-primary-soft); }

        .ala-section-label {
          font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;
          color: var(--lp-text-muted); margin: 4px 0 8px;
        }
        .ala-metrics-grid {
          display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 10px; margin-bottom: 20px;
        }
        .ala-metric-card {
          background: var(--lp-surface); border: 1px solid var(--lp-border);
          border-radius: var(--lp-radius-md); box-shadow: var(--lp-shadow-sm);
          padding: 12px 14px;
        }
        .ala-metric-label {
          font-size: 10.5px; font-weight: 700; text-transform: uppercase;
          letter-spacing: 0.04em; color: var(--lp-text-muted); margin-bottom: 4px;
        }
        .ala-metric-value { font-size: 20px; font-weight: 800; color: var(--lp-text); line-height: 1.2; }
        .ala-metric-value.accent { color: var(--lp-accent); }
        .ala-metric-value.primary { color: var(--lp-primary); }
        .ala-metric-value.warn { color: var(--lp-warn); }
        .ala-metric-value.danger { color: var(--lp-danger); }

        .ala-grid-2 { display: grid; grid-template-columns: 1.3fr 1fr; gap: 16px; margin-bottom: 16px; }
        .ala-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 16px; }
        @media (max-width: 1100px) { .ala-grid-2, .ala-grid-3 { grid-template-columns: 1fr; } }

        .ala-panel {
          background: var(--lp-surface); border: 1px solid var(--lp-border);
          border-radius: var(--lp-radius-md); box-shadow: var(--lp-shadow-sm);
          padding: 16px;
        }
        .ala-panel-title { font-size: 13px; font-weight: 700; margin-bottom: 12px; }
        .ala-panel-sub { font-size: 11px; color: var(--lp-text-muted); margin-top: -8px; margin-bottom: 12px; }

        /* ── Funnel ── */
        .ala-funnel-row { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
        .ala-funnel-label { width: 230px; font-size: 12px; font-weight: 600; flex-shrink: 0; }
        .ala-funnel-track { flex: 1; height: 18px; background: var(--lp-bg); border-radius: 20px; overflow: hidden; }
        .ala-funnel-fill { height: 100%; background: linear-gradient(90deg, var(--lp-primary), var(--lp-accent)); border-radius: 20px; }
        .ala-funnel-fill.followup { background: linear-gradient(90deg, #F5A623, var(--lp-accent)); }
        .ala-funnel-count { width: 42px; text-align: right; font-size: 12px; font-weight: 700; flex-shrink: 0; }
        .ala-funnel-pct { width: 44px; text-align: right; font-size: 11px; color: var(--lp-text-muted); flex-shrink: 0; }

        /* ── Tables ── */
        .ala-table-wrap { overflow-x: auto; }
        .ala-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
        .ala-table th {
          text-align: left; padding: 8px 10px; background: var(--lp-bg);
          font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.04em;
          color: var(--lp-text-muted); font-weight: 700; border-bottom: 1px solid var(--lp-border);
          white-space: nowrap;
        }
        .ala-table td { padding: 8px 10px; border-bottom: 1px solid var(--lp-border); white-space: nowrap; }
        .ala-table tr:last-child td { border-bottom: none; }
        .ala-rank-badge {
          display: inline-flex; align-items: center; justify-content: center;
          width: 20px; height: 20px; border-radius: 50%; font-size: 10.5px; font-weight: 800;
          background: var(--lp-primary-soft); color: var(--lp-primary);
        }
        .ala-rank-badge.gold { background: #FFF4D6; color: #B98900; }
        .ala-link { color: var(--lp-primary); font-weight: 700; text-decoration: none; font-size: 12px; }
        .ala-link:hover { text-decoration: underline; }
        .ala-pill { font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 20px; }
        .ala-pill.ok { background: var(--lp-accent-soft); color: var(--lp-accent); }
        .ala-pill.warn { background: #fff4d6; color: #8a6100; }
        .ala-pill.bad { background: #fee2e2; color: var(--lp-danger); }
        .ala-pill.mute { background: #EEF1F6; color: var(--lp-text-muted); }

        /* ── Recent activity ── */
        .ala-activity-item { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid var(--lp-border); font-size: 12.5px; }
        .ala-activity-item:last-child { border-bottom: none; }
        .ala-activity-name { font-weight: 700; }
        .ala-activity-sub { font-size: 11px; color: var(--lp-text-muted); }
        .ala-badge { font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 20px; white-space: nowrap; }
        .ala-badge.done { background: var(--lp-accent-soft); color: var(--lp-accent); }
        .ala-badge.progress { background: var(--lp-primary-soft); color: var(--lp-primary); }

        .ala-empty { color: var(--lp-text-muted); font-size: 12.5px; padding: 12px 0; }
      `}</style>

      <LoanModeToggle mode={mode} onChange={setMode} />

      <div style={{ marginBottom: 12 }}>
        <h4 style={{ fontWeight: 700, marginBottom: 2, fontSize: 16 }}>Loan Analytics</h4>
        <p style={{ color: "var(--lp-text-muted)", fontSize: 12.5, marginBottom: 0 }}>
          {mode === "marketing"
            ? "Overall performance, scheme mix and stage-wise bottlenecks across the Marketing loan process."
            : "Overall performance, scheme mix and stage-wise bottlenecks across the BDE loan process."}
        </p>
      </div>

      <div className="ala-filters">
        <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} title="From Date" />
        <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} title="To Date" />
        <button type="button" className="ala-reset-btn" onClick={loadOverview}>Apply</button>
        <button
          type="button"
          className="ala-reset-btn"
          onClick={() => { clearFilters(); setTimeout(loadOverview, 0); }}
        >
          Reset
        </button>
      </div>

      {loading && !data && <p className="ala-empty">Loading analytics…</p>}

      {data && (
        <>
          {/* ── Summary cards ── */}
          <div className="ala-section-label">Overall</div>
          <div className="ala-metrics-grid" style={{ marginBottom: 14 }}>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Total Applications</div>
              <div className="ala-metric-value">{data.summary.totalApplications}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Total Revenue</div>
              <div className="ala-metric-value">{formatRupee(data.summary.totalRevenue)}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">{staffLabel} Completed Revenue</div>
              <div className="ala-metric-value accent">{formatRupee(data.summary.completedRevenue)}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">{staffLabel} Completed</div>
              <div className="ala-metric-value accent">{data.summary.completedCount}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">In Progress</div>
              <div className="ala-metric-value primary">{data.summary.inProgressCount}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Avg Progress</div>
              <div className="ala-metric-value">{data.summary.avgProgress}%</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Pending Cases</div>
              <div className="ala-metric-value">{data.summary.pendingCount}</div>
            </div>
          </div>

          {/* ── Document Payment cards ── */}
          <div className="ala-section-label">Document Payment</div>
          <div className="ala-metrics-grid" style={{ marginBottom: 14 }}>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Doc Payment Collected</div>
              <div className="ala-metric-value accent">{formatRupee(data.summary.docPaymentTotal)}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Payments Received</div>
              <div className="ala-metric-value primary">{data.summary.docPaymentCount || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Done Elsewhere</div>
              <div className="ala-metric-value warn">{data.summary.docPaymentElsewhere || 0}</div>
            </div>
          </div>

          {/* ── Application cards ── */}
          <div className="ala-section-label">Application</div>
          <div className="ala-metrics-grid" style={{ marginBottom: 14 }}>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Not Taken Yet</div>
              <div className="ala-metric-value warn">{ap.notTaken || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">In Progress</div>
              <div className="ala-metric-value primary">{ap.inProgress || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Completed</div>
              <div className="ala-metric-value accent">{ap.completed || 0}</div>
            </div>
          </div>

          {/* ── Followup & Sanction cards ── */}
          <div className="ala-section-label">Followup & Sanction</div>
          <div className="ala-metrics-grid">
            <div className="ala-metric-card">
              <div className="ala-metric-label">With Followup</div>
              <div className="ala-metric-value warn">{fu.pending || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Unassigned Leads</div>
              <div className="ala-metric-value">{fu.unassigned || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Sanctioned</div>
              <div className="ala-metric-value accent">{fu.sanctioned || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Rejected</div>
              <div className="ala-metric-value danger">{fu.rejected || 0}</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Sanction Rate</div>
              <div className="ala-metric-value primary">{fu.sanctionRate || 0}%</div>
            </div>
            <div className="ala-metric-card">
              <div className="ala-metric-label">Sanctioned Revenue</div>
              <div className="ala-metric-value accent">{formatRupee(fu.sanctionedRevenue)}</div>
            </div>
          </div>

          {/* ── Monthly trend + Scheme pie ── */}
          <div className="ala-grid-2">
            <div className="ala-panel">
              <div className="ala-panel-title">Monthly Trend</div>
              <div className="ala-panel-sub">Applications & revenue over time</div>
              {data.monthlyTrend.length === 0 ? (
                <div className="ala-empty">No date-wise data yet.</div>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <ComposedChart data={data.monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E4E7EE" />
                    <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" tick={{ fontSize: 11 }} allowDecimals={false} />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      tick={{ fontSize: 11 }}
                      tickFormatter={(v) => `₹${(v / 100000).toFixed(0)}L`}
                    />
                    <Tooltip formatter={(v, name) => (name === "Revenue" ? formatRupee(v) : v)} />
                    <Legend />
                    <Bar yAxisId="left" dataKey="applications" name="Applications" fill="#2A3EB1" radius={[6, 6, 0, 0]} barSize={36} />
                    <Line yAxisId="right" type="monotone" dataKey="revenue" name="Revenue" stroke="#0F9D80" strokeWidth={2.5} dot={{ r: 4 }} />
                  </ComposedChart>
                </ResponsiveContainer>
              )}
            </div>

            <div className="ala-panel">
              <div className="ala-panel-title">Scheme-wise Mix</div>
              <div className="ala-panel-sub">PMEGP / UYEGP / AABCS split</div>
              {data.schemeBreakdown.length === 0 ? (
                <div className="ala-empty">No scheme data yet.</div>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie
                      data={data.schemeBreakdown}
                      dataKey="applications"
                      nameKey="scheme"
                      cx="50%"
                      cy="50%"
                      outerRadius={90}
                      label={(d) => `${d.scheme}: ${d.applications}`}
                    >
                      {data.schemeBreakdown.map((entry, i) => (
                        <Cell key={entry.scheme} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* ── Stage-wise funnel ── */}
          <div className="ala-panel" style={{ marginBottom: 16 }}>
            <div className="ala-panel-title">Stage-wise Funnel</div>
            <div className="ala-panel-sub">How many applications have crossed each checklist stage — spot the bottleneck</div>
            {data.funnel.map((stage) => {
              const max = data.summary.totalApplications || 1;
              const pct = Math.round((stage.count / max) * 100);
              return (
                <div className="ala-funnel-row" key={stage.key}>
                  <div className="ala-funnel-label" style={{ width: 170 }}>{stage.label}</div>
                  <div className="ala-funnel-track">
                    <div className="ala-funnel-fill" style={{ width: `${pct}%` }} />
                  </div>
                  <div className="ala-funnel-count">{stage.count}</div>
                </div>
              );
            })}
          </div>

          {/* ── Followup funnel ── */}
          <div className="ala-panel" style={{ marginBottom: 16 }}>
            <div className="ala-panel-title">Followup Funnel</div>
            <div className="ala-panel-sub">
              After the {staffLabel.toLowerCase()} finishes — how many reached DIC, Bank and Loan Sanction.
              % = share of Total (Handed over row) / share of Handed over (other rows)
            </div>
            {followupFunnel.map((step) => {
              const barPct = totalApps ? Math.round((step.count / totalApps) * 100) : 0;
              const sharePct = step.base ? Math.round((step.count / step.base) * 100) : null;
              return (
                <div className="ala-funnel-row" key={step.key}>
                  <div className="ala-funnel-label">{step.label}</div>
                  <div className="ala-funnel-track">
                    <div className="ala-funnel-fill followup" style={{ width: `${barPct}%` }} />
                  </div>
                  <div className="ala-funnel-count">{step.count}</div>
                  <div className="ala-funnel-pct">{sharePct === null ? "" : `${sharePct}%`}</div>
                </div>
              );
            })}
          </div>

          {/* ── Application team performance (employee-wise) ── */}
          <div className="ala-panel" style={{ marginBottom: 16 }}>
            <div className="ala-panel-title">Application Team Performance</div>
            <div className="ala-panel-sub">Who took how many applications and how many were completed.</div>
            {applicationStaff.length === 0 ? (
              <div className="ala-empty">
                No applications have been taken yet.
                {ap.notTaken ? ` ${ap.notTaken} application(s) are waiting to be taken.` : ""}
              </div>
            ) : (
              <div className="ala-table-wrap">
                <table className="ala-table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Employee</th>
                      <th>Taken</th>
                      <th>In Progress</th>
                      <th>Completed</th>
                      <th>Completion %</th>
                      <th>Completed Loan Value</th>
                      <th>Avg Days to Complete</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {applicationStaff.map((s, i) => (
                      <tr key={s.employeeId}>
                        <td><span className={`ala-rank-badge ${i === 0 ? "gold" : ""}`}>{i + 1}</span></td>
                        <td style={{ fontWeight: 600 }}>{s.name}</td>
                        <td><b>{s.taken}</b></td>
                        <td><span className="ala-pill warn">{s.pending}</span></td>
                        <td><span className="ala-pill ok">{s.completed}</span></td>
                        <td>{s.completionRate}%</td>
                        <td>{formatRupee(s.completedValue)}</td>
                        <td>{s.avgDaysToComplete === null ? "—" : `${s.avgDaysToComplete} d`}</td>
                        <td>
                          <a className="ala-link" href={`/admin/loan-process?applicationStaff=${s.employeeId}`}>
                            View applications →
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* ── Followup team performance (employee-wise) ── */}
          <div className="ala-panel" style={{ marginBottom: 16 }}>
            <div className="ala-panel-title">Followup Team Performance</div>
            <div className="ala-panel-sub">
              Who took how many leads, and how many reached DIC, Bank and Loan Sanction. Click “View leads” to see every lead of that employee.
            </div>
            {followupStaff.length === 0 ? (
              <div className="ala-empty">
                No leads have been taken by the Followup team yet.
                {fu.unassigned ? ` ${fu.unassigned} lead(s) are waiting to be taken.` : ""}
              </div>
            ) : (
              <div className="ala-table-wrap">
                <table className="ala-table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Employee</th>
                      <th>Leads Taken</th>
                      <th>Pending</th>
                      <th>DIC Forwarded</th>
                      <th>Bank Started</th>
                      <th>Completed</th>
                      <th>Rejected</th>
                      <th>Sanction %</th>
                      <th>Sanctioned Revenue</th>
                      <th>Avg Days to Sanction</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {followupStaff.map((s, i) => (
                      <tr key={s.employeeId}>
                        <td><span className={`ala-rank-badge ${i === 0 ? "gold" : ""}`}>{i + 1}</span></td>
                        <td style={{ fontWeight: 600 }}>{s.name}</td>
                        <td><b>{s.taken}</b></td>
                        <td><span className="ala-pill warn">{s.pending}</span></td>
                        <td>{s.dicForwarded}</td>
                        <td>{s.bankReached}</td>
                        <td><span className="ala-pill ok">{s.sanctioned}</span></td>
                        <td>{s.rejected ? <span className="ala-pill bad">{s.rejected}</span> : <span className="ala-pill mute">0</span>}</td>
                        <td>{s.sanctionRate}%</td>
                        <td>{formatRupee(s.sanctionedRevenue)}</td>
                        <td>{s.avgDaysToSanction === null ? "—" : `${s.avgDaysToSanction} d`}</td>
                        <td>
                          <a className="ala-link" href={`/admin/loan-process?followupStaff=${s.employeeId}`}>
                            View leads →
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* ── Telecaller leaderboard + Recent activity ── */}
          <div className="ala-grid-2">
            <div className="ala-panel">
              <div className="ala-panel-title">{staffLabel} Leaderboard</div>
              <div className="ala-panel-sub">Ranked by revenue</div>
              {data.staffBreakdown.length === 0 ? (
                <div className="ala-empty">No {staffLabel.toLowerCase()} data yet.</div>
              ) : (
                <table className="ala-table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>{staffLabel}</th>
                      <th>Applications</th>
                      <th>Revenue</th>
                      <th>Completed</th>
                      <th>Conv. %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.staffBreakdown.map((s, i) => (
                      <tr key={s._id || s.staffName}>
                        <td><span className={`ala-rank-badge ${i === 0 ? "gold" : ""}`}>{i + 1}</span></td>
                        <td style={{ fontWeight: 600 }}>{s.staffName || "Unknown"}</td>
                        <td>{s.applications}</td>
                        <td>{formatRupee(s.revenue)}</td>
                        <td>{s.completedCount}</td>
                        <td>{s.conversionRate}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="ala-panel">
              <div className="ala-panel-title">Recent Activity</div>
              <div className="ala-panel-sub">Latest updated customer records</div>
              {data.recentActivity.length === 0 ? (
                <div className="ala-empty">No recent activity.</div>
              ) : (
                data.recentActivity.map((c) => (
                  <div className="ala-activity-item" key={c._id}>
                    <div>
                      <div className="ala-activity-name">{c.customerName}</div>
                      <div className="ala-activity-sub">
                        {c.staffName || "—"} · {c.scheme || "No scheme"} ·{" "}
                        {c.updatedAt ? new Date(c.updatedAt).toLocaleDateString("en-IN") : "—"}
                      </div>
                    </div>
                    <span className={`ala-badge ${c.status === "COMPLETED" ? "done" : "progress"}`}>
                      {c.status === "COMPLETED" ? "Completed" : `${c.processPercent ?? 0}%`}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* ── Bank-wise & Business type breakdown ── */}
          <div className="ala-grid-2">
            <div className="ala-panel">
              <div className="ala-panel-title">Bank-wise Distribution</div>
              <div className="ala-panel-sub">Top banks by application count</div>
              {data.bankBreakdown.length === 0 ? (
                <div className="ala-empty">No bank data yet.</div>
              ) : (
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={data.bankBreakdown} layout="vertical" margin={{ left: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E4E7EE" />
                    <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
                    <YAxis type="category" dataKey="bankName" tick={{ fontSize: 11 }} width={110} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#2A3EB1" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>

            <div className="ala-panel">
              <div className="ala-panel-title">Business Type Distribution</div>
              <div className="ala-panel-sub">Top business types by application count</div>
              {data.businessTypeBreakdown.length === 0 ? (
                <div className="ala-empty">No business type data yet.</div>
              ) : (
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={data.businessTypeBreakdown} layout="vertical" margin={{ left: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E4E7EE" />
                    <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
                    <YAxis type="category" dataKey="businessType" tick={{ fontSize: 11 }} width={110} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#0F9D80" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* ── Pending reasons ── */}
          {data.pendingReasons.length > 0 && (
            <div className="ala-panel">
              <div className="ala-panel-title">Pending Reasons Summary</div>
              <div className="ala-panel-sub">Why applications are stuck, grouped by reason</div>
              <table className="ala-table">
                <thead>
                  <tr>
                    <th>Reason</th>
                    <th>Count</th>
                  </tr>
                </thead>
                <tbody>
                  {data.pendingReasons.map((r) => (
                    <tr key={r.reason}>
                      <td>{r.reason}</td>
                      <td>{r.count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}